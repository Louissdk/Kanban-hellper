
-- ===== Roles & profiles =====
CREATE TYPE public.app_role AS ENUM ('admin','supervisor','operator','viewer');

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY,
  full_name TEXT NOT NULL DEFAULT '',
  email TEXT,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT, INSERT, DELETE ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.can_operate(_user_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('admin','supervisor','operator'))
$$;

CREATE OR REPLACE FUNCTION public.can_manage(_user_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('admin','supervisor'))
$$;

CREATE POLICY "profiles readable by signed in" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "own profile or admin update" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid() OR public.has_role(auth.uid(),'admin'))
  WITH CHECK (id = auth.uid() OR public.has_role(auth.uid(),'admin'));

CREATE POLICY "roles readable by signed in" ON public.user_roles FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin inserts roles" ON public.user_roles FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin deletes roles" ON public.user_roles FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));

-- First user becomes admin; others start as viewer
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE is_first BOOLEAN;
BEGIN
  SELECT NOT EXISTS (SELECT 1 FROM public.profiles) INTO is_first;
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', split_part(NEW.email,'@',1)), NEW.email);
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, CASE WHEN is_first THEN 'admin'::public.app_role ELSE 'viewer'::public.app_role END);
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.touch_updated_at() RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;
CREATE TRIGGER profiles_touch BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ===== Sectors & stages =====
CREATE TABLE public.sectors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  active BOOLEAN NOT NULL DEFAULT true,
  position INT NOT NULL DEFAULT 0,
  is_default_import BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sectors TO authenticated;
GRANT ALL ON public.sectors TO service_role;
ALTER TABLE public.sectors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "sectors read" ON public.sectors FOR SELECT TO authenticated USING (true);
CREATE POLICY "sectors admin write" ON public.sectors FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER sectors_touch BEFORE UPDATE ON public.sectors FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE public.stages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sector_id UUID NOT NULL REFERENCES public.sectors(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  position INT NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT true,
  is_final BOOLEAN NOT NULL DEFAULT false,
  color TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX stages_sector_idx ON public.stages(sector_id, position);
GRANT SELECT, INSERT, UPDATE ON public.stages TO authenticated;
GRANT ALL ON public.stages TO service_role;
ALTER TABLE public.stages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "stages read" ON public.stages FOR SELECT TO authenticated USING (true);
CREATE POLICY "stages admin insert" ON public.stages FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "stages admin update" ON public.stages FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER stages_touch BEFORE UPDATE ON public.stages FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ===== Fichas (source data from SMB) =====
CREATE TABLE public.fichas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  external_order_id TEXT UNIQUE,
  order_number TEXT NOT NULL,
  customer TEXT NOT NULL DEFAULT '',
  product_summary TEXT,
  quantity NUMERIC,
  unit TEXT,
  order_date DATE,
  delivery_date DATE,
  source_observations TEXT,
  source_system TEXT NOT NULL DEFAULT 'smb' CHECK (source_system IN ('smb','manual')),
  source_synced_at TIMESTAMPTZ,
  source_hash TEXT,
  sync_state TEXT NOT NULL DEFAULT 'active' CHECK (sync_state IN ('active','not_seen_in_last_sync','archived')),
  sync_warning TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX fichas_order_number_idx ON public.fichas(order_number);
CREATE INDEX fichas_customer_idx ON public.fichas(customer);
CREATE INDEX fichas_delivery_idx ON public.fichas(delivery_date);
GRANT SELECT ON public.fichas TO authenticated;
GRANT ALL ON public.fichas TO service_role;
ALTER TABLE public.fichas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "fichas read" ON public.fichas FOR SELECT TO authenticated USING (true);
CREATE TRIGGER fichas_touch BEFORE UPDATE ON public.fichas FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE public.ficha_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ficha_id UUID NOT NULL REFERENCES public.fichas(id) ON DELETE CASCADE,
  line_no INT NOT NULL DEFAULT 1,
  code TEXT,
  product TEXT NOT NULL DEFAULT '',
  description TEXT,
  quantity NUMERIC,
  unit TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ficha_items_ficha_idx ON public.ficha_items(ficha_id);
GRANT SELECT ON public.ficha_items TO authenticated;
GRANT ALL ON public.ficha_items TO service_role;
ALTER TABLE public.ficha_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "items read" ON public.ficha_items FOR SELECT TO authenticated USING (true);

-- ===== Factory operational data =====
CREATE TABLE public.kanban_assignments (
  ficha_id UUID PRIMARY KEY REFERENCES public.fichas(id) ON DELETE CASCADE,
  sector_id UUID NOT NULL REFERENCES public.sectors(id),
  stage_id UUID NOT NULL REFERENCES public.stages(id),
  priority TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('baixa','normal','alta','urgente')),
  responsible_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  internal_notes TEXT,
  entered_stage_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  production_started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  last_changed_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ka_sector_stage_idx ON public.kanban_assignments(sector_id, stage_id);
CREATE INDEX ka_responsible_idx ON public.kanban_assignments(responsible_id);
GRANT SELECT, UPDATE ON public.kanban_assignments TO authenticated;
GRANT ALL ON public.kanban_assignments TO service_role;
ALTER TABLE public.kanban_assignments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ka read" ON public.kanban_assignments FOR SELECT TO authenticated USING (true);
CREATE POLICY "ka managers update" ON public.kanban_assignments FOR UPDATE TO authenticated
  USING (public.can_manage(auth.uid())) WITH CHECK (public.can_manage(auth.uid()));
CREATE TRIGGER ka_touch BEFORE UPDATE ON public.kanban_assignments FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Stage/sector columns must only change through the audited functions
CREATE OR REPLACE FUNCTION public.guard_assignment_stage() RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF (NEW.stage_id IS DISTINCT FROM OLD.stage_id OR NEW.sector_id IS DISTINCT FROM OLD.sector_id)
     AND COALESCE(current_setting('app.audited_transition', true),'') <> 'on' THEN
    RAISE EXCEPTION 'Alterações de etapa devem passar pelo fluxo auditado.';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER ka_guard BEFORE UPDATE ON public.kanban_assignments FOR EACH ROW EXECUTE FUNCTION public.guard_assignment_stage();

CREATE TABLE public.status_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ficha_id UUID NOT NULL REFERENCES public.fichas(id) ON DELETE CASCADE,
  sector_id UUID NOT NULL REFERENCES public.sectors(id),
  previous_stage_id UUID REFERENCES public.stages(id),
  new_stage_id UUID NOT NULL REFERENCES public.stages(id),
  changed_by_user_id UUID REFERENCES public.profiles(id),
  performed_by_user_id UUID REFERENCES public.profiles(id),
  changed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  observation TEXT,
  source TEXT NOT NULL CHECK (source IN ('kanban','manual','system','import'))
);
CREATE INDEX sh_ficha_idx ON public.status_history(ficha_id, changed_at DESC);
CREATE INDEX sh_changed_at_idx ON public.status_history(changed_at DESC);
GRANT SELECT ON public.status_history TO authenticated;
GRANT ALL ON public.status_history TO service_role;
ALTER TABLE public.status_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "history read" ON public.status_history FOR SELECT TO authenticated USING (true);

CREATE TABLE public.sector_transfer_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ficha_id UUID NOT NULL REFERENCES public.fichas(id) ON DELETE CASCADE,
  previous_sector_id UUID REFERENCES public.sectors(id),
  previous_stage_id UUID REFERENCES public.stages(id),
  new_sector_id UUID NOT NULL REFERENCES public.sectors(id),
  new_stage_id UUID NOT NULL REFERENCES public.stages(id),
  changed_by_user_id UUID REFERENCES public.profiles(id),
  performed_by_user_id UUID REFERENCES public.profiles(id),
  changed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  observation TEXT
);
CREATE INDEX sth_ficha_idx ON public.sector_transfer_history(ficha_id, changed_at DESC);
GRANT SELECT ON public.sector_transfer_history TO authenticated;
GRANT ALL ON public.sector_transfer_history TO service_role;
ALTER TABLE public.sector_transfer_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "transfer read" ON public.sector_transfer_history FOR SELECT TO authenticated USING (true);

-- Append-only enforcement even for privileged roles
CREATE OR REPLACE FUNCTION public.block_mutation() RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN RAISE EXCEPTION 'Histórico é somente leitura (append-only).'; END $$;
CREATE TRIGGER sh_no_update BEFORE UPDATE OR DELETE ON public.status_history FOR EACH ROW EXECUTE FUNCTION public.block_mutation();
CREATE TRIGGER sth_no_update BEFORE UPDATE OR DELETE ON public.sector_transfer_history FOR EACH ROW EXECUTE FUNCTION public.block_mutation();

-- ===== Sync =====
CREATE TABLE public.sync_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  status TEXT NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','running','success','partial','failed')),
  trigger TEXT NOT NULL DEFAULT 'schedule' CHECK (trigger IN ('schedule','manual')),
  requested_by UUID REFERENCES public.profiles(id),
  started_at TIMESTAMPTZ,
  finished_at TIMESTAMPTZ,
  total_read INT NOT NULL DEFAULT 0,
  inserted INT NOT NULL DEFAULT 0,
  updated INT NOT NULL DEFAULT 0,
  skipped INT NOT NULL DEFAULT 0,
  errors INT NOT NULL DEFAULT 0,
  warnings INT NOT NULL DEFAULT 0,
  error_details TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX sync_runs_created_idx ON public.sync_runs(created_at DESC);
GRANT SELECT, INSERT ON public.sync_runs TO authenticated;
GRANT ALL ON public.sync_runs TO service_role;
ALTER TABLE public.sync_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "sync read" ON public.sync_runs FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin requests sync" ON public.sync_runs FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(),'admin') AND status = 'requested' AND trigger = 'manual' AND requested_by = auth.uid());

CREATE TABLE public.sync_errors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sync_run_id UUID NOT NULL REFERENCES public.sync_runs(id) ON DELETE CASCADE,
  level TEXT NOT NULL DEFAULT 'error' CHECK (level IN ('error','warning')),
  external_order_id TEXT,
  message TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX sync_errors_run_idx ON public.sync_errors(sync_run_id);
GRANT SELECT ON public.sync_errors TO authenticated;
GRANT ALL ON public.sync_errors TO service_role;
ALTER TABLE public.sync_errors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "sync errors read" ON public.sync_errors FOR SELECT TO authenticated USING (true);

CREATE TABLE public.system_settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.system_settings TO authenticated;
GRANT ALL ON public.system_settings TO service_role;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "settings read" ON public.system_settings FOR SELECT TO authenticated USING (true);
CREATE POLICY "settings admin insert" ON public.system_settings FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "settings admin update" ON public.system_settings FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- ===== Central audited functions =====
CREATE OR REPLACE FUNCTION public.first_active_stage(_sector_id UUID) RETURNS UUID
LANGUAGE sql STABLE SET search_path = public AS $$
  SELECT id FROM public.stages WHERE sector_id = _sector_id AND active ORDER BY position, created_at LIMIT 1
$$;

CREATE OR REPLACE FUNCTION public.transition_ficha(
  _ficha_id UUID, _new_stage_id UUID, _changed_by UUID, _observation TEXT DEFAULT NULL, _source TEXT DEFAULT 'kanban')
RETURNS UUID LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE a public.kanban_assignments; st public.stages; hist_id UUID;
BEGIN
  IF auth.uid() IS NULL OR NOT public.can_operate(auth.uid()) THEN RAISE EXCEPTION 'Sem permissão para alterar etapas.'; END IF;
  IF _ficha_id IS NULL THEN RAISE EXCEPTION 'Selecione a ficha.'; END IF;
  IF _changed_by IS NULL THEN RAISE EXCEPTION 'Selecione o usuário responsável pela mudança.'; END IF;
  IF _new_stage_id IS NULL THEN RAISE EXCEPTION 'Selecione a nova etapa.'; END IF;
  IF _source NOT IN ('kanban','manual') THEN RAISE EXCEPTION 'Origem inválida.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = _changed_by AND active) THEN RAISE EXCEPTION 'Usuário responsável inválido ou inativo.'; END IF;
  SELECT * INTO a FROM public.kanban_assignments WHERE ficha_id = _ficha_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Ficha sem alocação no Kanban.'; END IF;
  SELECT * INTO st FROM public.stages WHERE id = _new_stage_id;
  IF NOT FOUND OR NOT st.active THEN RAISE EXCEPTION 'A etapa de destino está inativa ou não existe.'; END IF;
  IF st.sector_id <> a.sector_id THEN RAISE EXCEPTION 'A etapa de destino pertence a outro setor.'; END IF;
  IF st.id = a.stage_id THEN RAISE EXCEPTION 'A ficha já está nesta etapa.'; END IF;

  PERFORM set_config('app.audited_transition','on', true);
  UPDATE public.kanban_assignments SET
    stage_id = st.id, entered_stage_at = now(), last_changed_by = _changed_by,
    production_started_at = COALESCE(production_started_at, now()),
    completed_at = CASE WHEN st.is_final THEN now() ELSE NULL END
  WHERE ficha_id = _ficha_id;
  PERFORM set_config('app.audited_transition','off', true);

  INSERT INTO public.status_history (ficha_id, sector_id, previous_stage_id, new_stage_id, changed_by_user_id, performed_by_user_id, observation, source)
  VALUES (_ficha_id, a.sector_id, a.stage_id, st.id, _changed_by, auth.uid(), NULLIF(trim(_observation),''), _source)
  RETURNING id INTO hist_id;
  RETURN hist_id;
END $$;

CREATE OR REPLACE FUNCTION public.transfer_ficha_sector(
  _ficha_id UUID, _new_sector_id UUID, _changed_by UUID, _observation TEXT DEFAULT NULL)
RETURNS UUID LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE a public.kanban_assignments; first_stage UUID; tid UUID;
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Apenas administradores podem transferir setores.'; END IF;
  IF _changed_by IS NULL THEN RAISE EXCEPTION 'Selecione o usuário responsável pela mudança.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = _changed_by AND active) THEN RAISE EXCEPTION 'Usuário responsável inválido.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.sectors WHERE id = _new_sector_id AND active) THEN RAISE EXCEPTION 'Setor de destino inválido ou inativo.'; END IF;
  SELECT * INTO a FROM public.kanban_assignments WHERE ficha_id = _ficha_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Ficha sem alocação.'; END IF;
  IF a.sector_id = _new_sector_id THEN RAISE EXCEPTION 'A ficha já pertence a este setor.'; END IF;
  first_stage := public.first_active_stage(_new_sector_id);
  IF first_stage IS NULL THEN RAISE EXCEPTION 'O setor de destino não possui etapas ativas.'; END IF;

  PERFORM set_config('app.audited_transition','on', true);
  UPDATE public.kanban_assignments SET sector_id = _new_sector_id, stage_id = first_stage,
    entered_stage_at = now(), completed_at = NULL, last_changed_by = _changed_by
  WHERE ficha_id = _ficha_id;
  PERFORM set_config('app.audited_transition','off', true);

  INSERT INTO public.sector_transfer_history (ficha_id, previous_sector_id, previous_stage_id, new_sector_id, new_stage_id, changed_by_user_id, performed_by_user_id, observation)
  VALUES (_ficha_id, a.sector_id, a.stage_id, _new_sector_id, first_stage, _changed_by, auth.uid(), NULLIF(trim(_observation),''))
  RETURNING id INTO tid;
  RETURN tid;
END $$;

CREATE OR REPLACE FUNCTION public.reorder_stages(_sector_id UUID, _stage_ids UUID[])
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE i INT;
BEGIN
  IF NOT public.has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Sem permissão.'; END IF;
  FOR i IN 1..array_length(_stage_ids,1) LOOP
    UPDATE public.stages SET position = i WHERE id = _stage_ids[i] AND sector_id = _sector_id;
  END LOOP;
END $$;

CREATE OR REPLACE FUNCTION public.delete_stage_safe(_stage_id UUID)
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Sem permissão.'; END IF;
  IF EXISTS (SELECT 1 FROM public.kanban_assignments WHERE stage_id = _stage_id) THEN
    RAISE EXCEPTION 'Esta etapa possui fichas. Mova-as antes de excluir.'; END IF;
  IF EXISTS (SELECT 1 FROM public.status_history WHERE previous_stage_id = _stage_id OR new_stage_id = _stage_id)
     OR EXISTS (SELECT 1 FROM public.sector_transfer_history WHERE previous_stage_id = _stage_id OR new_stage_id = _stage_id) THEN
    RAISE EXCEPTION 'Esta etapa possui histórico registrado. Desative-a em vez de excluir.'; END IF;
  DELETE FROM public.stages WHERE id = _stage_id;
END $$;

-- Manual ficha creation (source = manual), used for orders not in SMB
CREATE OR REPLACE FUNCTION public.create_manual_ficha(
  _order_number TEXT, _customer TEXT, _product TEXT, _quantity NUMERIC, _unit TEXT,
  _delivery_date DATE, _sector_id UUID, _priority TEXT DEFAULT 'normal')
RETURNS UUID LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE fid UUID; first_stage UUID;
BEGIN
  IF NOT public.can_manage(auth.uid()) THEN RAISE EXCEPTION 'Sem permissão.'; END IF;
  IF coalesce(trim(_order_number),'') = '' THEN RAISE EXCEPTION 'Informe o número da ficha.'; END IF;
  first_stage := public.first_active_stage(_sector_id);
  IF first_stage IS NULL THEN RAISE EXCEPTION 'Setor sem etapas ativas.'; END IF;
  INSERT INTO public.fichas (order_number, customer, product_summary, quantity, unit, order_date, delivery_date, source_system)
  VALUES (trim(_order_number), coalesce(_customer,''), _product, _quantity, _unit, current_date, _delivery_date, 'manual') RETURNING id INTO fid;
  IF coalesce(_product,'') <> '' THEN
    INSERT INTO public.ficha_items (ficha_id, line_no, product, quantity, unit) VALUES (fid, 1, _product, _quantity, _unit);
  END IF;
  INSERT INTO public.kanban_assignments (ficha_id, sector_id, stage_id, priority, last_changed_by)
  VALUES (fid, _sector_id, first_stage, coalesce(_priority,'normal'), auth.uid());
  INSERT INTO public.status_history (ficha_id, sector_id, previous_stage_id, new_stage_id, changed_by_user_id, performed_by_user_id, observation, source)
  VALUES (fid, _sector_id, NULL, first_stage, auth.uid(), auth.uid(), 'Ficha criada manualmente', 'manual');
  RETURN fid;
END $$;

-- SMB ingest: called ONLY by the server route with service role. Never touches factory fields on update.
CREATE OR REPLACE FUNCTION public.ingest_smb_order(_order JSONB)
RETURNS TEXT LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE fid UUID; existing public.fichas; new_hash TEXT; target_sector UUID; first_stage UUID; it JSONB; n INT := 0;
BEGIN
  new_hash := md5(_order::text);
  SELECT * INTO existing FROM public.fichas WHERE external_order_id = _order->>'external_order_id';
  IF FOUND THEN
    IF existing.source_hash = new_hash THEN
      UPDATE public.fichas SET source_synced_at = now(), sync_state = 'active' WHERE id = existing.id;
      RETURN 'skipped';
    END IF;
    UPDATE public.fichas SET
      order_number = coalesce(_order->>'order_number', order_number),
      customer = coalesce(_order->>'customer', customer),
      product_summary = _order->>'product_summary',
      quantity = NULLIF(_order->>'quantity','')::numeric,
      unit = _order->>'unit',
      order_date = NULLIF(_order->>'order_date','')::date,
      delivery_date = NULLIF(_order->>'delivery_date','')::date,
      source_observations = _order->>'observations',
      source_synced_at = now(), source_hash = new_hash, sync_state = 'active', sync_warning = NULL
    WHERE id = existing.id;
    DELETE FROM public.ficha_items WHERE ficha_id = existing.id;
    fid := existing.id;
  ELSE
    SELECT id INTO target_sector FROM public.sectors WHERE active AND is_default_import ORDER BY position LIMIT 1;
    IF target_sector IS NULL THEN SELECT id INTO target_sector FROM public.sectors WHERE active ORDER BY position LIMIT 1; END IF;
    first_stage := public.first_active_stage(target_sector);
    IF first_stage IS NULL THEN RAISE EXCEPTION 'Nenhum setor/etapa ativo para importação.'; END IF;
    INSERT INTO public.fichas (external_order_id, order_number, customer, product_summary, quantity, unit, order_date, delivery_date, source_observations, source_system, source_synced_at, source_hash)
    VALUES (_order->>'external_order_id', coalesce(_order->>'order_number', _order->>'external_order_id'), coalesce(_order->>'customer',''),
      _order->>'product_summary', NULLIF(_order->>'quantity','')::numeric, _order->>'unit',
      NULLIF(_order->>'order_date','')::date, NULLIF(_order->>'delivery_date','')::date, _order->>'observations', 'smb', now(), new_hash)
    RETURNING id INTO fid;
    INSERT INTO public.kanban_assignments (ficha_id, sector_id, stage_id) VALUES (fid, target_sector, first_stage);
    INSERT INTO public.status_history (ficha_id, sector_id, previous_stage_id, new_stage_id, observation, source)
    VALUES (fid, target_sector, NULL, first_stage, 'Importado do SMB', 'import');
  END IF;
  FOR it IN SELECT * FROM jsonb_array_elements(coalesce(_order->'items','[]'::jsonb)) LOOP
    n := n + 1;
    INSERT INTO public.ficha_items (ficha_id, line_no, code, product, description, quantity, unit)
    VALUES (fid, n, it->>'code', coalesce(it->>'product',''), it->>'description', NULLIF(it->>'quantity','')::numeric, it->>'unit');
  END LOOP;
  RETURN CASE WHEN existing.id IS NULL THEN 'inserted' ELSE 'updated' END;
END $$;
REVOKE EXECUTE ON FUNCTION public.ingest_smb_order(JSONB) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.ingest_smb_order(JSONB) TO service_role;

CREATE OR REPLACE FUNCTION public.mark_unseen_orders(_seen_ids TEXT[])
RETURNS INT LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE c INT;
BEGIN
  UPDATE public.fichas SET sync_state = 'not_seen_in_last_sync'
  WHERE source_system = 'smb' AND sync_state = 'active' AND NOT (external_order_id = ANY(_seen_ids));
  GET DIAGNOSTICS c = ROW_COUNT; RETURN c;
END $$;
REVOKE EXECUTE ON FUNCTION public.mark_unseen_orders(TEXT[]) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.mark_unseen_orders(TEXT[]) TO service_role;

-- Dashboard aggregates
CREATE OR REPLACE FUNCTION public.stage_avg_durations(_sector_id UUID)
RETURNS TABLE(stage_id UUID, avg_hours NUMERIC) LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  WITH h AS (
    SELECT ficha_id, new_stage_id, changed_at,
      lead(changed_at) OVER (PARTITION BY ficha_id ORDER BY changed_at) AS left_at
    FROM public.status_history WHERE sector_id = _sector_id
  )
  SELECT new_stage_id, round(avg(extract(epoch FROM (left_at - changed_at))/3600)::numeric, 1)
  FROM h WHERE left_at IS NOT NULL GROUP BY new_stage_id
$$;

-- ===== Seed: Setor Cartucho + 13 stages + settings =====
WITH s AS (
  INSERT INTO public.sectors (name, description, position, is_default_import)
  VALUES ('Cartucho', 'Setor Cartucho — fluxo inicial de produção', 1, true) RETURNING id
)
INSERT INTO public.stages (sector_id, name, position, is_final)
SELECT s.id, v.name, v.pos, v.pos = 13 FROM s, (VALUES
  ('Corte de porcelana',1),('Enrolar porcelana',2),('Montagem',3),('Soldagem',4),('Enchimento',5),
  ('Laminador',6),('Retífica',7),('Tirar umidade',8),('Detalhe',9),('Acabamento',10),
  ('Expedição',11),('Embalado',12),('Enviado/Finalizado',13)) AS v(name,pos);

INSERT INTO public.system_settings (key, value) VALUES
  ('card_fields', '["customer","product","quantity","delivery","responsible","priority","last_move"]'::jsonb),
  ('sync', '{"interval_minutes": 30, "enabled": true}'::jsonb),
  ('stale_hours', '48'::jsonb);

ALTER PUBLICATION supabase_realtime ADD TABLE public.kanban_assignments, public.fichas, public.status_history, public.sync_runs;
