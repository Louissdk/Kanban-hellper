create or replace function public.create_manual_ficha(
  _order_number text,
  _customer text,
  _product text default null,
  _quantity numeric default null,
  _unit text default 'UND',
  _delivery_date date default null,
  _sector_id uuid default null,
  _priority text default 'normal'
)
returns uuid language plpgsql security definer set search_path = public as $func$
declare
  f_id uuid;
  target_stage uuid;
begin
  if not public.can_operate(auth.uid()) then raise exception 'Usuário sem permissão para criar fichas.'; end if;
  if coalesce(trim(_order_number),'') = '' then raise exception 'Número da ficha é obrigatório.'; end if;
  if coalesce(trim(_customer),'') = '' then raise exception 'Cliente é obrigatório.'; end if;
  if _priority not in ('baixa','normal','alta','urgente') then raise exception 'Prioridade inválida.'; end if;
  if not exists(select 1 from public.sectors where id=_sector_id and active) then raise exception 'Setor inválido ou inativo.'; end if;
  target_stage := public.first_active_stage(_sector_id);
  if target_stage is null then raise exception 'O setor não possui etapa ativa.'; end if;
  insert into public.fichas(order_number,customer,product_summary,quantity,unit,delivery_date,source_system,source_synced_at,sync_state)
  values(trim(_order_number),trim(_customer),nullif(trim(coalesce(_product,'')),''),_quantity,nullif(trim(coalesce(_unit,'UND')), ''),_delivery_date,'manual',null,'active')
  returning id into f_id;
  insert into public.kanban_assignments(ficha_id,sector_id,stage_id,priority,last_changed_by)
  values(f_id,_sector_id,target_stage,coalesce(_priority,'normal'),auth.uid());
  insert into public.status_history(ficha_id,sector_id,previous_stage_id,new_stage_id,changed_by_user_id,performed_by_user_id,changed_at,observation,source)
  values(f_id,_sector_id,null,target_stage,auth.uid(),auth.uid(),now(),'Ficha manual criada','manual');
  return f_id;
end $func$;

grant execute on function public.create_manual_ficha(text,text,text,numeric,text,date,uuid,text) to authenticated;
