-- Production losses: dashboard, reporting and period filtering.

create table if not exists public.production_losses (
  id uuid primary key default gen_random_uuid(),
  ficha_id uuid references public.fichas(id) on delete set null,
  occurrence_date date not null default current_date,
  sector_id uuid not null references public.sectors(id),
  stage_id uuid references public.stages(id),
  responsible_id uuid not null references public.profiles(id),
  description text not null,
  quantity numeric not null default 1 check (quantity > 0),
  unit text not null default 'UND',
  reason_category text not null,
  details text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_production_losses_date on public.production_losses(occurrence_date);
create index if not exists idx_production_losses_sector on public.production_losses(sector_id, occurrence_date);
create index if not exists idx_production_losses_responsible on public.production_losses(responsible_id, occurrence_date);
create index if not exists idx_production_losses_ficha on public.production_losses(ficha_id);

alter table public.production_losses enable row level security;
revoke all on public.production_losses from public, anon, authenticated;

drop policy if exists "authenticated can read losses" on public.production_losses;
create policy "authenticated can read losses"
on public.production_losses for select to authenticated
using (true);
grant select on public.production_losses to authenticated;

create or replace function public.record_production_loss(
  _ficha_id uuid default null,
  _occurrence_date date default current_date,
  _sector_id uuid default null,
  _stage_id uuid default null,
  _responsible_id uuid default null,
  _description text default '',
  _quantity numeric default 1,
  _unit text default 'UND',
  _reason_category text default 'Outro',
  _details text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $func$
declare
  loss_id uuid;
begin
  if not public.can_operate(auth.uid()) then raise exception 'Usuário sem permissão para registrar perdas.'; end if;
  if _occurrence_date is null then raise exception 'Data da perda é obrigatória.'; end if;
  if _sector_id is null or not exists(select 1 from public.sectors where id=_sector_id and active) then raise exception 'Setor inválido.'; end if;
  if _responsible_id is null or not exists(select 1 from public.profiles where id=_responsible_id and active) then raise exception 'Responsável inválido.'; end if;
  if coalesce(trim(_description),'') = '' then raise exception 'Descrição da peça é obrigatória.'; end if;
  if coalesce(_quantity,0) <= 0 then raise exception 'A quantidade perdida deve ser maior que zero.'; end if;
  if coalesce(trim(_reason_category),'') = '' then raise exception 'Motivo da perda é obrigatório.'; end if;
  if _ficha_id is not null and not exists(select 1 from public.fichas where id=_ficha_id) then raise exception 'Ficha não encontrada.'; end if;
  if _stage_id is not null and not exists(select 1 from public.stages where id=_stage_id and sector_id=_sector_id) then raise exception 'Etapa incompatível com o setor.'; end if;

  insert into public.production_losses(
    ficha_id, occurrence_date, sector_id, stage_id, responsible_id,
    description, quantity, unit, reason_category, details, created_by
  )
  values(
    _ficha_id, _occurrence_date, _sector_id, _stage_id, _responsible_id,
    trim(_description), _quantity, coalesce(nullif(trim(_unit),''),'UND'),
    trim(_reason_category), nullif(trim(coalesce(_details,'')),''), auth.uid()
  )
  returning id into loss_id;

  return loss_id;
end
$func$;

create or replace function public.list_production_losses(
  _start_date date,
  _end_date date,
  _sector_id uuid default null
)
returns table(
  id uuid,
  ficha_id uuid,
  order_number text,
  occurrence_date date,
  sector_id uuid,
  sector_name text,
  stage_id uuid,
  stage_name text,
  responsible_id uuid,
  responsible_name text,
  description text,
  quantity numeric,
  unit text,
  reason_category text,
  details text,
  created_by uuid,
  created_at timestamptz
)
language sql
stable
security definer
set search_path = public
as $func$
  select
    l.id, l.ficha_id, f.order_number, l.occurrence_date,
    l.sector_id, s.name, l.stage_id, st.name,
    l.responsible_id, p.full_name, l.description, l.quantity,
    l.unit, l.reason_category, l.details, l.created_by, l.created_at
  from public.production_losses l
  left join public.fichas f on f.id=l.ficha_id
  join public.sectors s on s.id=l.sector_id
  left join public.stages st on st.id=l.stage_id
  join public.profiles p on p.id=l.responsible_id
  where l.occurrence_date between _start_date and _end_date
    and (_sector_id is null or l.sector_id=_sector_id)
  order by l.occurrence_date desc, l.created_at desc;
$func$;

revoke execute on function public.record_production_loss(uuid,date,uuid,uuid,uuid,text,numeric,text,text,text) from public, anon, authenticated;
revoke execute on function public.list_production_losses(date,date,uuid) from public, anon;
grant execute on function public.record_production_loss(uuid,date,uuid,uuid,uuid,text,numeric,text,text,text) to authenticated;
grant execute on function public.list_production_losses(date,date,uuid) to authenticated;
