-- Persist the manual vertical order of cards without changing production-stage history.
alter table public.kanban_assignments
  add column if not exists sort_order bigint;

update public.kanban_assignments ka
set sort_order = ranked.rn * 1000
from (
  select ka2.ficha_id,
         row_number() over (
           partition by ka2.sector_id, ka2.stage_id
           order by f.created_at desc, ka2.entered_stage_at desc, ka2.updated_at desc, ka2.ficha_id
         ) as rn
  from public.kanban_assignments ka2
  join public.fichas f on f.id = ka2.ficha_id
) ranked
where ranked.ficha_id = ka.ficha_id
  and ka.sort_order is null;

create index if not exists idx_kanban_assignments_stage_sort
  on public.kanban_assignments (sector_id, stage_id, sort_order, ficha_id);

create schema if not exists private;

create or replace function private.set_kanban_sort_order()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  next_order bigint;
begin
  if TG_OP = 'INSERT'
     or NEW.stage_id is distinct from OLD.stage_id
     or NEW.sector_id is distinct from OLD.sector_id then
    select coalesce(max(sort_order), 0) + 1000
      into next_order
      from public.kanban_assignments
     where sector_id = NEW.sector_id
       and stage_id = NEW.stage_id
       and ficha_id <> NEW.ficha_id;

    NEW.sort_order := next_order;
  end if;

  return NEW;
end;
$function$;

revoke all on function private.set_kanban_sort_order() from public, anon, authenticated;

drop trigger if exists trg_set_kanban_sort_order on public.kanban_assignments;

create trigger trg_set_kanban_sort_order
before insert or update of sector_id, stage_id
on public.kanban_assignments
for each row
execute function private.set_kanban_sort_order();

create or replace function public.reorder_kanban_stage(
  _sector_id uuid,
  _stage_id uuid,
  _ordered_ficha_ids uuid[]
)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  expected_count integer;
  ordered_count integer;
  duplicate_count integer;
begin
  if auth.uid() is null or not public.can_operate(auth.uid()) then
    raise exception 'Você não tem permissão para reordenar os cards.';
  end if;

  if _sector_id is null or _stage_id is null then
    raise exception 'Setor e etapa são obrigatórios.';
  end if;

  select count(*) into expected_count
  from public.kanban_assignments
  where sector_id = _sector_id
    and stage_id = _stage_id;

  ordered_count := coalesce(array_length(_ordered_ficha_ids, 1), 0);

  if ordered_count <> expected_count then
    raise exception 'A lista de cards mudou durante a movimentação. Atualize o quadro e tente novamente.';
  end if;

  select count(*) into duplicate_count
  from (
    select ficha_id
    from unnest(coalesce(_ordered_ficha_ids, '{}'::uuid[])) as ficha_id
    group by ficha_id
    having count(*) > 1
  ) duplicates;

  if duplicate_count > 0 then
    raise exception 'A ordenação recebida contém cards duplicados.';
  end if;

  if exists (
    select 1
    from unnest(coalesce(_ordered_ficha_ids, '{}'::uuid[])) as x(ficha_id)
    where not exists (
      select 1
      from public.kanban_assignments ka
      where ka.ficha_id = x.ficha_id
        and ka.sector_id = _sector_id
        and ka.stage_id = _stage_id
    )
  ) then
    raise exception 'A ordenação contém um card que não pertence à etapa.';
  end if;

  update public.kanban_assignments ka
     set sort_order = ranked.sort_order
    from (
      select ficha_id, ord * 1000 as sort_order
      from unnest(coalesce(_ordered_ficha_ids, '{}'::uuid[])) with ordinality as x(ficha_id, ord)
    ) ranked
   where ka.ficha_id = ranked.ficha_id
     and ka.sector_id = _sector_id
     and ka.stage_id = _stage_id;
end;
$function$;

revoke all on function public.reorder_kanban_stage(uuid, uuid, uuid[]) from public, anon, authenticated;
grant execute on function public.reorder_kanban_stage(uuid, uuid, uuid[]) to authenticated, service_role;
