-- Controle administrativo do código mestre do cliente + visibilidade de fornecedores.
-- O código definido pela administração é a fonte definitiva para fichas antigas e futuras.

create or replace function public.update_customer_code(_ficha_id uuid, _customer_code text)
returns uuid
language plpgsql
security definer
set search_path = public
as $func$
declare
  result_id uuid;
  customer_name text;
  normalized_code text;
  master_matches integer;
begin
  if not public.has_role(auth.uid(),'admin') then
    raise exception 'Apenas administradores podem alterar o código do cliente.';
  end if;

  normalized_code := nullif(trim(_customer_code), '');

  select f.customer into customer_name
  from public.fichas f
  where f.id = _ficha_id;

  if customer_name is null then
    raise exception 'Ficha não encontrada.';
  end if;

  select count(*) into master_matches
  from public.clientes c
  where upper(trim(c.nome)) = upper(trim(customer_name));

  if master_matches = 0 then
    insert into public.clientes(nome, codigo_cliente, ativo)
    values(customer_name, normalized_code, true);
  else
    update public.clientes
    set codigo_cliente = normalized_code
    where upper(trim(nome)) = upper(trim(customer_name));
  end if;

  update public.fichas
  set customer_code = normalized_code,
      codigo_cliente = normalized_code,
      updated_at = now()
  where upper(trim(customer)) = upper(trim(customer_name));

  select id into result_id
  from public.fichas
  where id = _ficha_id;

  return result_id;
end
$func$;

revoke execute on function public.update_customer_code(uuid,text) from public, anon;
grant execute on function public.update_customer_code(uuid,text) to authenticated;

create or replace function public.sync_customer_master_code_to_fichas()
returns trigger
language plpgsql
security definer
set search_path = public
as $func$
begin
  update public.fichas
  set customer_code = new.codigo_cliente,
      codigo_cliente = new.codigo_cliente,
      updated_at = now()
  where upper(trim(customer)) = upper(trim(new.nome));

  return new;
end
$func$;

drop trigger if exists trg_sync_customer_master_code on public.clientes;
create trigger trg_sync_customer_master_code
after update of codigo_cliente on public.clientes
for each row
when (old.codigo_cliente is distinct from new.codigo_cliente)
execute function public.sync_customer_master_code_to_fichas();

revoke all on public.clientes from anon;
revoke update, insert, delete on public.clientes from authenticated;
grant select on public.clientes to authenticated;

alter table public.clientes enable row level security;

drop policy if exists clientes_select_admin on public.clientes;
create policy clientes_select_admin
on public.clientes
for select
to authenticated
using (public.has_role(auth.uid(),'admin'));

-- Fornecedores: caso a base já possua esta tabela, somente a administração poderá
-- visualizar as linhas. A regra é condicional para não criar uma arquitetura nova.
do $$
begin
  if to_regclass('public.fornecedores') is not null then
    execute 'alter table public.fornecedores enable row level security';
    execute 'revoke all on public.fornecedores from anon';
    execute 'revoke all on public.fornecedores from authenticated';
    execute 'grant select on public.fornecedores to authenticated';
    execute 'drop policy if exists fornecedores_select_admin on public.fornecedores';
    execute 'create policy fornecedores_select_admin on public.fornecedores for select to authenticated using (public.has_role(auth.uid(),''admin''))';
  end if;
end $$;
