-- Repair migration for the existing Kanban drag/drop architecture.
-- Keeps transition_ficha + status_history as the single stage-change path.
-- Adds the persisted manual card order RPC used by the board.

alter table public.kanban_assignments
  add column if not exists sort_order bigint;

update public.kanban_assignments ka
set sort_order = ranked.rn * 1000
from (
  select ka2.ficha_id,
         row_number() over (
           partition by ka2.sector_id, ka2.stage_id
           order by f.created_at desc,
                    ka2.entered_stage_at desc,
                    ka2.updated_at desc,
                    ka2.ficha_id
         ) as rn
  from public.kanban_assignments ka2
  join public.fichas f on f.id = ka2.ficha_id
) ranked
where ranked.ficha_id = ka.ficha_id
  and ka.sort_order is null;

create index if not exists idx_kanban_assignments_stage_sort
  on public.kanban_assignments (sector_id, stage_id, sort_order, ficha_id);

create schema if not exists private;

create or replace function private.set_kanban_sort_order()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  next_order bigint;
begin
  if TG_OP = 'INSERT'
     or NEW.stage_id is distinct from OLD.stage_id
     or NEW.sector_id is distinct from OLD.sector_id then
    select coalesce(max(sort_order), 0) + 1000
      into next_order
      from public.kanban_assignments
     where sector_id = NEW.sector_id
       and stage_id = NEW.stage_id
       and ficha_id <> NEW.ficha_id;

    NEW.sort_order := next_order;
  end if;

  return NEW;
end;
$function$;

revoke all on function private.set_kanban_sort_order() from public, anon, authenticated;

drop trigger if exists trg_set_kanban_sort_order on public.kanban_assignments;
create trigger trg_set_kanban_sort_order
before insert or update of sector_id, stage_id
on public.kanban_assignments
for each row
execute function private.set_kanban_sort_order();

create or replace function public.reorder_kanban_stage(
  _sector_id uuid,
  _stage_id uuid,
  _ordered_ficha_ids uuid[]
)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  expected_count integer;
  ordered_count integer;
  duplicate_count integer;
begin
  if auth.uid() is null or not public.can_operate(auth.uid()) then
    raise exception 'Você não tem permissão para reordenar os cards.';
  end if;

  if _sector_id is null or _stage_id is null then
    raise exception 'Setor e etapa são obrigatórios.';
  end if;

  select count(*)
    into expected_count
  from public.kanban_assignments
  where sector_id = _sector_id
    and stage_id = _stage_id;

  ordered_count := coalesce(array_length(_ordered_ficha_ids, 1), 0);

  if ordered_count <> expected_count then
    raise exception 'A lista de cards mudou durante a movimentação. Atualize o quadro e tente novamente.';
  end if;

  select count(*)
    into duplicate_count
  from (
    select ficha_id
    from unnest(coalesce(_ordered_ficha_ids, '{}'::uuid[])) as ficha_id
    group by ficha_id
    having count(*) > 1
  ) duplicates;

  if duplicate_count > 0 then
    raise exception 'A ordenação recebida contém cards duplicados.';
  end if;

  if exists (
    select 1
    from unnest(coalesce(_ordered_ficha_ids, '{}'::uuid[])) as x(ficha_id)
    where not exists (
      select 1
      from public.kanban_assignments ka
      where ka.ficha_id = x.ficha_id
        and ka.sector_id = _sector_id
        and ka.stage_id = _stage_id
    )
  ) then
    raise exception 'A ordenação contém um card que não pertence à etapa.';
  end if;

  update public.kanban_assignments ka
     set sort_order = ranked.sort_order
    from (
      select ficha_id, ord * 1000 as sort_order
      from unnest(coalesce(_ordered_ficha_ids, '{}'::uuid[]))
        with ordinality as x(ficha_id, ord)
    ) ranked
   where ka.ficha_id = ranked.ficha_id
     and ka.sector_id = _sector_id
     and ka.stage_id = _stage_id;
end;
$function$;

revoke all on function public.reorder_kanban_stage(uuid, uuid, uuid[]) from public, anon, authenticated;
grant execute on function public.reorder_kanban_stage(uuid, uuid, uuid[]) to authenticated, service_role;

-- Ensure the current production transition function exists with the
-- return-tracking contract already used by the frontend.
alter table public.kanban_assignments
  add column if not exists production_returned boolean not null default false,
  add column if not exists return_count integer not null default 0,
  add column if not exists last_return_reason_category text,
  add column if not exists last_return_reason text,
  add column if not exists last_returned_at timestamptz,
  add column if not exists last_returned_by uuid references public.profiles(id);

alter table public.status_history
  add column if not exists movement_type text not null default 'entrada',
  add column if not exists return_reason_category text,
  add column if not exists return_reason text;

drop function if exists public.transition_ficha(uuid,uuid,uuid,text,text);

create or replace function public.transition_ficha(
  _ficha_id uuid,
  _new_stage_id uuid,
  _changed_by uuid,
  _observation text default '',
  _source text default 'kanban',
  _return_reason_category text default null
)
returns uuid
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  ka public.kanban_assignments%rowtype;
  target public.stages%rowtype;
  current_stage public.stages%rowtype;
  history_id uuid;
  movement text;
begin
  if not public.can_operate(auth.uid()) then
    raise exception 'Usuário sem permissão para alterar etapas.';
  end if;

  if not exists (
    select 1
    from public.profiles
    where id = _changed_by
      and active
  ) then
    raise exception 'Usuário responsável inválido.';
  end if;

  select *
    into ka
  from public.kanban_assignments
  where ficha_id = _ficha_id
  for update;

  if ka.ficha_id is null then
    raise exception 'Ficha não encontrada no Kanban.';
  end if;

  select *
    into current_stage
  from public.stages
  where id = ka.stage_id;

  select *
    into target
  from public.stages
  where id = _new_stage_id
    and sector_id = ka.sector_id
    and active;

  if target.id is null then
    raise exception 'A etapa de destino não pertence ao setor ou está inativa.';
  end if;

  if target.id = ka.stage_id then
    raise exception 'A ficha já está nesta etapa.';
  end if;

  movement := case
    when target.position < current_stage.position then 'retorno'
    else 'avanco'
  end;

  if movement = 'retorno' then
    if coalesce(trim(_return_reason_category), '') = '' then
      raise exception 'Selecione o motivo do retorno da etapa.';
    end if;

    if coalesce(trim(_observation), '') = '' then
      raise exception 'Descreva o motivo do retorno da etapa.';
    end if;

    update public.kanban_assignments
       set stage_id = target.id,
           entered_stage_at = now(),
           last_changed_by = _changed_by,
           completed_at = null,
           production_started_at = coalesce(production_started_at, now()),
           production_returned = true,
           return_count = return_count + 1,
           last_return_reason_category = trim(_return_reason_category),
           last_return_reason = trim(_observation),
           last_returned_at = now(),
           last_returned_by = _changed_by,
           updated_at = now()
     where ficha_id = _ficha_id;
  else
    update public.kanban_assignments
       set stage_id = target.id,
           entered_stage_at = now(),
           last_changed_by = _changed_by,
           completed_at = case when target.is_final then now() else null end,
           production_started_at = coalesce(production_started_at, now()),
           updated_at = now()
     where ficha_id = _ficha_id;
  end if;

  insert into public.status_history(
    ficha_id,
    sector_id,
    previous_stage_id,
    new_stage_id,
    changed_by_user_id,
    performed_by_user_id,
    changed_at,
    observation,
    source,
    movement_type,
    return_reason_category,
    return_reason
  )
  values(
    _ficha_id,
    ka.sector_id,
    ka.stage_id,
    target.id,
    _changed_by,
    auth.uid(),
    now(),
    nullif(trim(_observation), ''),
    coalesce(_source, 'kanban'),
    movement,
    case
      when movement = 'retorno'
      then nullif(trim(_return_reason_category), '')
      else null
    end,
    case
      when movement = 'retorno'
      then nullif(trim(_observation), '')
      else null
    end
  )
  returning id into history_id;

  return history_id;
end;
$function$;

revoke execute on function public.transition_ficha(uuid,uuid,uuid,text,text,text) from public, anon;
grant execute on function public.transition_ficha(uuid,uuid,uuid,text,text,text) to authenticated, service_role;

-- Ask PostgREST to refresh its function schema cache immediately.
notify pgrst, 'reload schema';
