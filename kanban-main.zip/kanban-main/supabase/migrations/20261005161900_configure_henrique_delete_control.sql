-- Keep the administrative delete control aligned with the primary account.
update public.profiles
set full_name='Henrique',
    active=true,
    email='dynatecompras@gmail.com',
    updated_at=now()
where lower(email)=lower('dynatecompras@gmail.com');

insert into public.user_roles(user_id,role)
select p.id,'admin'::public.app_role
from public.profiles p
where lower(p.email)=lower('dynatecompras@gmail.com')
and not exists (
  select 1 from public.user_roles ur
  where ur.user_id=p.id and ur.role='admin'::public.app_role
);

insert into private.kanban_delete_authorizers(profile_id,created_by)
select p.id,p.id
from public.profiles p
where lower(p.email)=lower('dynatecompras@gmail.com')
on conflict (profile_id) do nothing;

update private.kanban_security
set delete_pin_hash=crypt(chr(48)||chr(49)||chr(50)||chr(51),gen_salt('bf')),
    manager_emails=array['dynatecompras@gmail.com','dynatec.adm@gmail.com']::text[],
    updated_at=now()
where singleton;
