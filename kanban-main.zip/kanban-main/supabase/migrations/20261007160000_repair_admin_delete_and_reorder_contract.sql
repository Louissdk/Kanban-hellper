-- Repair administrative deletion authorization and the stage-card reorder contract.
-- Keeps the existing delete_ficha, status_history and transition_ficha architecture.

create or replace function public.get_delete_authorizers()
returns table(
  profile_id uuid,
  full_name text,
  email text,
  active boolean
)
language sql
security definer
set search_path = public, private
as $function$
  select p.id, p.full_name, p.email, p.active
  from public.profiles p
  where p.active
    and public.has_role(p.id, 'admin')
    and public.has_role(auth.uid(), 'admin')
  order by p.full_name
$function$;

revoke execute on function public.get_delete_authorizers() from public, anon;
grant execute on function public.get_delete_authorizers() to authenticated, service_role;

create or replace function public.delete_ficha(
  _ficha_id uuid,
  _authorized_profile_id uuid,
  _pin text
)
returns uuid
language plpgsql
security definer
set search_path = public, private
as $function$
declare
  f public.fichas%rowtype;
  ka public.kanban_assignments%rowtype;
  items jsonb;
  history jsonb;
  result_id uuid;
  group_id uuid;
begin
  if not public.has_role(auth.uid(), 'admin') then
    raise exception 'Apenas administradores podem excluir pedidos.';
  end if;

  if not exists(
    select 1
    from public.profiles p
    where p.id = _authorized_profile_id
      and p.active
      and public.has_role(p.id, 'admin')
  ) then
    raise exception 'O perfil selecionado não está autorizado para exclusão.';
  end if;

  if not exists(
    select 1
    from private.kanban_security
    where singleton
      and delete_pin_hash = crypt(coalesce(_pin,''), delete_pin_hash)
  ) then
    raise exception 'PIN de exclusão inválido.';
  end if;

  select * into f
  from public.fichas
  where id = _ficha_id
  for update;

  if f.id is null then
    raise exception 'Pedido não encontrado.';
  end if;

  group_id := f.duplicate_group_id;

  select * into ka
  from public.kanban_assignments
  where ficha_id = f.id;

  select coalesce(jsonb_agg(to_jsonb(i) order by i.line_no), '[]'::jsonb)
    into items
  from public.ficha_items i
  where i.ficha_id = f.id;

  select coalesce(jsonb_agg(to_jsonb(h) order by h.changed_at), '[]'::jsonb)
    into history
  from public.status_history h
  where h.ficha_id = f.id;

  insert into public.ficha_deletion_history(
    ficha_id,
    order_number,
    deleted_by_user_id,
    authorized_profile_id,
    record_snapshot
  )
  values(
    f.id,
    f.order_number,
    auth.uid(),
    _authorized_profile_id,
    jsonb_build_object(
      'ficha', to_jsonb(f),
      'kanban_assignment', to_jsonb(ka),
      'items', items,
      'status_history', history,
      'deleted_at', now()
    )
  );

  delete from public.fichas
  where id = f.id
  returning id into result_id;

  if group_id is not null then
    update public.fichas
       set duplicate_group_id = null,
           updated_at = now()
     where duplicate_group_id = group_id
       and not exists(
         select 1
         from public.fichas f2
         where f2.duplicate_group_id = group_id
           and f2.id <> public.fichas.id
       );
  end if;

  return result_id;
end
$function$;

revoke execute on function public.delete_ficha(uuid, uuid, text) from public, anon;
grant execute on function public.delete_ficha(uuid, uuid, text) to authenticated, service_role;

alter table public.kanban_assignments
  add column if not exists sort_order integer;

create index if not exists idx_kanban_assignments_stage_sort
  on public.kanban_assignments(sector_id, stage_id, sort_order, updated_at);

create or replace function public.reorder_kanban_stage(
  _sector_id uuid,
  _stage_id uuid,
  _ordered_ficha_ids uuid[]
)
returns void
language plpgsql
security definer
set search_path = public
as $function$
declare
  idx integer;
  v_ficha_id uuid;
begin
  if not public.can_operate(auth.uid()) then
    raise exception 'Usuário sem permissão para reordenar fichas.';
  end if;

  if not exists(
    select 1 from public.stages
    where id = _stage_id
      and sector_id = _sector_id
      and active
  ) then
    raise exception 'A etapa informada não pertence ao setor ou está inativa.';
  end if;

  if coalesce(array_length(_ordered_ficha_ids, 1), 0) = 0 then
    return;
  end if;

  if exists(
    select 1
    from unnest(_ordered_ficha_ids) x
    where x is null
       or not exists(
         select 1
         from public.kanban_assignments ka
         where ka.ficha_id = x
           and ka.sector_id = _sector_id
           and ka.stage_id = _stage_id
       )
  ) then
    raise exception 'A ordem contém ficha que não pertence à etapa informada.';
  end if;

  for idx in 1..array_length(_ordered_ficha_ids, 1) loop
    v_ficha_id := _ordered_ficha_ids[idx];
    update public.kanban_assignments ka
       set sort_order = idx,
           updated_at = now()
     where ka.ficha_id = v_ficha_id;
  end loop;
end
$function$;

revoke execute on function public.reorder_kanban_stage(uuid, uuid, uuid[]) from public, anon;
grant execute on function public.reorder_kanban_stage(uuid, uuid, uuid[]) to authenticated, service_role;
