
-- Reuses the existing smb_admin_changes audit table and current production architecture.
do $block$
declare
  v_sector uuid;
  v_pedido uuid;
  v_corte uuid;
begin
  select id into v_sector from public.sectors where lower(trim(name))='cartucho' limit 1;
  if v_sector is null then return; end if;

  select id into v_pedido from public.stages
    where sector_id=v_sector and lower(trim(name))='pedido na fabrica' limit 1;
  select id into v_corte from public.stages
    where sector_id=v_sector and lower(trim(name))='corte de porcelana' limit 1;

  if v_pedido is null then
    if v_corte is null then
      select id into v_corte from public.stages where sector_id=v_sector order by position limit 1;
      if v_corte is not null then
        update public.stages set name='Corte de porcelana', updated_at=now() where id=v_corte;
      end if;
    end if;

    update public.stages set position=position+1 where sector_id=v_sector;
    insert into public.stages(id,sector_id,name,position,active,is_final,color)
      values(gen_random_uuid(),v_sector,'Pedido na fabrica',1,true,false,null);
    select id into v_pedido from public.stages
      where sector_id=v_sector and lower(trim(name))='pedido na fabrica' limit 1;
  else
    update public.stages set position=1,updated_at=now() where id=v_pedido;
    if v_corte is not null then
      update public.stages set position=2,updated_at=now() where id=v_corte;
    end if;
  end if;

  if v_pedido is not null and v_corte is not null then
    insert into public.status_history(
      ficha_id,sector_id,previous_stage_id,new_stage_id,changed_at,observation,source,movement_type
    )
    select ka.ficha_id,ka.sector_id,v_corte,v_pedido,now(),
      'Reorganização do fluxo: Corte de porcelana → Pedido na fabrica.','system','avanco'
    from public.kanban_assignments ka
    where ka.stage_id=v_corte
      and not exists (
        select 1 from public.status_history h
        where h.ficha_id=ka.ficha_id
          and h.previous_stage_id=v_corte
          and h.new_stage_id=v_pedido
          and h.observation='Reorganização do fluxo: Corte de porcelana → Pedido na fabrica.'
      );

    update public.kanban_assignments
    set stage_id=v_pedido,entered_stage_at=now(),updated_at=now()
    where stage_id=v_corte;
  end if;
end
$block$;

alter table public.smb_admin_changes alter column ficha_id drop not null;
alter table public.smb_admin_changes drop constraint if exists smb_admin_changes_ficha_id_fkey;
alter table public.smb_admin_changes
  add constraint smb_admin_changes_ficha_id_fkey
  foreign key (ficha_id) references public.fichas(id) on delete set null;

alter table public.smb_admin_changes enable row level security;
revoke all on public.smb_admin_changes from anon,authenticated;
grant select on public.smb_admin_changes to authenticated;

drop policy if exists "Authenticated users can view SMB administrative changes" on public.smb_admin_changes;
create policy "Authenticated users can view SMB administrative changes"
on public.smb_admin_changes for select to authenticated using (true);
;

CREATE OR REPLACE FUNCTION public.first_active_stage(_sector_id uuid)
 RETURNS uuid
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select st.id
  from public.stages st
  join public.sectors sec on sec.id=st.sector_id
  where st.sector_id=_sector_id and st.active
  order by
    case
      when lower(trim(sec.name))='cartucho' and lower(trim(st.name))='pedido na fabrica' then 0
      else 1
    end,
    st.position,
    st.name
  limit 1
$function$

;

CREATE OR REPLACE FUNCTION private.record_smb_ficha_change(_old fichas, _new fichas, _source text, _actor_type text, _actor_label text, _sync_run_id uuid)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'private', 'public', 'pg_temp'
AS $function$
declare
  c record;
  total integer := 0;
  changed_at_value timestamptz := clock_timestamp();
  old_code text := coalesce(nullif(trim(_old.customer_code),''),nullif(trim(_old.codigo_cliente),''));
  new_code text := coalesce(nullif(trim(_new.customer_code),''),nullif(trim(_new.codigo_cliente),''));
  key_value text;
begin
  for c in
    select * from (values
      ('customer','Cliente',to_jsonb(_old.customer),to_jsonb(_new.customer)),
      ('customer_code','Código do cliente',to_jsonb(old_code),to_jsonb(new_code)),
      ('seller_name','Vendedor',to_jsonb(_old.seller_name),to_jsonb(_new.seller_name)),
      ('order_number','Número do pedido',to_jsonb(_old.order_number),to_jsonb(_new.order_number)),
      ('pedido_cliente','Pedido do cliente',to_jsonb(_old.pedido_cliente),to_jsonb(_new.pedido_cliente)),
      ('opened_at','Data de abertura',to_jsonb(_old.opened_at),to_jsonb(_new.opened_at)),
      ('delivery_date','Data de entrega',to_jsonb(coalesce(_old.delivery_date,_old.data_entrega)),to_jsonb(coalesce(_new.delivery_date,_new.data_entrega))),
      ('envio','Transporte/Envio',to_jsonb(_old.envio),to_jsonb(_new.envio)),
      ('source_observations','Observações',to_jsonb(_old.source_observations),to_jsonb(_new.source_observations)),
      ('smb_status','Status SMB',to_jsonb(_old.smb_status),to_jsonb(_new.smb_status)),
      ('status_smb','Código status SMB',to_jsonb(_old.status_smb),to_jsonb(_new.status_smb)),
      ('status_smb_descricao','Descrição do status SMB',to_jsonb(_old.status_smb_descricao),to_jsonb(_new.status_smb_descricao)),
      ('product_summary','Produto',to_jsonb(_old.product_summary),to_jsonb(_new.product_summary)),
      ('quantity','Quantidade',to_jsonb(_old.quantity),to_jsonb(_new.quantity)),
      ('unit','Unidade',to_jsonb(_old.unit),to_jsonb(_new.unit)),
      ('smb_cliente_id','ID do cliente SMB',to_jsonb(_old.smb_cliente_id),to_jsonb(_new.smb_cliente_id))
    ) v(field_name,field_label,old_value,new_value)
    where old_value is distinct from new_value
  loop
    key_value := md5(
      coalesce(_source,'')||'|'||
      coalesce(_sync_run_id::text,changed_at_value::text)||'|'||
      _new.id::text||'|'||c.field_name||'|'||
      coalesce(c.old_value::text,'null')||'|'||coalesce(c.new_value::text,'null')
    );

    insert into public.smb_admin_changes(
      ficha_id,external_order_id,sync_run_id,field_name,field_label,
      old_value,new_value,change_type,source,actor_type,actor_label,
      change_key,changed_at,metadata
    )
    values(
      _new.id,coalesce(_new.external_order_id,_new.pdd_id),_sync_run_id,
      c.field_name,c.field_label,c.old_value,c.new_value,
      case when _source='SMB_SYNC' then 'SMB_UPDATE' else 'ADMIN_UPDATE' end,
      _source,_actor_type,_actor_label,key_value,changed_at_value,
      jsonb_build_object('audit','ficha','source',_source)
    )
    on conflict(change_key) do nothing;

    if found then total := total + 1; end if;
  end loop;

  return total;
end
$function$

;

CREATE OR REPLACE FUNCTION private.record_smb_item_changes(_ficha_id uuid, _external_order_id text, _sync_run_id uuid, _items jsonb)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'private', 'public', 'pg_temp'
AS $function$
declare
  field_row record;
  pair_row record;
  total integer := 0;
  key_value text;
begin
  with old_items as (
    select i.*,
      case
        when nullif(trim(i.pdd_id),'') is not null then 'pdd:'||upper(trim(i.pdd_id))||':'||i.line_no::text
        when nullif(trim(i.code),'') is not null then 'code:'||upper(trim(i.code))||':'||i.line_no::text
        else 'line:'||i.line_no::text
      end as item_key
    from public.ficha_items i
    where i.ficha_id=_ficha_id
  ),
  new_items as (
    select
      coalesce(nullif(trim(coalesce(v->>'sequencia',v->>'sequence',v->>'item_sequence')),'')::integer,ord::integer) as line_no,
      nullif(trim(coalesce(v->>'codigo',v->>'code')),'') as code,
      nullif(trim(coalesce(v->>'produto',v->>'product')),'') as product,
      nullif(trim(coalesce(v->>'descricao',v->>'description')),'') as description,
      case when nullif(trim(coalesce(v->>'quantidade',v->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
        then replace(coalesce(v->>'quantidade',v->>'quantity'),',','.')::numeric else null end as quantity,
      nullif(trim(coalesce(v->>'unidade',v->>'unit')),'') as unit,
      case
        when nullif(trim(_external_order_id),'') is not null then 'pdd:'||upper(trim(_external_order_id))||':'||coalesce(nullif(trim(coalesce(v->>'sequencia',v->>'sequence',v->>'item_sequence')),'')::integer,ord::integer)::text
        when nullif(trim(coalesce(v->>'codigo',v->>'code')),'') is not null then 'code:'||upper(trim(coalesce(v->>'codigo',v->>'code')))||':'||coalesce(nullif(trim(coalesce(v->>'sequencia',v->>'sequence',v->>'item_sequence')),'')::integer,ord::integer)::text
        else 'line:'||coalesce(nullif(trim(coalesce(v->>'sequencia',v->>'sequence',v->>'item_sequence')),'')::integer,ord::integer)::text
      end as item_key
    from jsonb_array_elements(coalesce(_items,'[]'::jsonb)) with ordinality a(v,ord)
  ),
  paired as (
    select
      n.item_key as new_key,n.line_no as new_line_no,n.code as new_code,n.product as new_product,n.description as new_description,n.quantity as new_quantity,n.unit as new_unit,
      o.item_key as old_key,o.line_no as old_line_no,o.code as old_code,o.product as old_product,o.description as old_description,o.quantity as old_quantity,o.unit as old_unit
    from old_items o
    join new_items n on n.item_key=o.item_key
  )
  select * into pair_row from paired limit 1;

  if pair_row.new_key is null then
    -- No matched item; additions/removals are still handled by the set comparison below.
    null;
  end if;

  insert into public.smb_admin_changes(
    ficha_id,external_order_id,sync_run_id,field_name,field_label,old_value,new_value,change_type,source,actor_type,actor_label,
    item_line_no,change_key,changed_at,metadata
  )
  with old_items as (
    select i.*,
      case
        when nullif(trim(i.pdd_id),'') is not null then 'pdd:'||upper(trim(i.pdd_id))||':'||i.line_no::text
        when nullif(trim(i.code),'') is not null then 'code:'||upper(trim(i.code))||':'||i.line_no::text
        else 'line:'||i.line_no::text
      end as item_key
    from public.ficha_items i where i.ficha_id=_ficha_id
  ),
  new_items as (
    select
      coalesce(nullif(trim(coalesce(v->>'sequencia',v->>'sequence',v->>'item_sequence')),'')::integer,ord::integer) as line_no,
      nullif(trim(coalesce(v->>'codigo',v->>'code')),'') as code,
      nullif(trim(coalesce(v->>'produto',v->>'product')),'') as product,
      nullif(trim(coalesce(v->>'descricao',v->>'description')),'') as description,
      case when nullif(trim(coalesce(v->>'quantidade',v->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
        then replace(coalesce(v->>'quantidade',v->>'quantity'),',','.')::numeric else null end as quantity,
      nullif(trim(coalesce(v->>'unidade',v->>'unit')),'') as unit,
      case
        when nullif(trim(_external_order_id),'') is not null then 'pdd:'||upper(trim(_external_order_id))||':'||coalesce(nullif(trim(coalesce(v->>'sequencia',v->>'sequence',v->>'item_sequence')),'')::integer,ord::integer)::text
        when nullif(trim(coalesce(v->>'codigo',v->>'code')),'') is not null then 'code:'||upper(trim(coalesce(v->>'codigo',v->>'code')))||':'||coalesce(nullif(trim(coalesce(v->>'sequencia',v->>'sequence',v->>'item_sequence')),'')::integer,ord::integer)::text
        else 'line:'||coalesce(nullif(trim(coalesce(v->>'sequencia',v->>'sequence',v->>'item_sequence')),'')::integer,ord::integer)::text
      end as item_key
    from jsonb_array_elements(coalesce(_items,'[]'::jsonb)) with ordinality a(v,ord)
  )
  select _ficha_id,_external_order_id,_sync_run_id,'item',
    case when n.item_key is not null then 'Item adicionado' else 'Item removido' end,
    case when n.item_key is not null then null else jsonb_build_object('line_no',o.line_no,'code',o.code,'product',o.product,'description',o.description,'quantity',o.quantity,'unit',o.unit) end,
    case when n.item_key is not null then jsonb_build_object('line_no',n.line_no,'code',n.code,'product',n.product,'description',n.description,'quantity',n.quantity,'unit',n.unit) else null end,
    case when n.item_key is not null then 'SMB_ITEM_ADDED' else 'SMB_ITEM_REMOVED' end,
    'SMB_SYNC','ROBOT_SMB','Robô SMB',coalesce(n.line_no,o.line_no),
    md5(case when n.item_key is not null then 'SMB_ITEM_ADDED|' else 'SMB_ITEM_REMOVED|' end||_sync_run_id::text||'|'||_ficha_id::text||'|'||coalesce(n.item_key,o.item_key)),
    clock_timestamp(),jsonb_build_object('item_key',coalesce(n.item_key,o.item_key),'audit','item')
  from old_items o
  full join new_items n on n.item_key=o.item_key
  where n.item_key is null or o.item_key is null
  on conflict(change_key) do nothing;
  get diagnostics total = row_count;

  for pair_row in
    with old_items as (
      select i.*,
        case
          when nullif(trim(i.pdd_id),'') is not null then 'pdd:'||upper(trim(i.pdd_id))||':'||i.line_no::text
          when nullif(trim(i.code),'') is not null then 'code:'||upper(trim(i.code))||':'||i.line_no::text
          else 'line:'||i.line_no::text
        end as item_key
      from public.ficha_items i where i.ficha_id=_ficha_id
    ),
    new_items as (
      select
        coalesce(nullif(trim(coalesce(v->>'sequencia',v->>'sequence',v->>'item_sequence')),'')::integer,ord::integer) as line_no,
        nullif(trim(coalesce(v->>'codigo',v->>'code')),'') as code,
        nullif(trim(coalesce(v->>'produto',v->>'product')),'') as product,
        nullif(trim(coalesce(v->>'descricao',v->>'description')),'') as description,
        case when nullif(trim(coalesce(v->>'quantidade',v->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
          then replace(coalesce(v->>'quantidade',v->>'quantity'),',','.')::numeric else null end as quantity,
        nullif(trim(coalesce(v->>'unidade',v->>'unit')),'') as unit,
        case
          when nullif(trim(_external_order_id),'') is not null then 'pdd:'||upper(trim(_external_order_id))||':'||coalesce(nullif(trim(coalesce(v->>'sequencia',v->>'sequence',v->>'item_sequence')),'')::integer,ord::integer)::text
          when nullif(trim(coalesce(v->>'codigo',v->>'code')),'') is not null then 'code:'||upper(trim(coalesce(v->>'codigo',v->>'code')))||':'||coalesce(nullif(trim(coalesce(v->>'sequencia',v->>'sequence',v->>'item_sequence')),'')::integer,ord::integer)::text
          else 'line:'||coalesce(nullif(trim(coalesce(v->>'sequencia',v->>'sequence',v->>'item_sequence')),'')::integer,ord::integer)::text
        end as item_key
      from jsonb_array_elements(coalesce(_items,'[]'::jsonb)) with ordinality a(v,ord)
    )
    select o.line_no old_line_no,o.code old_code,o.product old_product,o.description old_description,o.quantity old_quantity,o.unit old_unit,o.item_key old_key,
           n.line_no new_line_no,n.code new_code,n.product new_product,n.description new_description,n.quantity new_quantity,n.unit new_unit,n.item_key new_key
    from old_items o join new_items n on n.item_key=o.item_key
  loop
    for field_row in
      select * from (values
        ('code','Código do item alterado',to_jsonb(pair_row.old_code),to_jsonb(pair_row.new_code)),
        ('product','Produto do item alterado',to_jsonb(pair_row.old_product),to_jsonb(pair_row.new_product)),
        ('description','Descrição do item alterada',to_jsonb(pair_row.old_description),to_jsonb(pair_row.new_description)),
        ('quantity','Quantidade do item alterada',to_jsonb(pair_row.old_quantity),to_jsonb(pair_row.new_quantity)),
        ('unit','Unidade do item alterada',to_jsonb(pair_row.old_unit),to_jsonb(pair_row.new_unit))
      ) v(field_name,field_label,old_value,new_value)
      where old_value is distinct from new_value
    loop
      key_value:=md5('SMB_ITEM_UPDATE|'||_sync_run_id::text||'|'||_ficha_id::text||'|'||pair_row.new_key||'|'||field_row.field_name||'|'||coalesce(field_row.old_value::text,'null')||'|'||coalesce(field_row.new_value::text,'null'));
      insert into public.smb_admin_changes(
        ficha_id,external_order_id,sync_run_id,field_name,field_label,old_value,new_value,change_type,source,actor_type,actor_label,item_line_no,change_key,changed_at,metadata
      )
      values(
        _ficha_id,_external_order_id,_sync_run_id,'item.'||field_row.field_name,field_row.field_label,field_row.old_value,field_row.new_value,
        'SMB_ITEM_UPDATE','SMB_SYNC','ROBOT_SMB','Robô SMB',pair_row.new_line_no,key_value,clock_timestamp(),
        jsonb_build_object('item_key',pair_row.new_key,'audit','item')
      )
      on conflict(change_key) do nothing;
      if found then total:=total+1; end if;
    end loop;
  end loop;

  return total;
end
$function$

;

CREATE OR REPLACE FUNCTION private.record_smb_item_admin_update(_old ficha_items, _new ficha_items, _actor_label text)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'private', 'public', 'pg_temp'
AS $function$
declare
  c record;
  total integer:=0;
  key_value text;
begin
  for c in
    select * from (values
      ('code','Código do item alterado',to_jsonb(_old.code),to_jsonb(_new.code)),
      ('product','Produto do item alterado',to_jsonb(_old.product),to_jsonb(_new.product)),
      ('description','Descrição do item alterada',to_jsonb(_old.description),to_jsonb(_new.description)),
      ('quantity','Quantidade do item alterada',to_jsonb(_old.quantity),to_jsonb(_new.quantity)),
      ('unit','Unidade do item alterada',to_jsonb(_old.unit),to_jsonb(_new.unit)),
      ('line_no','Linha do item alterada',to_jsonb(_old.line_no),to_jsonb(_new.line_no))
    ) v(field_name,field_label,old_value,new_value)
    where old_value is distinct from new_value
  loop
    key_value:=md5('KANBAN_ADMIN|ITEM_UPDATE|'||_new.id::text||'|'||c.field_name||'|'||
      coalesce(c.old_value::text,'null')||'|'||coalesce(c.new_value::text,'null')||'|'||clock_timestamp()::text);
    insert into public.smb_admin_changes(
      ficha_id,external_order_id,field_name,field_label,old_value,new_value,
      change_type,source,actor_type,actor_label,item_line_no,change_key,changed_at,metadata
    )
    select _new.ficha_id,f.external_order_id,'item.'||c.field_name,c.field_label,c.old_value,c.new_value,
      'ADMIN_ITEM_UPDATE','KANBAN_ADMIN','USER',coalesce(_actor_label,'Usuário administrativo'),
      _new.line_no,key_value,clock_timestamp(),jsonb_build_object('audit','item','item_id',_new.id)
    from public.fichas f where f.id=_new.ficha_id
    on conflict(change_key) do nothing;
    if found then total:=total+1; end if;
  end loop;
  return total;
end
$function$

;

CREATE OR REPLACE FUNCTION private.audit_ficha_admin_update()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'private', 'public', 'pg_temp'
AS $function$
declare
  source_value text := nullif(current_setting('app.smb_audit_source',true),'');
  run_value text := nullif(current_setting('app.smb_audit_run_id',true),'');
  actor_type_value text := nullif(current_setting('app.smb_audit_actor_type',true),'');
  actor_label_value text := nullif(current_setting('app.smb_audit_actor_label',true),'');
  profile_name text;
begin
  if source_value='SMB_SYNC' then
    perform private.record_smb_ficha_change(old,new,'SMB_SYNC','ROBOT_SMB',coalesce(actor_label_value,'Robô SMB'),nullif(run_value,'')::uuid);
    return new;
  end if;

  if auth.uid() is null or not public.has_role(auth.uid(),'admin') then return new; end if;

  select nullif(trim(p.full_name),'') into profile_name from public.profiles p where p.id=auth.uid();
  perform private.record_smb_ficha_change(old,new,'KANBAN_ADMIN','USER',coalesce(profile_name,'Usuário administrativo'),null);
  return new;
end
$function$

;

CREATE OR REPLACE FUNCTION private.audit_ficha_item_admin_change()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'private', 'public', 'pg_temp'
AS $function$
declare
  profile_name text;
  key_value text;
begin
  if auth.uid() is null or not public.has_role(auth.uid(),'admin') then return case when tg_op='DELETE' then old else new end; end if;
  select nullif(trim(p.full_name),'') into profile_name from public.profiles p where p.id=auth.uid();

  if tg_op='INSERT' then
    key_value:=md5('KANBAN_ADMIN|ITEM_ADDED|'||new.id::text||'|'||clock_timestamp()::text);
    insert into public.smb_admin_changes(
      ficha_id,external_order_id,field_name,field_label,old_value,new_value,
      change_type,source,actor_type,actor_label,item_line_no,change_key,changed_at,metadata
    )
    select new.ficha_id,f.external_order_id,'item','Item adicionado',null,to_jsonb(new),
      'ADMIN_ITEM_ADDED','KANBAN_ADMIN','USER',coalesce(profile_name,'Usuário administrativo'),
      new.line_no,key_value,clock_timestamp(),jsonb_build_object('audit','item','item_id',new.id)
    from public.fichas f where f.id=new.ficha_id
    on conflict(change_key) do nothing;
  elsif tg_op='DELETE' then
    key_value:=md5('KANBAN_ADMIN|ITEM_REMOVED|'||old.id::text||'|'||clock_timestamp()::text);
    insert into public.smb_admin_changes(
      ficha_id,external_order_id,field_name,field_label,old_value,new_value,
      change_type,source,actor_type,actor_label,item_line_no,change_key,changed_at,metadata
    )
    select old.ficha_id,f.external_order_id,'item','Item removido',to_jsonb(old),null,
      'ADMIN_ITEM_REMOVED','KANBAN_ADMIN','USER',coalesce(profile_name,'Usuário administrativo'),
      old.line_no,key_value,clock_timestamp(),jsonb_build_object('audit','item','item_id',old.id)
    from public.fichas f where f.id=old.ficha_id
    on conflict(change_key) do nothing;
  else
    perform private.record_smb_item_admin_update(old,new,profile_name);
  end if;
  return new;
end
$function$

;

drop trigger if exists trg_audit_ficha_admin_update on public.fichas;
create trigger trg_audit_ficha_admin_update
after update of customer,customer_code,codigo_cliente,seller_name,order_number,pedido_cliente,opened_at,delivery_date,data_entrega,envio,source_observations,smb_status,status_smb,status_smb_descricao,product_summary,quantity,unit,smb_cliente_id
on public.fichas
for each row execute function private.audit_ficha_admin_update();

drop trigger if exists trg_audit_ficha_item_admin_change on public.ficha_items;
create trigger trg_audit_ficha_item_admin_change
after insert or update or delete on public.ficha_items
for each row execute function private.audit_ficha_item_admin_change();

revoke execute on function private.record_smb_ficha_change(public.fichas,public.fichas,text,text,text,uuid) from public,anon,authenticated;
revoke execute on function private.record_smb_item_changes(uuid,text,uuid,jsonb) from public,anon,authenticated;
revoke execute on function private.record_smb_item_admin_update(public.ficha_items,public.ficha_items,text) from public,anon,authenticated;
revoke execute on function private.audit_ficha_admin_update() from public,anon,authenticated;
revoke execute on function private.audit_ficha_item_admin_change() from public,anon,authenticated;
;

CREATE OR REPLACE FUNCTION public.process_smb_sync_result(_sync_run_id uuid, _result jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  run_row public.sync_runs%rowtype;
  order_row record;
  item jsonb;
  f_id uuid;
  target_stage uuid;
  import_sector_id uuid;
  customer_name text;
  resolved_customer_code text;
  customer_matches integer;
  pdd text;
  customer_order_number text;
  seller_value text;
  opened_value timestamptz;
  delivery_value date;
  normalized_status text;
  status_code text;
  status_description text;
  status_is_completed boolean;
  order_items jsonb;
  item_count integer;
  derived_product_summary text;
  derived_quantity numeric;
  derived_unit text;
  created_count integer := 0;
  updated_count integer := 0;
  ignored_count integer := 0;
  eligible_count integer := 0;
  error_count integer := 0;
  warning_count integer := 0;
  error_messages text[] := '{}';
  ranking_value integer;
  existing_stage_id uuid;
  existing_sector_id uuid;
  sequence_value integer;
  fallback_matches integer := 0;
begin
  if coalesce(current_setting('request.jwt.claims',true)::jsonb->>'role','') <> 'service_role' then
    raise exception 'Somente o serviço de integração pode processar resultados do robô.';
  end if;

  select * into run_row from public.sync_runs where id=_sync_run_id for update;
  if run_row.id is null then raise exception 'Execução de sincronização não encontrada.'; end if;
  if run_row.status not in ('requested','running') then
    raise exception 'A execução de sincronização não está aguardando processamento.';
  end if;

  perform set_config('app.smb_audit_source','SMB_SYNC',true);
  perform set_config('app.smb_audit_run_id',_sync_run_id::text,true);
  perform set_config('app.smb_audit_actor_type','ROBOT_SMB',true);
  perform set_config('app.smb_audit_actor_label','Robô SMB',true);

  update public.sync_runs
  set status='running',started_at=coalesce(started_at,now()),
      robot_status='available',robot_message=null,error_message=null
  where id=_sync_run_id;

  select s.id into import_sector_id
  from public.sectors s
  where s.active and s.is_default_import
  order by s.position
  limit 1;

  create temporary table if not exists tmp_smb_orders(
    external_order_id text,customer_order_number text,customer text,smb_cliente_id text,
    seller text,opened_at timestamptz,delivery_date date,envio text,
    status_smb text,status_smb_descricao text,ranking integer,
    source_observations text,source_hash text,product_summary text,
    quantity numeric,unit text,items jsonb
  ) on commit drop;

  truncate tmp_smb_orders;

  insert into tmp_smb_orders(
    external_order_id,customer_order_number,customer,smb_cliente_id,seller,
    opened_at,delivery_date,envio,status_smb,status_smb_descricao,ranking,
    source_observations,source_hash,product_summary,quantity,unit,items
  )
  select
    nullif(trim(coalesce(raw->>'external_order_id',raw->>'pdd_id')),''),
    nullif(trim(coalesce(raw->>'pedido_cliente',raw->>'customer_order_number',raw->>'order_number')),''),
    nullif(trim(coalesce(raw->'cliente'->>'nome',raw->>'customer')),''),
    nullif(trim(coalesce(raw->'cliente'->>'smb_cliente_id',raw->>'smb_cliente_id')),''),
    nullif(trim(coalesce(raw->>'vendedor',raw->>'seller')),''),
    public.parse_smb_datetime(coalesce(raw->>'abertura',raw->>'opened_at')),
    public.parse_smb_date(coalesce(raw->>'data_entrega',raw->>'delivery_date')),
    nullif(trim(coalesce(raw->>'envio',raw->>'shipping')),''),
    upper(trim(coalesce(raw->>'status_smb',raw->>'smb_status',''))),
    nullif(trim(coalesce(raw->>'status_smb_descricao',raw->>'smb_status_descricao')),''),
    case
      when nullif(trim(coalesce(raw->>'ranking',raw->>'rank')),'') ~ '^\d+$'
      then (coalesce(raw->>'ranking',raw->>'rank'))::integer
      else null
    end,
    nullif(trim(coalesce(raw->>'observacoes',raw->>'source_observations')),''),
    nullif(trim(raw->>'source_hash'),''),
    nullif(trim(raw->>'product_summary'),''),
    case when nullif(trim(raw->>'quantity'),'') is null then null else (raw->>'quantity')::numeric end,
    nullif(trim(raw->>'unit'),''),
    case
      when jsonb_typeof(raw->'itens')='array' then raw->'itens'
      when jsonb_typeof(raw->'items')='array' then raw->'items'
      else '[]'::jsonb
    end
  from jsonb_array_elements(coalesce(_result->'orders','[]'::jsonb)) raw;

  for order_row in
    select distinct on (external_order_id) *
    from tmp_smb_orders
    where external_order_id is not null
    order by external_order_id,opened_at desc nulls last,
             jsonb_array_length(items) desc,ranking nulls last
  loop
    pdd := order_row.external_order_id;
    customer_order_number := order_row.customer_order_number;
    seller_value := order_row.seller;
    opened_value := order_row.opened_at;
    delivery_value := order_row.delivery_date;
    status_code := upper(trim(coalesce(order_row.status_smb,'')));
    status_description := upper(trim(coalesce(order_row.status_smb_descricao,'')));

    normalized_status := case
      when status_code='I' then 'INICIADO'
      when status_code='P' then 'EM PRODUÇÃO'
      when status_code='A' then 'EM ATRASO'
      when status_code='C' then 'CONCLUÍDO'
      when status_code='' and status_description='INICIADO' then 'INICIADO'
      when status_code='' and status_description='EM PRODUÇÃO' then 'EM PRODUÇÃO'
      when status_code='' and status_description='EM ATRASO' then 'EM ATRASO'
      when status_code='' and status_description='CONCLUÍDO' then 'CONCLUÍDO'
      else null
    end;

    status_is_completed := status_code='C';

    if pdd is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'Pedido sem pdd_id/external_order_id.');
      insert into public.sync_errors(
        sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
      )
      values(
        _sync_run_id,null,'error','Pedido sem pdd_id/external_order_id.',
        'missing_external_order_id','Pedido sem pdd_id/external_order_id.',now()
      );
      continue;
    end if;

    select f.id,ka.stage_id,ka.sector_id
      into f_id,existing_stage_id,existing_sector_id
    from public.fichas f
    left join public.kanban_assignments ka on ka.ficha_id=f.id
    where f.pdd_id=pdd or f.external_order_id=pdd
    limit 1;

    customer_name := order_row.customer;

    select count(*),max(c.codigo_cliente)
      into customer_matches,resolved_customer_code
    from public.clientes c
    where c.ativo=true
      and coalesce(customer_name,'')<>''
      and upper(trim(c.nome))=upper(trim(customer_name));

    if customer_matches<>1 then
      resolved_customer_code:=null;
      if customer_matches>1 then
        warning_count:=warning_count+1;
        insert into public.sync_errors(
          sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
        )
        values(
          _sync_run_id,pdd,'warning',
          'Cliente com correspondência ambígua; código mantido NULL.',
          'ambiguous_customer','Cliente com correspondência ambígua; código mantido NULL.',now()
        );
      end if;
    end if;

    if f_id is null then
      select count(*) into fallback_matches
      from public.fichas f
      where f.pdd_id is null
        and f.external_order_id is null
        and upper(trim(coalesce(f.order_number,''))) =
            upper(trim(coalesce(customer_order_number,pdd)))
        and upper(trim(coalesce(f.customer,''))) =
            upper(trim(coalesce(customer_name,'')));

      if fallback_matches = 1 then
        select f.id,ka.stage_id,ka.sector_id
          into f_id,existing_stage_id,existing_sector_id
        from public.fichas f
        left join public.kanban_assignments ka on ka.ficha_id=f.id
        where f.pdd_id is null
          and f.external_order_id is null
          and upper(trim(coalesce(f.order_number,''))) =
              upper(trim(coalesce(customer_order_number,pdd)))
          and upper(trim(coalesce(f.customer,''))) =
              upper(trim(coalesce(customer_name,'')))
        order by f.created_at
        limit 1;
      elsif fallback_matches > 1 then
        warning_count:=warning_count+1;
        ignored_count:=ignored_count+1;
        error_messages:=array_append(
          error_messages,
          '['||pdd||'] pedido não importado porque existem múltiplas fichas com o mesmo número e cliente; decisão administrativa necessária.'
        );
        insert into public.sync_errors(
          sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
        )
        values(
          _sync_run_id,pdd,'warning',
          'Pedido não importado porque existem múltiplas fichas com o mesmo número e cliente; decisão administrativa necessária.',
          'duplicate_order_number_conflict',
          'Pedido não importado porque existem múltiplas fichas com o mesmo número e cliente; decisão administrativa necessária.',
          now()
        );
        continue;
      end if;
    end if;

    order_items := order_row.items;
    select count(*) into item_count from jsonb_array_elements(order_items);

    derived_product_summary := order_row.product_summary;
    if derived_product_summary is null then
      select nullif(trim(coalesce(i.value->>'descricao',i.value->>'description',i.value->>'product')),'')
        into derived_product_summary
      from jsonb_array_elements(order_items) i(value)
      order by coalesce(
        nullif(i.value->>'sequencia','')::integer,
        nullif(i.value->>'sequence','')::integer,
        nullif(i.value->>'item_sequence','')::integer,
        999999
      )
      limit 1;
    end if;

    derived_quantity := order_row.quantity;
    if derived_quantity is null then
      select sum(
        case
          when nullif(trim(coalesce(i.value->>'quantidade',i.value->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
          then replace(coalesce(i.value->>'quantidade',i.value->>'quantity'),',','.')::numeric
          else null
        end
      ) into derived_quantity
      from jsonb_array_elements(order_items) i(value);
    end if;

    derived_unit := order_row.unit;
    if derived_unit is null and item_count=1 then
      select nullif(trim(coalesce(i.value->>'unidade',i.value->>'unit')),'')
        into derived_unit
      from jsonb_array_elements(order_items) i(value)
      limit 1;
    end if;

    if f_id is not null then
      update public.fichas f
      set pdd_id=coalesce(f.pdd_id,pdd),
          external_order_id=coalesce(f.external_order_id,pdd),
          order_number=coalesce(order_row.customer_order_number,f.order_number),
          pedido_cliente=coalesce(order_row.customer_order_number,f.pedido_cliente),
          customer=coalesce(order_row.customer,f.customer),
          smb_cliente_id=coalesce(order_row.smb_cliente_id,f.smb_cliente_id),
          seller_name=coalesce(order_row.seller,f.seller_name),
          product_summary=coalesce(derived_product_summary,f.product_summary),
          quantity=coalesce(derived_quantity,f.quantity),
          unit=coalesce(derived_unit,f.unit),
          opened_at=coalesce(order_row.opened_at,f.opened_at),
          order_date=coalesce(order_row.opened_at::date,f.order_date),
          delivery_date=coalesce(delivery_value,f.delivery_date),
          data_entrega=coalesce(delivery_value,f.data_entrega),
          envio=coalesce(order_row.envio,f.envio),
          status_smb=case when status_code<>'' then status_code else f.status_smb end,
          status_smb_descricao=coalesce(nullif(trim(order_row.status_smb_descricao),''),f.status_smb_descricao),
          smb_status=coalesce(normalized_status,f.smb_status),
          codigo_cliente=coalesce(
            nullif(trim(f.codigo_cliente),''),
            nullif(trim(f.customer_code),''),
            resolved_customer_code
          ),
          customer_code=coalesce(
            nullif(trim(f.customer_code),''),
            nullif(trim(f.codigo_cliente),''),
            resolved_customer_code
          ),
          smb_ranking=coalesce(order_row.ranking,f.smb_ranking),
          source_observations=coalesce(order_row.source_observations,f.source_observations),
          source_system='SMB',
          source_synced_at=now(),
          source_hash=coalesce(order_row.source_hash,f.source_hash),
          sync_state='active',
          sync_warning=case
            when fallback_matches > 0 then 'Ficha manual vinculada ao pedido SMB automaticamente.'
            when customer_matches>1 then 'Código do cliente não resolvido: múltiplas correspondências.'
            when customer_matches=0 and coalesce(customer_name,'')<>'' then 'Código do cliente não resolvido: cliente não encontrado.'
            else null
          end,
          updated_at=now()
      where f.id=f_id;

      perform private.record_smb_item_changes(f_id,pdd,_sync_run_id,order_items);

      delete from public.ficha_items where ficha_id=f_id;

      for item in select value from jsonb_array_elements(order_items)
      loop
        sequence_value:=coalesce(
          nullif(item->>'sequencia','')::integer,
          nullif(item->>'sequence','')::integer,
          nullif(item->>'item_sequence','')::integer
        );
        if sequence_value is null then
          sequence_value:=coalesce(
            (select max(line_no)+1 from public.ficha_items where ficha_id=f_id),
            1
          );
        end if;

        insert into public.ficha_items(
          ficha_id,pdd_id,line_no,code,product,description,quantity,unit
        )
        values(
          f_id,pdd,sequence_value,
          nullif(trim(coalesce(item->>'codigo',item->>'code')),''),
          nullif(trim(coalesce(item->>'produto',item->>'product')),''),
          nullif(trim(coalesce(item->>'descricao',item->>'description')),''),
          case
            when nullif(trim(coalesce(item->>'quantidade',item->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
            then replace(coalesce(item->>'quantidade',item->>'quantity'),',','.')::numeric
            else null
          end,
          nullif(trim(coalesce(item->>'unidade',item->>'unit')),'')
        );
      end loop;

      updated_count:=updated_count+1;

      if status_is_completed then
        perform public.finalize_smb_order(
          f_id,'SMB_SYNC','Pedido identificado como CONCLUÍDO no SMB.'
        );
      end if;

      continue;
    end if;

    if opened_value is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] data/hora de abertura ausente ou inválida.');
      insert into public.sync_errors(
        sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
      )
      values(
        _sync_run_id,pdd,'error',
        'Data/hora de abertura ausente ou inválida.',
        'invalid_opened_at','Data/hora de abertura ausente ou inválida.',now()
      );
      continue;
    end if;

    if opened_value::date < date '2026-09-21' then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    ranking_value:=order_row.ranking;

    if ranking_value is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] ranking não informado pelo robô.');
      insert into public.sync_errors(
        sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
      )
      values(
        _sync_run_id,pdd,'error',
        'Ranking não informado pelo robô.',
        'missing_ranking','Ranking não informado pelo robô.',now()
      );
      continue;
    end if;

    if ranking_value<=2 then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    if normalized_status is null then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    if normalized_status not in ('INICIADO','EM PRODUÇÃO','EM ATRASO') then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    if seller_value is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] vendedor ausente; pedido não pode entrar no Kanban.');
      insert into public.sync_errors(
        sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
      )
      values(
        _sync_run_id,pdd,'error',
        'Vendedor ausente; pedido não pode entrar no Kanban.',
        'missing_seller','Vendedor ausente; pedido não pode entrar no Kanban.',now()
      );
      continue;
    end if;

    if import_sector_id is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] nenhum setor de importação configurado.');
      insert into public.sync_errors(
        sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
      )
      values(
        _sync_run_id,pdd,'error',
        'Nenhum setor de importação configurado.',
        'missing_import_sector','Nenhum setor de importação configurado.',now()
      );
      continue;
    end if;

    target_stage:=public.first_active_stage(import_sector_id);

    if target_stage is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] nenhum estágio inicial ativo configurado.');
      insert into public.sync_errors(
        sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
      )
      values(
        _sync_run_id,pdd,'error',
        'Nenhum estágio inicial ativo configurado.',
        'missing_import_stage','Nenhum estágio inicial ativo configurado.',now()
      );
      continue;
    end if;

    eligible_count:=eligible_count+1;

    insert into public.fichas(
      pdd_id,external_order_id,order_number,customer,codigo_cliente,customer_code,seller_name,
      product_summary,quantity,unit,order_date,opened_at,delivery_date,
      smb_cliente_id,pedido_cliente,data_entrega,envio,status_smb,status_smb_descricao,
      smb_ranking,source_observations,source_system,source_synced_at,source_hash,
      sync_state,sync_warning,smb_status
    )
    values(
      pdd,pdd,coalesce(order_row.customer_order_number,pdd),coalesce(order_row.customer,''),
      resolved_customer_code,resolved_customer_code,order_row.seller,derived_product_summary,
      derived_quantity,derived_unit,opened_value::date,opened_value,delivery_value,
      order_row.smb_cliente_id,order_row.customer_order_number,delivery_value,order_row.envio,
      case when status_code in ('I','P','A','C') then status_code else null end,
      coalesce(nullif(trim(order_row.status_smb_descricao),''),normalized_status),
      ranking_value,order_row.source_observations,'SMB',now(),
      coalesce(order_row.source_hash,md5(order_row::text)),
      'active',
      case
        when customer_matches>1 then 'Código do cliente não resolvido: múltiplas correspondências.'
        when customer_matches=0 and coalesce(customer_name,'')<>'' then 'Código do cliente não resolvido: cliente não encontrado.'
        else null
      end,
      normalized_status
    )
    returning id into f_id;

    insert into public.kanban_assignments(ficha_id,sector_id,stage_id,priority,last_changed_by)
    values(f_id,import_sector_id,target_stage,'normal',null);

    insert into public.status_history(
      ficha_id,sector_id,previous_stage_id,new_stage_id,changed_at,observation,source,movement_type
    )
    values(
      f_id,import_sector_id,null,target_stage,now(),
      'Importado do SMB','SMB_SYNC','entrada'
    );

    for item in select value from jsonb_array_elements(order_items)
    loop
      sequence_value:=coalesce(
        nullif(item->>'sequencia','')::integer,
        nullif(item->>'sequence','')::integer,
        nullif(item->>'item_sequence','')::integer
      );
      if sequence_value is null then
        sequence_value:=coalesce(
          (select max(line_no)+1 from public.ficha_items where ficha_id=f_id),
          1
        );
      end if;

      insert into public.ficha_items(
        ficha_id,pdd_id,line_no,code,product,description,quantity,unit
      )
      values(
        f_id,pdd,sequence_value,
        nullif(trim(coalesce(item->>'codigo',item->>'code')),''),
        nullif(trim(coalesce(item->>'produto',item->>'product')),''),
        nullif(trim(coalesce(item->>'descricao',item->>'description')),''),
        case
          when nullif(trim(coalesce(item->>'quantidade',item->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
          then replace(coalesce(item->>'quantidade',item->>'quantity'),',','.')::numeric
          else null
        end,
        nullif(trim(coalesce(item->>'unidade',item->>'unit')),'')
      );
    end loop;

    created_count:=created_count+1;
  end loop;

  update public.sync_runs
  set status=case when error_count>0 or warning_count>0 then 'partial' else 'success' end,
      finished_at=now(),
      total_read=jsonb_array_length(coalesce(_result->'orders','[]'::jsonb)),
      inserted=created_count,updated=updated_count,skipped=ignored_count,
      errors=error_count,warnings=warning_count,
      orders_scanned=jsonb_array_length(coalesce(_result->'orders','[]'::jsonb)),
      orders_eligible=eligible_count,orders_created=created_count,
      orders_updated=updated_count,orders_ignored=ignored_count,
      errors_count=error_count,
      error_details=case
        when coalesce(array_length(error_messages,1),0)>0 then array_to_string(error_messages,E'\n')
        else null
      end,
      error_message=case
        when coalesce(array_length(error_messages,1),0)>0 then array_to_string(error_messages,E'\n')
        else null
      end,
      robot_status='available',
      robot_message=coalesce(
        nullif(trim(_result->>'message'),''),
        'Resultado recebido do serviço de leitura.'
      )
  where id=_sync_run_id;

  return jsonb_build_object(
    'success',error_count=0 and warning_count=0,
    'sync_run_id',_sync_run_id,
    'orders_scanned',jsonb_array_length(coalesce(_result->'orders','[]'::jsonb)),
    'orders_eligible',eligible_count,'orders_created',created_count,
    'orders_updated',updated_count,'orders_ignored',ignored_count,
    'errors_count',error_count,'warnings_count',warning_count,
    'status',case when error_count>0 or warning_count>0 then 'partial' else 'success' end
  );
end
$function$

;
revoke execute on function public.process_smb_sync_result(uuid,jsonb) from public,anon,authenticated;
grant execute on function public.process_smb_sync_result(uuid,jsonb) to service_role;
revoke execute on function public.first_active_stage(uuid) from public,anon;
grant execute on function public.first_active_stage(uuid) to authenticated,service_role;
