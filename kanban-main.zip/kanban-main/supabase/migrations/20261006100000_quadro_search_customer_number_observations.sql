-- Expand the existing finalized-card search without changing the architecture.
DROP FUNCTION IF EXISTS public.search_finalized_fichas(uuid,uuid,text,integer);

CREATE FUNCTION public.search_finalized_fichas(
  _sector_id uuid,
  _stage_id uuid,
  _query text DEFAULT '',
  _limit integer DEFAULT 100
)
RETURNS TABLE(
  ficha_id uuid,
  sector_id uuid,
  stage_id uuid,
  priority text,
  responsible_id uuid,
  entered_stage_at timestamptz,
  completed_at timestamptz,
  updated_at timestamptz,
  production_returned boolean,
  return_count integer,
  last_return_reason_category text,
  last_return_reason text,
  pdd_id text,
  order_number text,
  pedido_cliente text,
  customer text,
  codigo_cliente text,
  customer_code text,
  smb_cliente_id text,
  seller_name text,
  product_summary text,
  quantity numeric,
  unit text,
  delivery_date date,
  data_entrega date,
  envio text,
  status_smb text,
  status_smb_descricao text,
  source_observations text,
  source_system text,
  sync_state text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  select
    ka.ficha_id,ka.sector_id,ka.stage_id,ka.priority,ka.responsible_id,
    ka.entered_stage_at,ka.completed_at,ka.updated_at,ka.production_returned,
    ka.return_count,ka.last_return_reason_category,ka.last_return_reason,
    f.pdd_id,f.order_number,f.pedido_cliente,f.customer,f.codigo_cliente,
    f.customer_code,f.smb_cliente_id,f.seller_name,f.product_summary,
    f.quantity,f.unit,f.delivery_date,f.data_entrega,f.envio,f.status_smb,
    f.status_smb_descricao,f.source_observations,f.source_system,f.sync_state
  from public.kanban_assignments ka
  join public.fichas f on f.id=ka.ficha_id
  where ka.sector_id=_sector_id and ka.stage_id=_stage_id
    and f.sync_state<>'archived'
    and (
      nullif(trim(_query),'') is null
      or f.pdd_id ilike '%'||trim(_query)||'%'
      or f.external_order_id ilike '%'||trim(_query)||'%'
      or f.order_number ilike '%'||trim(_query)||'%'
      or f.pedido_cliente ilike '%'||trim(_query)||'%'
      or f.codigo_cliente ilike '%'||trim(_query)||'%'
      or f.customer_code ilike '%'||trim(_query)||'%'
      or f.customer ilike '%'||trim(_query)||'%'
      or f.seller_name ilike '%'||trim(_query)||'%'
      or f.smb_cliente_id ilike '%'||trim(_query)||'%'
      or f.product_summary ilike '%'||trim(_query)||'%'
      or f.source_observations ilike '%'||trim(_query)||'%'
      or exists (
        select 1
        from public.ficha_items fi
        where fi.ficha_id=f.id
          and (
            fi.description ilike '%'||trim(_query)||'%'
            or fi.product ilike '%'||trim(_query)||'%'
            or fi.code ilike '%'||trim(_query)||'%'
          )
      )
    )
  order by coalesce(ka.completed_at,ka.updated_at) desc
  limit greatest(1,least(coalesce(_limit,100),250));
$function$;

REVOKE EXECUTE ON FUNCTION public.search_finalized_fichas(uuid,uuid,text,integer) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.search_finalized_fichas(uuid,uuid,text,integer) TO authenticated, service_role;
