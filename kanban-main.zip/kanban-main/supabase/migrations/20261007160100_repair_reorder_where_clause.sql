-- Correct the row predicate in reorder_kanban_stage.
create or replace function public.reorder_kanban_stage(
  _sector_id uuid,
  _stage_id uuid,
  _ordered_ficha_ids uuid[]
)
returns void
language plpgsql
security definer
set search_path = public
as $function$
declare
  idx integer;
  v_ficha_id uuid;
begin
  if not public.can_operate(auth.uid()) then
    raise exception 'Usuário sem permissão para reordenar fichas.';
  end if;

  if not exists(
    select 1 from public.stages
    where id = _stage_id
      and sector_id = _sector_id
      and active
  ) then
    raise exception 'A etapa informada não pertence ao setor ou está inativa.';
  end if;

  if coalesce(array_length(_ordered_ficha_ids, 1), 0) = 0 then
    return;
  end if;

  if exists(
    select 1
    from unnest(_ordered_ficha_ids) x
    where x is null
       or not exists(
         select 1
         from public.kanban_assignments ka
         where ka.ficha_id = x
           and ka.sector_id = _sector_id
           and ka.stage_id = _stage_id
       )
  ) then
    raise exception 'A ordem contém ficha que não pertence à etapa informada.';
  end if;

  for idx in 1..array_length(_ordered_ficha_ids, 1) loop
    v_ficha_id := _ordered_ficha_ids[idx];
    update public.kanban_assignments ka
       set sort_order = idx,
           updated_at = now()
     where ka.ficha_id = v_ficha_id;
  end loop;
end
$function$;

revoke execute on function public.reorder_kanban_stage(uuid, uuid, uuid[]) from public, anon;
grant execute on function public.reorder_kanban_stage(uuid, uuid, uuid[]) to authenticated, service_role;
