-- PEDIFLOW flow integrity: dynamic initial classification, safe ficha copies and existing movement rules.
-- Does not replace SMB integration or production-history architecture.

alter table public.fichas
  add column if not exists duplicated_from_ficha_id uuid references public.fichas(id) on delete set null;

create index if not exists idx_fichas_duplicated_from
  on public.fichas(duplicated_from_ficha_id)
  where duplicated_from_ficha_id is not null;

create or replace function public.classify_initial_sector(_item_name text)
returns uuid
language plpgsql
stable
security definer
set search_path = public, pg_temp
as $function$
declare
  normalized text;
  target_name text;
  target_id uuid;
begin
  normalized := lower(
    translate(
      coalesce(_item_name,''),
      'ÁÀÂÃÄáàâãäÉÈÊËéèêëÍÌÎÏíìîïÓÒÔÕÖóòôõöÚÙÛÜúùûüÇçÑñ',
      'AAAAAaaaaaEEEEeeeeIIIIiiiiOOOOOoooooUUUUuuuuCcNn'
    )
  );
  normalized := btrim(regexp_replace(regexp_replace(normalized, '[^a-z0-9]+', ' ', 'g'), '\\s+', ' ', 'g'));

  if normalized ~ '(^| )cartucho( |$)'
     or normalized ~ '(^| )cac( |$)'
     or normalized ~ 'resistencia +(?:de +)?alta +carga'
  then
    target_name := 'cartucho';
  elsif normalized ~ 'microtubular'
     or normalized ~ '(^| )micro( |$)'
     or normalized ~ 'resistencia +em +espiral'
  then
    target_name := 'micro';
  elsif normalized ~ '(^| )tubular( |$)'
     or normalized ~ 'tubular +reta'
     or normalized ~ 'aletada'
     or normalized ~ 'flange'
     or normalized ~ 'flexivel'
  then
    target_name := 'tubular';
  else
    target_name := 'comprado fora';
  end if;

  select s.id into target_id
  from public.sectors s
  where s.active
    and lower(trim(s.name)) = target_name
  order by s.position, s.name
  limit 1;

  if target_id is null then
    raise exception 'O setor real "%" necessário para a classificação inicial não está cadastrado/ativo.', initcap(target_name);
  end if;

  return target_id;
end
$function$;

revoke execute on function public.classify_initial_sector(text) from public, anon;
grant execute on function public.classify_initial_sector(text) to authenticated, service_role;

create or replace function private.apply_initial_smb_classification()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  f public.fichas%rowtype;
  ka public.kanban_assignments%rowtype;
  item_name text;
  target_sector uuid;
  target_stage uuid;
  history_id uuid;
  history_count integer;
  transfer_count integer;
  status_text text;
begin
  select * into f from public.fichas where id = new.ficha_id;
  if f.id is null or upper(coalesce(f.source_system,'')) <> 'SMB' then
    return new;
  end if;

  select count(*) into history_count
  from public.status_history
  where ficha_id = f.id;

  select count(*) into transfer_count
  from public.sector_transfer_history
  where ficha_id = f.id;

  -- Any prior production move OR sector transfer means this is no longer initial classification.
  if history_count > 1 or transfer_count > 0 then
    return new;
  end if;

  select * into ka
  from public.kanban_assignments
  where ficha_id = f.id
  for update;

  if ka.ficha_id is null then
    return new;
  end if;

  select coalesce(nullif(trim(i.product),''), nullif(trim(i.description),'')) into item_name
  from public.ficha_items i
  where i.ficha_id = f.id
  order by i.line_no, i.created_at, i.id
  limit 1;

  if coalesce(trim(item_name),'') = '' then
    return new;
  end if;

  target_sector := public.classify_initial_sector(item_name);

  status_text := lower(trim(coalesce(f.smb_status,'')));
  if status_text ~ 'conclu' or ka.completed_at is not null then
    select st.id into target_stage
    from public.stages st
    where st.sector_id = target_sector
      and st.active
      and (
        st.is_final
        or lower(trim(st.name)) in ('enviado/finalizado','enviado / finalizado')
      )
    order by st.is_final desc, st.position desc, st.name
    limit 1;
  else
    target_stage := public.first_active_stage(target_sector);
  end if;

  if target_stage is null then
    raise exception 'O setor classificado não possui etapa ativa disponível.';
  end if;

  update public.kanban_assignments
  set sector_id = target_sector,
      stage_id = target_stage,
      entered_stage_at = coalesce(entered_stage_at, now()),
      updated_at = now()
  where ficha_id = f.id
    and (sector_id is distinct from target_sector or stage_id is distinct from target_stage);

  select h.id into history_id
  from public.status_history h
  where h.ficha_id = f.id
    and h.previous_stage_id is null
  order by h.changed_at desc, h.id desc
  limit 1;

  if history_id is not null then
    update public.status_history
    set sector_id = target_sector,
        new_stage_id = target_stage
    where id = history_id;
  end if;

  return new;
end
$function$;

drop trigger if exists trg_apply_initial_smb_classification on public.ficha_items;
create trigger trg_apply_initial_smb_classification
after insert or update of product,description,line_no
on public.ficha_items
for each row
execute function private.apply_initial_smb_classification();

-- Manual creation already inserts ficha_items before kanban_assignments, so classify
-- the initial assignment directly without affecting deliberate duplicate copies.
create or replace function private.classify_manual_initial_assignment()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  f public.fichas%rowtype;
  item_name text;
  target_sector uuid;
  target_stage uuid;
begin
  select * into f from public.fichas where id = new.ficha_id;
  if f.id is null
     or upper(coalesce(f.source_system,'')) <> 'MANUAL'
     or f.duplicated_from_ficha_id is not null
  then
    return new;
  end if;

  if exists(select 1 from public.status_history where ficha_id=f.id) then
    return new;
  end if;

  select coalesce(nullif(trim(i.product),''), nullif(trim(i.description),'')) into item_name
  from public.ficha_items i
  where i.ficha_id=f.id
  order by i.line_no, i.created_at, i.id
  limit 1;

  if coalesce(trim(item_name),'') = '' then
    return new;
  end if;

  target_sector := public.classify_initial_sector(item_name);
  target_stage := public.first_active_stage(target_sector);

  if target_stage is null then
    raise exception 'O setor classificado não possui etapa ativa disponível.';
  end if;

  new.sector_id := target_sector;
  new.stage_id := target_stage;
  return new;
end
$function$;

drop trigger if exists trg_classify_manual_initial_assignment on public.kanban_assignments;
create trigger trg_classify_manual_initial_assignment
before insert
on public.kanban_assignments
for each row
execute function private.classify_manual_initial_assignment();

create or replace function public.duplicate_ficha(
  _ficha_id uuid,
  _target_sector_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  source_f public.fichas%rowtype;
  source_ka public.kanban_assignments%rowtype;
  target_sector uuid;
  target_stage uuid;
  copy_id uuid;
  duplicate_group uuid;
begin
  if not public.has_role(auth.uid(),'admin') then
    raise exception 'Somente a administração pode duplicar fichas.';
  end if;

  select * into source_f from public.fichas where id=_ficha_id for update;
  if source_f.id is null then
    raise exception 'Ficha de origem não encontrada.';
  end if;

  select * into source_ka from public.kanban_assignments where ficha_id=_ficha_id for update;
  if source_ka.ficha_id is null then
    raise exception 'A ficha de origem não possui posição no Kanban.';
  end if;

  target_sector := coalesce(_target_sector_id, source_ka.sector_id);

  if not exists(select 1 from public.sectors where id=target_sector and active) then
    raise exception 'O setor de destino é inválido ou está inativo.';
  end if;

  target_stage := public.first_active_stage(target_sector);
  if target_stage is null then
    raise exception 'O setor de destino não possui etapa ativa.';
  end if;

  duplicate_group := coalesce(source_f.duplicate_group_id, gen_random_uuid());

  update public.fichas
  set duplicate_group_id = duplicate_group,
      updated_at = now()
  where id = source_f.id;

  insert into public.fichas(
    external_order_id, order_number, customer, customer_code, codigo_cliente,
    product_summary, quantity, unit, order_date, delivery_date,
    source_observations, source_system, source_synced_at, source_hash,
    sync_state, sync_warning, seller_name,
    duplicate_group_id, duplicated_from_ficha_id
  )
  values(
    null, source_f.order_number, source_f.customer, source_f.customer_code, source_f.codigo_cliente,
    source_f.product_summary, source_f.quantity, source_f.unit, source_f.order_date, source_f.delivery_date,
    source_f.source_observations, 'manual', null, null,
    'active', null, source_f.seller_name,
    duplicate_group, source_f.id
  )
  returning id into copy_id;

  insert into public.ficha_items(ficha_id,line_no,code,product,description,quantity,unit)
  select copy_id,line_no,code,product,description,quantity,unit
  from public.ficha_items
  where ficha_id=source_f.id
  order by line_no;

  insert into public.kanban_assignments(
    ficha_id,sector_id,stage_id,priority,responsible_id,internal_notes,
    production_started_at,completed_at,entered_stage_at,last_changed_by,updated_at
  )
  values(
    copy_id,source_ka.sector_id,source_ka.stage_id,source_ka.priority,source_ka.responsible_id,source_ka.internal_notes,
    null,null,now(),auth.uid(),now()
  );

  insert into public.status_history(
    ficha_id,sector_id,previous_stage_id,new_stage_id,changed_by_user_id,
    performed_by_user_id,changed_at,observation,source,movement_type
  )
  values(
    copy_id,source_ka.sector_id,null,source_ka.stage_id,auth.uid(),auth.uid(),now(),
    'Cópia criada a partir da ficha #'||source_f.order_number,
    'manual','entrada'
  );

  if target_sector is distinct from source_ka.sector_id then
    perform public.transfer_ficha_sector(
      copy_id,
      target_sector,
      auth.uid(),
      'Cópia criada a partir da ficha #'||source_f.order_number
    );
  end if;

  return copy_id;
end
$function$;

revoke execute on function public.duplicate_ficha(uuid,uuid) from public, anon;
grant execute on function public.duplicate_ficha(uuid,uuid) to authenticated, service_role;
