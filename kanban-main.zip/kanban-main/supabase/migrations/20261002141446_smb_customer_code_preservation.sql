alter table public.fichas
  add column if not exists customer_code text;

create or replace function public.ingest_smb_order(_order jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $func$
declare
  f_id uuid; sector_id uuid; stage_id uuid; item jsonb; line integer := 0;
begin
  if coalesce(current_setting('request.jwt.claims', true)::jsonb->>'role','') <> 'service_role' then
    raise exception 'Somente o worker de integração pode importar pedidos.';
  end if;
  if coalesce(_order->>'external_order_id','') = '' then raise exception 'external_order_id é obrigatório.'; end if;

  select id into f_id from public.fichas where external_order_id = _order->>'external_order_id' for update;

  if f_id is null then
    select id into sector_id from public.sectors where active and is_default_import order by position limit 1;
    if sector_id is null then select id into sector_id from public.sectors where active order by position limit 1; end if;
    if sector_id is null then raise exception 'Nenhum setor ativo configurado para importação.'; end if;
    stage_id := public.first_active_stage(sector_id);
    if stage_id is null then raise exception 'O setor de importação não possui etapa ativa.'; end if;

    insert into public.fichas(
      external_order_id, order_number, customer, customer_code, product_summary, quantity,
      unit, order_date, delivery_date, source_observations, source_system,
      source_synced_at, source_hash, sync_state, sync_warning
    )
    values(
      _order->>'external_order_id',
      coalesce(_order->>'order_number', _order->>'external_order_id'),
      coalesce(_order->>'customer',''),
      nullif(trim(_order->>'customer_code'),''),
      nullif(_order->>'product_summary',''),
      nullif(_order->>'quantity','')::numeric,
      nullif(_order->>'unit',''),
      nullif(_order->>'order_date','')::date,
      nullif(_order->>'delivery_date','')::date,
      nullif(_order->>'source_observations',''),
      coalesce(_order->>'source_system','SMB'),
      now(), nullif(_order->>'source_hash',''), 'active', null
    ) returning id into f_id;

    insert into public.kanban_assignments(ficha_id,sector_id,stage_id) values(f_id,sector_id,stage_id);
    insert into public.status_history(ficha_id,sector_id,previous_stage_id,new_stage_id,changed_at,observation,source,movement_type)
    values(f_id,sector_id,null,stage_id,now(),'Importado do SMB','system','entrada');
  else
    update public.fichas
    set order_number = coalesce(_order->>'order_number', order_number),
        customer = coalesce(_order->>'customer', customer),
        customer_code = case when nullif(trim(customer_code),'') is null and nullif(trim(_order->>'customer_code'),'') is not null
          then nullif(trim(_order->>'customer_code'),'') else customer_code end,
        product_summary = case when _order ? 'product_summary' then nullif(_order->>'product_summary','') else product_summary end,
        quantity = case when _order ? 'quantity' and nullif(_order->>'quantity','') is not null then (_order->>'quantity')::numeric else quantity end,
        unit = case when _order ? 'unit' then nullif(_order->>'unit','') else unit end,
        order_date = case when _order ? 'order_date' and nullif(_order->>'order_date','') is not null then (_order->>'order_date')::date else order_date end,
        delivery_date = case when _order ? 'delivery_date' and nullif(_order->>'delivery_date','') is not null then (_order->>'delivery_date')::date else delivery_date end,
        source_observations = case when _order ? 'source_observations' then nullif(_order->>'source_observations','') else source_observations end,
        source_system = coalesce(_order->>'source_system', source_system),
        source_synced_at = now(), source_hash = nullif(_order->>'source_hash',''),
        sync_state = 'active', sync_warning = null, updated_at = now()
    where id = f_id;
  end if;

  delete from public.ficha_items where ficha_id = f_id;
  for item in select * from jsonb_array_elements(coalesce(_order->'items','[]'::jsonb)) loop
    line := line + 1;
    insert into public.ficha_items(ficha_id,line_no,code,product,description,quantity,unit)
    values(f_id,line,nullif(item->>'code',''),nullif(item->>'product',''),nullif(item->>'description',''),
      case when nullif(item->>'quantity','') is null then null else (item->>'quantity')::numeric end,
      nullif(item->>'unit',''));
  end loop;
  return f_id;
end
$func$;

revoke execute on function public.ingest_smb_order(jsonb) from public, anon, authenticated;
grant execute on function public.ingest_smb_order(jsonb) to service_role;
