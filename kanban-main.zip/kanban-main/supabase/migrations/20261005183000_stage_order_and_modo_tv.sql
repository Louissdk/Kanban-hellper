-- Idempotent setup for the Cartucho first stage and Modo TV.
do $$
declare
  v_sector uuid;
  v_corte uuid;
  v_pedido uuid;
begin
  select id into v_sector from public.sectors where name='Cartucho' limit 1;
  if v_sector is null then raise exception 'Setor Cartucho não encontrado.'; end if;

  select id into v_pedido from public.stages
  where sector_id=v_sector and lower(trim(name))='pedido na fabrica' limit 1;

  select id into v_corte from public.stages
  where sector_id=v_sector and lower(trim(name))='corte de porcelana' limit 1;

  if v_pedido is null then
    if v_corte is null then
      select id into v_corte from public.stages where sector_id=v_sector order by position limit 1;
      update public.stages set name='Corte de porcelana' where id=v_corte;
    end if;

    update public.stages set position=position+1
    where sector_id=v_sector;

    insert into public.stages(id,sector_id,name,position,active,is_final,color)
    values(gen_random_uuid(),v_sector,'Pedido na fabrica',1,true,false,null);
  else
    update public.stages set position=1 where id=v_pedido;
    if v_corte is not null then
      update public.stages set position=2 where id=v_corte;
    end if;
  end if;
end $$;

create table if not exists public.tv_orders (
  ficha_id uuid primary key references public.fichas(id) on delete cascade,
  display_date date not null,
  is_priority boolean not null default false,
  shipping_method text not null default 'Não definido',
  sort_order integer not null default 0,
  notes text null,
  created_by uuid null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_tv_orders_display_date
  on public.tv_orders(display_date, is_priority desc, sort_order, updated_at desc);

alter table public.tv_orders enable row level security;

drop policy if exists tv_orders_select_authenticated on public.tv_orders;
create policy tv_orders_select_authenticated
on public.tv_orders for select to authenticated using (true);

drop policy if exists tv_orders_admin_insert on public.tv_orders;
create policy tv_orders_admin_insert
on public.tv_orders for insert to authenticated
with check (public.has_role(auth.uid(),'admin') and created_by = auth.uid());

drop policy if exists tv_orders_admin_update on public.tv_orders;
create policy tv_orders_admin_update
on public.tv_orders for update to authenticated
using (public.has_role(auth.uid(),'admin'))
with check (public.has_role(auth.uid(),'admin'));

drop policy if exists tv_orders_admin_delete on public.tv_orders;
create policy tv_orders_admin_delete
on public.tv_orders for delete to authenticated
using (public.has_role(auth.uid(),'admin'));

revoke all on public.tv_orders from anon;
grant select, insert, update, delete on public.tv_orders to authenticated;

create or replace function public.touch_tv_orders_updated_at()
returns trigger
language plpgsql
set search_path = public
as $function$
begin
  new.updated_at = now();
  return new;
end
$function$;

drop trigger if exists trg_tv_orders_updated_at on public.tv_orders;
create trigger trg_tv_orders_updated_at
before update on public.tv_orders
for each row execute function public.touch_tv_orders_updated_at();

create or replace function public.remove_tv_order_when_sent_to_expedition()
returns trigger
language plpgsql
security definer
set search_path = public
as $function$
begin
  if new.stage_id is distinct from old.stage_id
     and exists (
       select 1 from public.stages s
       where s.id = new.stage_id and lower(trim(s.name)) = 'expedição'
     )
  then
    delete from public.tv_orders where ficha_id = new.ficha_id;
  end if;
  return new;
end
$function$;

drop trigger if exists trg_remove_tv_on_expedition on public.kanban_assignments;
create trigger trg_remove_tv_on_expedition
after update of stage_id on public.kanban_assignments
for each row execute function public.remove_tv_order_when_sent_to_expedition();

revoke all on function public.touch_tv_orders_updated_at() from public,anon,authenticated;
revoke all on function public.remove_tv_order_when_sent_to_expedition() from public,anon,authenticated;
