create or replace function public.finalize_smb_order(
  _ficha_id uuid,
  _source text default 'smb_sync',
  _observation text default 'Pedido identificado como finalizado no SMB.'
)
returns boolean
language plpgsql
security definer
set search_path = public
as $function$
declare
  ka public.kanban_assignments%rowtype;
  target public.stages%rowtype;
begin
  select * into ka from public.kanban_assignments where ficha_id=_ficha_id for update;
  if ka.ficha_id is null then raise exception 'Ficha não encontrada no Kanban.'; end if;

  select * into target
  from public.stages
  where sector_id=ka.sector_id and active=true and is_final=true
  order by position desc limit 1;

  if target.id is null then
    select * into target
    from public.stages
    where sector_id=ka.sector_id
      and active=true
      and lower(trim(name)) in ('enviado/finalizado','finalizados','finalizado','finalizada')
    order by position desc limit 1;
  end if;

  if target.id is null then raise exception 'Nenhuma etapa final ativa está configurada neste setor.'; end if;
  if ka.stage_id=target.id and ka.completed_at is not null then return false; end if;

  update public.kanban_assignments
  set stage_id=target.id, entered_stage_at=now(), completed_at=now(), updated_at=now()
  where ficha_id=_ficha_id;

  if not exists(
    select 1 from public.status_history h
    where h.ficha_id=_ficha_id
      and h.new_stage_id=target.id
      and h.observation=coalesce(nullif(trim(_observation),''),'Pedido identificado como finalizado no SMB.')
      and h.source=coalesce(nullif(trim(_source),''),'smb_sync')
      and h.changed_at > now() - interval '10 seconds'
  ) then
    insert into public.status_history(
      ficha_id,sector_id,previous_stage_id,new_stage_id,changed_by_user_id,
      performed_by_user_id,changed_at,observation,source,movement_type
    )
    values(
      _ficha_id,ka.sector_id,ka.stage_id,target.id,null,null,now(),
      nullif(trim(_observation),''),coalesce(nullif(trim(_source),''),'smb_sync'),'avanco'
    );
  end if;
  return true;
end
$function$;

revoke execute on function public.finalize_smb_order(uuid,text,text) from public, anon;
grant execute on function public.finalize_smb_order(uuid,text,text) to authenticated, service_role;