-- Never process real SMB data while the reversible PEDIFLOW test mode is active.
do $$
declare
  definition text;
begin
  select pg_get_functiondef(oid)
    into definition
  from pg_proc
  where oid='public.process_smb_sync_result(uuid,jsonb)'::regprocedure;

  if position('Modo de teste ativo: processamento SMB bloqueado.' in definition)=0 then
    definition := replace(
      definition,
      '  if coalesce(current_setting(''request.jwt.claims'',true)::jsonb->>''role'','''')<>''service_role'' then',
      '  if public.is_test_mode() then raise exception ''Modo de teste ativo: processamento SMB bloqueado.''; end if;' || chr(10) ||
      '  if coalesce(current_setting(''request.jwt.claims'',true)::jsonb->>''role'','''')<>''service_role'' then'
    );
    execute definition;
  end if;
end
$$;
