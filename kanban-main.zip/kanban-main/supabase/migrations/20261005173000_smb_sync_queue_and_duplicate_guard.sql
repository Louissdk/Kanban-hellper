-- SMB queue contract, manual duplicate guard and administrative duplicate resolution.
-- Preserves the existing Kanban architecture and production history.

alter table public.fichas
  add column if not exists duplicate_group_id uuid;

create index if not exists idx_fichas_duplicate_group
  on public.fichas(duplicate_group_id)
  where duplicate_group_id is not null;

create or replace function public.create_manual_ficha_with_items(
  _order_number text,
  _customer text,
  _items jsonb default '[]'::jsonb,
  _delivery_date date default null,
  _sector_id uuid default null,
  _priority text default 'normal',
  _seller_name text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $function$
begin
  return public.create_manual_ficha_with_items(
    _order_number,_customer,_items,_delivery_date,_sector_id,_priority,_seller_name,false
  );
end
$function$;

create or replace function public.create_manual_ficha_with_items(
  _order_number text,
  _customer text,
  _items jsonb default '[]'::jsonb,
  _delivery_date date default null,
  _sector_id uuid default null,
  _priority text default 'normal',
  _seller_name text default null,
  _allow_duplicate boolean default false
)
returns uuid
language plpgsql
security definer
set search_path = public
as $function$
declare
  f_id uuid;
  target_stage uuid;
  item_count integer;
  first_product text;
  first_quantity numeric;
  first_unit text;
  row_item record;
  effective_priority text;
  duplicate_count integer := 0;
  existing_group uuid;
  duplicate_group uuid;
begin
  if not public.can_operate(auth.uid()) then
    raise exception 'Usuário sem permissão para criar fichas.';
  end if;

  if coalesce(trim(_order_number), '') = '' then
    raise exception 'Número da ficha é obrigatório.';
  end if;

  if coalesce(trim(_customer), '') = '' then
    raise exception 'Cliente é obrigatório.';
  end if;

  if not exists (select 1 from public.sectors where id = _sector_id and active) then
    raise exception 'Setor inválido ou inativo.';
  end if;

  if jsonb_typeof(_items) <> 'array' or jsonb_array_length(_items) = 0 then
    raise exception 'Adicione pelo menos um item ao pedido.';
  end if;

  for row_item in
    select * from jsonb_to_recordset(_items) as x(
      code text, product text, description text, quantity numeric, unit text
    )
  loop
    if coalesce(trim(row_item.product), '') = '' and coalesce(trim(row_item.description), '') = '' then
      raise exception 'Cada item precisa de produto ou descrição.';
    end if;
    if row_item.quantity is not null and row_item.quantity < 0 then
      raise exception 'A quantidade de um item não pode ser negativa.';
    end if;
  end loop;

  effective_priority :=
    case
      when public.has_role(auth.uid(),'admin') then coalesce(_priority,'normal')
      else 'normal'
    end;

  if effective_priority not in ('baixa','normal','alta','urgente') then
    raise exception 'Prioridade inválida.';
  end if;

  perform pg_advisory_xact_lock(
    hashtext(upper(trim(_order_number)) || E'\x1f' || upper(trim(_customer)))
  );

  select count(*) into duplicate_count
  from public.fichas f
  where upper(trim(coalesce(f.order_number,''))) = upper(trim(_order_number))
    and upper(trim(coalesce(f.customer,''))) = upper(trim(_customer));

  if duplicate_count > 0 then
    if not _allow_duplicate then
      raise exception 'Já existe um pedido com este número para este cliente. A duplicidade só pode ser criada pela administração.';
    end if;

    if not public.has_role(auth.uid(),'admin') then
      raise exception 'Somente a administração pode criar um pedido duplicado.';
    end if;

    select f.duplicate_group_id into existing_group
    from public.fichas f
    where upper(trim(coalesce(f.order_number,''))) = upper(trim(_order_number))
      and upper(trim(coalesce(f.customer,''))) = upper(trim(_customer))
      and f.duplicate_group_id is not null
    order by f.created_at
    limit 1;

    duplicate_group := coalesce(existing_group, gen_random_uuid());

    update public.fichas f
       set duplicate_group_id = duplicate_group,
           updated_at = now()
     where upper(trim(coalesce(f.order_number,''))) = upper(trim(_order_number))
       and upper(trim(coalesce(f.customer,''))) = upper(trim(_customer));
  end if;

  select id into target_stage
  from public.stages
  where sector_id = _sector_id and active
  order by position
  limit 1;

  if target_stage is null then
    raise exception 'O setor não possui etapa ativa.';
  end if;

  select
    coalesce(nullif(trim(product), ''), nullif(trim(description), '')),
    quantity,
    nullif(trim(coalesce(unit, 'UND')), '')
  into first_product, first_quantity, first_unit
  from jsonb_to_record(_items->0) as x(
    code text, product text, description text, quantity numeric, unit text
  );

  item_count := jsonb_array_length(_items);

  insert into public.fichas(
    order_number,customer,product_summary,quantity,unit,delivery_date,seller_name,
    source_system,source_synced_at,sync_state,duplicate_group_id
  )
  values(
    trim(_order_number),trim(_customer),first_product,
    case when item_count = 1 then first_quantity else null end,
    case when item_count = 1 then first_unit else null end,
    _delivery_date,nullif(trim(coalesce(_seller_name, '')), ''),
    'manual',null,'active',duplicate_group
  )
  returning id into f_id;

  insert into public.ficha_items(ficha_id,line_no,code,product,description,quantity,unit)
  select
    f_id,row_number() over (),nullif(trim(x.code),''),nullif(trim(x.product),''),
    nullif(trim(x.description),''),x.quantity,nullif(trim(coalesce(x.unit,'UND')),'')
  from jsonb_to_recordset(_items) as x(
    code text, product text, description text, quantity numeric, unit text
  );

  insert into public.kanban_assignments(
    ficha_id,sector_id,stage_id,priority,last_changed_by
  )
  values(f_id,_sector_id,target_stage,effective_priority,auth.uid());

  insert into public.status_history(
    ficha_id,sector_id,previous_stage_id,new_stage_id,
    changed_by_user_id,performed_by_user_id,changed_at,observation,source
  )
  values(
    f_id,_sector_id,null,target_stage,auth.uid(),auth.uid(),now(),
    case
      when duplicate_group is not null then 'Ficha manual criada como duplicidade autorizada pela administração.'
      else 'Ficha manual criada'
    end,
    'manual'
  );

  return f_id;
end
$function$;

grant execute on function public.create_manual_ficha_with_items(text,text,jsonb,date,uuid,text,text)
  to authenticated;
grant execute on function public.create_manual_ficha_with_items(text,text,jsonb,date,uuid,text,text,boolean)
  to authenticated;

create or replace function public.delete_ficha(
  _ficha_id uuid,
  _authorized_profile_id uuid,
  _pin text
)
returns uuid
language plpgsql
security definer
set search_path = public, private
as $function$
declare
  f public.fichas%rowtype;
  ka public.kanban_assignments%rowtype;
  items jsonb;
  history jsonb;
  result_id uuid;
  group_id uuid;
begin
  if not public.has_role(auth.uid(),'admin') then
    raise exception 'Apenas administradores podem excluir pedidos.';
  end if;

  if not exists(
    select 1
    from private.kanban_delete_authorizers a
    join public.profiles p on p.id=a.profile_id
    where a.profile_id=_authorized_profile_id
      and p.active
      and lower(split_part(trim(p.full_name),' ',1)) in ('matheus','henrique','gabrielly')
  ) then
    raise exception 'O perfil selecionado não está autorizado para exclusão.';
  end if;

  if not exists(
    select 1 from private.kanban_security
    where singleton and delete_pin_hash=crypt(coalesce(_pin,''), delete_pin_hash)
  ) then
    raise exception 'PIN de exclusão inválido.';
  end if;

  select * into f from public.fichas where id=_ficha_id for update;
  if f.id is null then raise exception 'Pedido não encontrado.'; end if;

  group_id := f.duplicate_group_id;

  select * into ka from public.kanban_assignments where ficha_id=f.id;

  select coalesce(jsonb_agg(to_jsonb(i) order by i.line_no),'[]'::jsonb)
    into items from public.ficha_items i where i.ficha_id=f.id;

  select coalesce(jsonb_agg(to_jsonb(h) order by h.changed_at),'[]'::jsonb)
    into history from public.status_history h where h.ficha_id=f.id;

  insert into public.ficha_deletion_history(
    ficha_id,order_number,deleted_by_user_id,authorized_profile_id,record_snapshot
  )
  values(
    f.id,f.order_number,auth.uid(),_authorized_profile_id,
    jsonb_build_object(
      'ficha',to_jsonb(f),
      'kanban_assignment',to_jsonb(ka),
      'items',items,
      'status_history',history,
      'deleted_at',now()
    )
  );

  delete from public.fichas where id=f.id returning id into result_id;

  if group_id is not null then
    if not exists(select 1 from public.fichas where duplicate_group_id=group_id) then
      null;
    elsif (select count(*) from public.fichas where duplicate_group_id=group_id)=1 then
      update public.fichas set duplicate_group_id=null,updated_at=now()
      where duplicate_group_id=group_id;
    end if;
  end if;

  return result_id;
end
$function$;

revoke execute on function public.delete_ficha(uuid,uuid,text) from public, anon;
grant execute on function public.delete_ficha(uuid,uuid,text) to authenticated, service_role;

drop policy if exists sync_runs_request_authenticated on public.sync_runs;
create policy sync_runs_request_authenticated
on public.sync_runs
for insert
to authenticated
with check (
  requested_by = auth.uid()
  and status = 'requested'
  and trigger = 'manual'
  and trigger_type = 'manual_button'
  and robot_status = 'queued'
  and robot_message = 'Aguardando o robô SMB.'
);

revoke insert on public.sync_runs from anon;
grant insert on public.sync_runs to authenticated;

create or replace function public.process_smb_sync_result(_sync_run_id uuid, _result jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $function$
declare
  run_row public.sync_runs%rowtype;
  order_row record;
  item jsonb;
  f_id uuid;
  target_stage uuid;
  import_sector_id uuid;
  customer_name text;
  resolved_customer_code text;
  customer_matches integer;
  pdd text;
  customer_order_number text;
  seller_value text;
  opened_value timestamptz;
  delivery_value date;
  normalized_status text;
  status_code text;
  status_description text;
  status_is_completed boolean;
  order_items jsonb;
  item_count integer;
  derived_product_summary text;
  derived_quantity numeric;
  derived_unit text;
  created_count integer := 0;
  updated_count integer := 0;
  ignored_count integer := 0;
  eligible_count integer := 0;
  error_count integer := 0;
  warning_count integer := 0;
  error_messages text[] := '{}';
  ranking_value integer;
  existing_stage_id uuid;
  existing_sector_id uuid;
  sequence_value integer;
  fallback_matches integer := 0;
begin
  if coalesce(current_setting('request.jwt.claims',true)::jsonb->>'role','') <> 'service_role' then
    raise exception 'Somente o serviço de integração pode processar resultados do robô.';
  end if;

  select * into run_row from public.sync_runs where id=_sync_run_id for update;
  if run_row.id is null then raise exception 'Execução de sincronização não encontrada.'; end if;
  if run_row.status not in ('requested','running') then
    raise exception 'A execução de sincronização não está aguardando processamento.';
  end if;

  update public.sync_runs
  set status='running',started_at=coalesce(started_at,now()),
      robot_status='available',robot_message=null,error_message=null
  where id=_sync_run_id;

  select s.id into import_sector_id
  from public.sectors s
  where s.active and s.is_default_import
  order by s.position
  limit 1;

  create temporary table if not exists tmp_smb_orders(
    external_order_id text,customer_order_number text,customer text,smb_cliente_id text,
    seller text,opened_at timestamptz,delivery_date date,envio text,
    status_smb text,status_smb_descricao text,ranking integer,
    source_observations text,source_hash text,product_summary text,
    quantity numeric,unit text,items jsonb
  ) on commit drop;

  truncate tmp_smb_orders;

  insert into tmp_smb_orders(
    external_order_id,customer_order_number,customer,smb_cliente_id,seller,
    opened_at,delivery_date,envio,status_smb,status_smb_descricao,ranking,
    source_observations,source_hash,product_summary,quantity,unit,items
  )
  select
    nullif(trim(coalesce(raw->>'external_order_id',raw->>'pdd_id')),''),
    nullif(trim(coalesce(raw->>'pedido_cliente',raw->>'customer_order_number',raw->>'order_number')),''),
    nullif(trim(coalesce(raw->'cliente'->>'nome',raw->>'customer')),''),
    nullif(trim(coalesce(raw->'cliente'->>'smb_cliente_id',raw->>'smb_cliente_id')),''),
    nullif(trim(coalesce(raw->>'vendedor',raw->>'seller')),''),
    public.parse_smb_datetime(coalesce(raw->>'abertura',raw->>'opened_at')),
    public.parse_smb_date(coalesce(raw->>'data_entrega',raw->>'delivery_date')),
    nullif(trim(coalesce(raw->>'envio',raw->>'shipping')),''),
    upper(trim(coalesce(raw->>'status_smb',raw->>'smb_status',''))),
    nullif(trim(coalesce(raw->>'status_smb_descricao',raw->>'smb_status_descricao')),''),
    case
      when nullif(trim(coalesce(raw->>'ranking',raw->>'rank')),'') ~ '^\d+$'
      then (coalesce(raw->>'ranking',raw->>'rank'))::integer
      else null
    end,
    nullif(trim(coalesce(raw->>'observacoes',raw->>'source_observations')),''),
    nullif(trim(raw->>'source_hash'),''),
    nullif(trim(raw->>'product_summary'),''),
    case when nullif(trim(raw->>'quantity'),'') is null then null else (raw->>'quantity')::numeric end,
    nullif(trim(raw->>'unit'),''),
    case
      when jsonb_typeof(raw->'itens')='array' then raw->'itens'
      when jsonb_typeof(raw->'items')='array' then raw->'items'
      else '[]'::jsonb
    end
  from jsonb_array_elements(coalesce(_result->'orders','[]'::jsonb)) raw;

  for order_row in
    select distinct on (external_order_id) *
    from tmp_smb_orders
    where external_order_id is not null
    order by external_order_id,opened_at desc nulls last,
             jsonb_array_length(items) desc,ranking nulls last
  loop
    pdd := order_row.external_order_id;
    customer_order_number := order_row.customer_order_number;
    seller_value := order_row.seller;
    opened_value := order_row.opened_at;
    delivery_value := order_row.delivery_date;
    status_code := upper(trim(coalesce(order_row.status_smb,'')));
    status_description := upper(trim(coalesce(order_row.status_smb_descricao,'')));

    normalized_status := case
      when status_code='I' then 'INICIADO'
      when status_code='P' then 'EM PRODUÇÃO'
      when status_code='A' then 'EM ATRASO'
      when status_code='C' then 'CONCLUÍDO'
      when status_code='' and status_description='INICIADO' then 'INICIADO'
      when status_code='' and status_description='EM PRODUÇÃO' then 'EM PRODUÇÃO'
      when status_code='' and status_description='EM ATRASO' then 'EM ATRASO'
      when status_code='' and status_description='CONCLUÍDO' then 'CONCLUÍDO'
      else null
    end;

    status_is_completed := status_code='C';

    if pdd is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'Pedido sem pdd_id/external_order_id.');
      insert into public.sync_errors(
        sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
      )
      values(
        _sync_run_id,null,'error','Pedido sem pdd_id/external_order_id.',
        'missing_external_order_id','Pedido sem pdd_id/external_order_id.',now()
      );
      continue;
    end if;

    select f.id,ka.stage_id,ka.sector_id
      into f_id,existing_stage_id,existing_sector_id
    from public.fichas f
    left join public.kanban_assignments ka on ka.ficha_id=f.id
    where f.pdd_id=pdd or f.external_order_id=pdd
    limit 1;

    customer_name := order_row.customer;

    select count(*),max(c.codigo_cliente)
      into customer_matches,resolved_customer_code
    from public.clientes c
    where c.ativo=true
      and coalesce(customer_name,'')<>''
      and upper(trim(c.nome))=upper(trim(customer_name));

    if customer_matches<>1 then
      resolved_customer_code:=null;
      if customer_matches>1 then
        warning_count:=warning_count+1;
        insert into public.sync_errors(
          sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
        )
        values(
          _sync_run_id,pdd,'warning',
          'Cliente com correspondência ambígua; código mantido NULL.',
          'ambiguous_customer','Cliente com correspondência ambígua; código mantido NULL.',now()
        );
      end if;
    end if;

    if f_id is null then
      select count(*) into fallback_matches
      from public.fichas f
      where f.pdd_id is null
        and f.external_order_id is null
        and upper(trim(coalesce(f.order_number,''))) =
            upper(trim(coalesce(customer_order_number,pdd)))
        and upper(trim(coalesce(f.customer,''))) =
            upper(trim(coalesce(customer_name,'')));

      if fallback_matches = 1 then
        select f.id,ka.stage_id,ka.sector_id
          into f_id,existing_stage_id,existing_sector_id
        from public.fichas f
        left join public.kanban_assignments ka on ka.ficha_id=f.id
        where f.pdd_id is null
          and f.external_order_id is null
          and upper(trim(coalesce(f.order_number,''))) =
              upper(trim(coalesce(customer_order_number,pdd)))
          and upper(trim(coalesce(f.customer,''))) =
              upper(trim(coalesce(customer_name,'')))
        order by f.created_at
        limit 1;
      elsif fallback_matches > 1 then
        warning_count:=warning_count+1;
        ignored_count:=ignored_count+1;
        error_messages:=array_append(
          error_messages,
          '['||pdd||'] pedido não importado porque existem múltiplas fichas com o mesmo número e cliente; decisão administrativa necessária.'
        );
        insert into public.sync_errors(
          sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
        )
        values(
          _sync_run_id,pdd,'warning',
          'Pedido não importado porque existem múltiplas fichas com o mesmo número e cliente; decisão administrativa necessária.',
          'duplicate_order_number_conflict',
          'Pedido não importado porque existem múltiplas fichas com o mesmo número e cliente; decisão administrativa necessária.',
          now()
        );
        continue;
      end if;
    end if;

    order_items := order_row.items;
    select count(*) into item_count from jsonb_array_elements(order_items);

    derived_product_summary := order_row.product_summary;
    if derived_product_summary is null then
      select nullif(trim(coalesce(i.value->>'descricao',i.value->>'description',i.value->>'product')),'')
        into derived_product_summary
      from jsonb_array_elements(order_items) i(value)
      order by coalesce(
        nullif(i.value->>'sequencia','')::integer,
        nullif(i.value->>'sequence','')::integer,
        nullif(i.value->>'item_sequence','')::integer,
        999999
      )
      limit 1;
    end if;

    derived_quantity := order_row.quantity;
    if derived_quantity is null then
      select sum(
        case
          when nullif(trim(coalesce(i.value->>'quantidade',i.value->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
          then replace(coalesce(i.value->>'quantidade',i.value->>'quantity'),',','.')::numeric
          else null
        end
      ) into derived_quantity
      from jsonb_array_elements(order_items) i(value);
    end if;

    derived_unit := order_row.unit;
    if derived_unit is null and item_count=1 then
      select nullif(trim(coalesce(i.value->>'unidade',i.value->>'unit')),'')
        into derived_unit
      from jsonb_array_elements(order_items) i(value)
      limit 1;
    end if;

    if f_id is not null then
      update public.fichas f
      set pdd_id=coalesce(f.pdd_id,pdd),
          external_order_id=coalesce(f.external_order_id,pdd),
          order_number=coalesce(order_row.customer_order_number,f.order_number),
          pedido_cliente=coalesce(order_row.customer_order_number,f.pedido_cliente),
          customer=coalesce(order_row.customer,f.customer),
          smb_cliente_id=coalesce(order_row.smb_cliente_id,f.smb_cliente_id),
          seller_name=coalesce(order_row.seller,f.seller_name),
          product_summary=coalesce(derived_product_summary,f.product_summary),
          quantity=coalesce(derived_quantity,f.quantity),
          unit=coalesce(derived_unit,f.unit),
          opened_at=coalesce(order_row.opened_at,f.opened_at),
          order_date=coalesce(order_row.opened_at::date,f.order_date),
          delivery_date=coalesce(delivery_value,f.delivery_date),
          data_entrega=coalesce(delivery_value,f.data_entrega),
          envio=coalesce(order_row.envio,f.envio),
          status_smb=case when status_code<>'' then status_code else f.status_smb end,
          status_smb_descricao=coalesce(nullif(trim(order_row.status_smb_descricao),''),f.status_smb_descricao),
          smb_status=coalesce(normalized_status,f.smb_status),
          codigo_cliente=coalesce(
            nullif(trim(f.codigo_cliente),''),
            nullif(trim(f.customer_code),''),
            resolved_customer_code
          ),
          customer_code=coalesce(
            nullif(trim(f.customer_code),''),
            nullif(trim(f.codigo_cliente),''),
            resolved_customer_code
          ),
          smb_ranking=coalesce(order_row.ranking,f.smb_ranking),
          source_observations=coalesce(order_row.source_observations,f.source_observations),
          source_system='SMB',
          source_synced_at=now(),
          source_hash=coalesce(order_row.source_hash,f.source_hash),
          sync_state='active',
          sync_warning=case
            when fallback_matches > 0 then 'Ficha manual vinculada ao pedido SMB automaticamente.'
            when customer_matches>1 then 'Código do cliente não resolvido: múltiplas correspondências.'
            when customer_matches=0 and coalesce(customer_name,'')<>'' then 'Código do cliente não resolvido: cliente não encontrado.'
            else null
          end,
          updated_at=now()
      where f.id=f_id;

      delete from public.ficha_items where ficha_id=f_id;

      for item in select value from jsonb_array_elements(order_items)
      loop
        sequence_value:=coalesce(
          nullif(item->>'sequencia','')::integer,
          nullif(item->>'sequence','')::integer,
          nullif(item->>'item_sequence','')::integer
        );
        if sequence_value is null then
          sequence_value:=coalesce(
            (select max(line_no)+1 from public.ficha_items where ficha_id=f_id),
            1
          );
        end if;

        insert into public.ficha_items(
          ficha_id,pdd_id,line_no,code,product,description,quantity,unit
        )
        values(
          f_id,pdd,sequence_value,
          nullif(trim(coalesce(item->>'codigo',item->>'code')),''),
          nullif(trim(coalesce(item->>'produto',item->>'product')),''),
          nullif(trim(coalesce(item->>'descricao',item->>'description')),''),
          case
            when nullif(trim(coalesce(item->>'quantidade',item->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
            then replace(coalesce(item->>'quantidade',item->>'quantity'),',','.')::numeric
            else null
          end,
          nullif(trim(coalesce(item->>'unidade',item->>'unit')),'')
        );
      end loop;

      updated_count:=updated_count+1;

      if status_is_completed then
        perform public.finalize_smb_order(
          f_id,'SMB_SYNC','Pedido identificado como CONCLUÍDO no SMB.'
        );
      end if;

      continue;
    end if;

    if opened_value is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] data/hora de abertura ausente ou inválida.');
      insert into public.sync_errors(
        sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
      )
      values(
        _sync_run_id,pdd,'error',
        'Data/hora de abertura ausente ou inválida.',
        'invalid_opened_at','Data/hora de abertura ausente ou inválida.',now()
      );
      continue;
    end if;

    if opened_value::date < date '2026-09-21' then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    ranking_value:=order_row.ranking;

    if ranking_value is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] ranking não informado pelo robô.');
      insert into public.sync_errors(
        sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
      )
      values(
        _sync_run_id,pdd,'error',
        'Ranking não informado pelo robô.',
        'missing_ranking','Ranking não informado pelo robô.',now()
      );
      continue;
    end if;

    if ranking_value<=2 then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    if normalized_status is null then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    if normalized_status not in ('INICIADO','EM PRODUÇÃO','EM ATRASO') then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    if seller_value is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] vendedor ausente; pedido não pode entrar no Kanban.');
      insert into public.sync_errors(
        sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
      )
      values(
        _sync_run_id,pdd,'error',
        'Vendedor ausente; pedido não pode entrar no Kanban.',
        'missing_seller','Vendedor ausente; pedido não pode entrar no Kanban.',now()
      );
      continue;
    end if;

    if import_sector_id is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] nenhum setor de importação configurado.');
      insert into public.sync_errors(
        sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
      )
      values(
        _sync_run_id,pdd,'error',
        'Nenhum setor de importação configurado.',
        'missing_import_sector','Nenhum setor de importação configurado.',now()
      );
      continue;
    end if;

    target_stage:=public.first_active_stage(import_sector_id);

    if target_stage is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] nenhum estágio inicial ativo configurado.');
      insert into public.sync_errors(
        sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at
      )
      values(
        _sync_run_id,pdd,'error',
        'Nenhum estágio inicial ativo configurado.',
        'missing_import_stage','Nenhum estágio inicial ativo configurado.',now()
      );
      continue;
    end if;

    eligible_count:=eligible_count+1;

    insert into public.fichas(
      pdd_id,external_order_id,order_number,customer,codigo_cliente,customer_code,seller_name,
      product_summary,quantity,unit,order_date,opened_at,delivery_date,
      smb_cliente_id,pedido_cliente,data_entrega,envio,status_smb,status_smb_descricao,
      smb_ranking,source_observations,source_system,source_synced_at,source_hash,
      sync_state,sync_warning,smb_status
    )
    values(
      pdd,pdd,coalesce(order_row.customer_order_number,pdd),coalesce(order_row.customer,''),
      resolved_customer_code,resolved_customer_code,order_row.seller,derived_product_summary,
      derived_quantity,derived_unit,opened_value::date,opened_value,delivery_value,
      order_row.smb_cliente_id,order_row.customer_order_number,delivery_value,order_row.envio,
      case when status_code in ('I','P','A','C') then status_code else null end,
      coalesce(nullif(trim(order_row.status_smb_descricao),''),normalized_status),
      ranking_value,order_row.source_observations,'SMB',now(),
      coalesce(order_row.source_hash,md5(order_row::text)),
      'active',
      case
        when customer_matches>1 then 'Código do cliente não resolvido: múltiplas correspondências.'
        when customer_matches=0 and coalesce(customer_name,'')<>'' then 'Código do cliente não resolvido: cliente não encontrado.'
        else null
      end,
      normalized_status
    )
    returning id into f_id;

    insert into public.kanban_assignments(ficha_id,sector_id,stage_id,priority,last_changed_by)
    values(f_id,import_sector_id,target_stage,'normal',null);

    insert into public.status_history(
      ficha_id,sector_id,previous_stage_id,new_stage_id,changed_at,observation,source,movement_type
    )
    values(
      f_id,import_sector_id,null,target_stage,now(),
      'Importado do SMB','SMB_SYNC','entrada'
    );

    for item in select value from jsonb_array_elements(order_items)
    loop
      sequence_value:=coalesce(
        nullif(item->>'sequencia','')::integer,
        nullif(item->>'sequence','')::integer,
        nullif(item->>'item_sequence','')::integer
      );
      if sequence_value is null then
        sequence_value:=coalesce(
          (select max(line_no)+1 from public.ficha_items where ficha_id=f_id),
          1
        );
      end if;

      insert into public.ficha_items(
        ficha_id,pdd_id,line_no,code,product,description,quantity,unit
      )
      values(
        f_id,pdd,sequence_value,
        nullif(trim(coalesce(item->>'codigo',item->>'code')),''),
        nullif(trim(coalesce(item->>'produto',item->>'product')),''),
        nullif(trim(coalesce(item->>'descricao',item->>'description')),''),
        case
          when nullif(trim(coalesce(item->>'quantidade',item->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
          then replace(coalesce(item->>'quantidade',item->>'quantity'),',','.')::numeric
          else null
        end,
        nullif(trim(coalesce(item->>'unidade',item->>'unit')),'')
      );
    end loop;

    created_count:=created_count+1;
  end loop;

  update public.sync_runs
  set status=case when error_count>0 or warning_count>0 then 'partial' else 'success' end,
      finished_at=now(),
      total_read=jsonb_array_length(coalesce(_result->'orders','[]'::jsonb)),
      inserted=created_count,updated=updated_count,skipped=ignored_count,
      errors=error_count,warnings=warning_count,
      orders_scanned=jsonb_array_length(coalesce(_result->'orders','[]'::jsonb)),
      orders_eligible=eligible_count,orders_created=created_count,
      orders_updated=updated_count,orders_ignored=ignored_count,
      errors_count=error_count,
      error_details=case
        when coalesce(array_length(error_messages,1),0)>0 then array_to_string(error_messages,E'\n')
        else null
      end,
      error_message=case
        when coalesce(array_length(error_messages,1),0)>0 then array_to_string(error_messages,E'\n')
        else null
      end,
      robot_status='available',
      robot_message=coalesce(
        nullif(trim(_result->>'message'),''),
        'Resultado recebido do serviço de leitura.'
      )
  where id=_sync_run_id;

  return jsonb_build_object(
    'success',error_count=0 and warning_count=0,
    'sync_run_id',_sync_run_id,
    'orders_scanned',jsonb_array_length(coalesce(_result->'orders','[]'::jsonb)),
    'orders_eligible',eligible_count,'orders_created',created_count,
    'orders_updated',updated_count,'orders_ignored',ignored_count,
    'errors_count',error_count,'warnings_count',warning_count,
    'status',case when error_count>0 or warning_count>0 then 'partial' else 'success' end
  );
end
$function$;

revoke execute on function public.process_smb_sync_result(uuid,jsonb)
  from public, anon, authenticated;
grant execute on function public.process_smb_sync_result(uuid,jsonb) to service_role;
