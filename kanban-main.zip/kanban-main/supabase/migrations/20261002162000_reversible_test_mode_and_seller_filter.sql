-- Reversible test mode permissions.
-- The snapshot/restore functions already exist in the production database.
-- This migration makes the temporary elevated permissions apply only to
-- the authenticated user while test mode is active and protects shutdown.
create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean
language sql
stable
security definer
set search_path = public, private
as $function$
  select case
    when coalesce((select active from private.kanban_test_mode where singleton), false)
      and _user_id = auth.uid()
      then true
    else exists(
      select 1 from public.user_roles
      where user_id = _user_id and role = _role
    )
  end;
$function$;

create or replace function public.deactivate_test_mode()
returns jsonb
language plpgsql
security definer
set search_path = public, private
as $function$
declare
  snap jsonb;
  active_by uuid;
begin
  select t.activated_by, t.snapshot into active_by, snap
  from private.kanban_test_mode t
  where t.singleton and t.active;

  if snap is null then
    raise exception 'Snapshot do modo de teste não encontrado.';
  end if;

  if active_by <> auth.uid()
     and not exists (
       select 1 from public.user_roles
       where user_id = auth.uid() and role = 'admin'::app_role
     ) then
    raise exception 'Somente quem ativou o modo de teste ou um administrador real pode desativá-lo.';
  end if;

  update private.kanban_test_mode
  set active = false, activated_by = null, activated_at = null
  where singleton;

  delete from private.kanban_delete_authorizers;
  delete from private.kanban_security;
  delete from public.ficha_items;
  delete from public.production_losses;
  delete from public.status_history;
  delete from public.sector_transfer_history;
  delete from public.ficha_deletion_history;
  delete from public.kanban_assignments;
  delete from public.sync_errors;
  delete from public.sync_runs;
  delete from public.user_roles;
  delete from public.fichas;
  delete from public.stages;
  delete from public.sectors;
  delete from public.clientes;
  delete from public.system_settings;
  delete from public.documents;
  delete from public.profiles;

  insert into public.profiles select * from jsonb_populate_recordset(null::public.profiles, snap->'profiles');
  insert into public.user_roles select * from jsonb_populate_recordset(null::public.user_roles, snap->'user_roles');
  insert into public.sectors select * from jsonb_populate_recordset(null::public.sectors, snap->'sectors');
  insert into public.stages select * from jsonb_populate_recordset(null::public.stages, snap->'stages');
  insert into public.clientes select * from jsonb_populate_recordset(null::public.clientes, snap->'clientes');
  insert into public.system_settings select * from jsonb_populate_recordset(null::public.system_settings, snap->'system_settings');
  insert into public.fichas select * from jsonb_populate_recordset(null::public.fichas, snap->'fichas');
  insert into public.kanban_assignments select * from jsonb_populate_recordset(null::public.kanban_assignments, snap->'kanban_assignments');
  insert into public.ficha_items select * from jsonb_populate_recordset(null::public.ficha_items, snap->'ficha_items');
  insert into public.status_history select * from jsonb_populate_recordset(null::public.status_history, snap->'status_history');
  insert into public.sector_transfer_history select * from jsonb_populate_recordset(null::public.sector_transfer_history, snap->'sector_transfer_history');
  insert into public.production_losses select * from jsonb_populate_recordset(null::public.production_losses, snap->'production_losses');
  insert into public.ficha_deletion_history select * from jsonb_populate_recordset(null::public.ficha_deletion_history, snap->'ficha_deletion_history');
  insert into public.sync_runs select * from jsonb_populate_recordset(null::public.sync_runs, snap->'sync_runs');
  insert into public.sync_errors select * from jsonb_populate_recordset(null::public.sync_errors, snap->'sync_errors');
  insert into public.documents(id, content, metadata, embedding)
    select (x->>'id')::bigint, x->>'content', coalesce(x->'metadata','{}'::jsonb),
      case when nullif(x->>'embedding','') is null then null else (x->>'embedding')::vector end
    from jsonb_array_elements(snap->'documents') x;
  insert into private.kanban_security select * from jsonb_populate_recordset(null::private.kanban_security, snap->'security');
  insert into private.kanban_delete_authorizers select * from jsonb_populate_recordset(null::private.kanban_delete_authorizers, snap->'delete_authorizers');

  update private.kanban_test_mode set snapshot = null where singleton;
  return public.get_test_mode_state();
end
$function$;

-- Keep the SMB worker read-only relative to the real environment during tests.
-- Normal integration continues unchanged whenever test mode is off.
create or replace function public.ingest_smb_order(_order jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $function$
declare
  f_id uuid;
  sector_id uuid;
  stage_id uuid;
  item jsonb;
  line integer := 0;
begin
  if public.is_test_mode() then
    raise exception 'Modo de teste ativo: sincronização SMB temporariamente bloqueada.';
  end if;
  if coalesce(current_setting('request.jwt.claims', true)::jsonb->>'role','') <> 'service_role' then
    raise exception 'Somente o worker de integração pode importar pedidos.';
  end if;
  if coalesce(_order->>'external_order_id','') = '' then raise exception 'external_order_id é obrigatório.'; end if;

  select id into f_id from public.fichas where external_order_id = _order->>'external_order_id' for update;
  if f_id is null then
    select id into sector_id from public.sectors where active and is_default_import order by position limit 1;
    if sector_id is null then select id into sector_id from public.sectors where active order by position limit 1; end if;
    if sector_id is null then raise exception 'Nenhum setor ativo configurado para importação.'; end if;
    stage_id := public.first_active_stage(sector_id);
    if stage_id is null then raise exception 'O setor de importação não possui etapa ativa.'; end if;

    insert into public.fichas(
      external_order_id, order_number, customer, customer_code, seller_name, product_summary,
      quantity, unit, order_date, delivery_date, source_observations,
      source_system, source_synced_at, source_hash, sync_state, sync_warning
    )
    values(
      _order->>'external_order_id', coalesce(_order->>'order_number', _order->>'external_order_id'),
      coalesce(_order->>'customer',''), nullif(trim(_order->>'customer_code'),''),
      nullif(trim(_order->>'seller_name'),''), nullif(_order->>'product_summary',''),
      nullif(_order->>'quantity','')::numeric, nullif(_order->>'unit',''),
      nullif(_order->>'order_date','')::date, nullif(_order->>'delivery_date','')::date,
      nullif(_order->>'source_observations',''), coalesce(_order->>'source_system','SMB'),
      now(), nullif(_order->>'source_hash',''), 'active', null
    )
    returning id into f_id;
    insert into public.kanban_assignments(ficha_id,sector_id,stage_id) values(f_id,sector_id,stage_id);
    insert into public.status_history(ficha_id,sector_id,previous_stage_id,new_stage_id,changed_at,observation,source,movement_type)
    values(f_id,sector_id,null,stage_id,now(),'Importado do SMB','system','entrada');
  else
    update public.fichas
    set order_number = coalesce(_order->>'order_number', order_number),
        customer = coalesce(_order->>'customer', customer),
        customer_code = case when nullif(trim(customer_code),'') is null and nullif(trim(_order->>'customer_code'),'') is not null then nullif(trim(_order->>'customer_code'),'') else customer_code end,
        seller_name = case when nullif(trim(seller_name),'') is null and nullif(trim(_order->>'seller_name'),'') is not null then nullif(trim(_order->>'seller_name'),'') else seller_name end,
        product_summary = case when _order ? 'product_summary' then nullif(_order->>'product_summary','') else product_summary end,
        quantity = case when _order ? 'quantity' and nullif(_order->>'quantity','') is not null then (_order->>'quantity')::numeric else quantity end,
        unit = case when _order ? 'unit' then nullif(_order->>'unit','') else unit end,
        order_date = case when _order ? 'order_date' and nullif(_order->>'order_date','') is not null then (_order->>'order_date')::date else order_date end,
        delivery_date = case when _order ? 'delivery_date' and nullif(_order->>'delivery_date','') is not null then (_order->>'delivery_date')::date else delivery_date end,
        source_observations = case when _order ? 'source_observations' then nullif(_order->>'source_observations','') else source_observations end,
        source_system = coalesce(_order->>'source_system', source_system),
        source_synced_at = now(), source_hash = nullif(_order->>'source_hash',''),
        sync_state = 'active', sync_warning = null, updated_at = now()
    where id = f_id;
  end if;

  delete from public.ficha_items where ficha_id = f_id;
  for item in select * from jsonb_array_elements(coalesce(_order->'items','[]'::jsonb)) loop
    line := line + 1;
    insert into public.ficha_items(ficha_id,line_no,code,product,description,quantity,unit)
    values(f_id,line,nullif(item->>'code',''),nullif(item->>'product',''),nullif(item->>'description',''),
      case when nullif(item->>'quantity','') is null then null else (item->>'quantity')::numeric end,
      nullif(item->>'unit',''));
  end loop;
  return f_id;
end
$function$;