alter table public.fichas
  add column if not exists customer_code text;

alter table public.kanban_assignments
  add column if not exists production_returned boolean not null default false,
  add column if not exists return_count integer not null default 0,
  add column if not exists last_return_reason_category text,
  add column if not exists last_return_reason text,
  add column if not exists last_returned_at timestamptz,
  add column if not exists last_returned_by uuid references public.profiles(id);

alter table public.status_history
  add column if not exists movement_type text not null default 'entrada',
  add column if not exists return_reason_category text,
  add column if not exists return_reason text;

update public.status_history h
set movement_type = case
  when h.previous_stage_id is null then 'entrada'
  when (select ns.position from public.stages ns where ns.id = h.new_stage_id) <
       (select ps.position from public.stages ps where ps.id = h.previous_stage_id)
    then 'retorno'
  else 'avanco'
end;

update public.system_settings
set value = '["customer","customer_code","product","quantity","delivery","responsible","priority","last_move"]'::jsonb,
    updated_at = now()
where key = 'card_fields';

create index if not exists idx_kanban_production_returned
  on public.kanban_assignments(production_returned)
  where production_returned = true;

create index if not exists idx_status_history_movement_type
  on public.status_history(ficha_id, movement_type, changed_at desc);

drop function if exists public.transition_ficha(uuid,uuid,uuid,text,text);
drop function if exists public.transition_ficha(uuid,uuid,uuid,text,text,text);

create or replace function public.transition_ficha(
  _ficha_id uuid,
  _new_stage_id uuid,
  _changed_by uuid,
  _observation text default '',
  _source text default 'kanban',
  _return_reason_category text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $func$
declare
  ka public.kanban_assignments%rowtype;
  target public.stages%rowtype;
  current_stage public.stages%rowtype;
  history_id uuid;
  movement text;
begin
  if not public.can_operate(auth.uid()) then raise exception 'Usuário sem permissão para alterar etapas.'; end if;
  if not exists(select 1 from public.profiles where id = _changed_by and active) then raise exception 'Usuário responsável inválido.'; end if;
  select * into ka from public.kanban_assignments where ficha_id = _ficha_id for update;
  if ka.ficha_id is null then raise exception 'Ficha não encontrada no Kanban.'; end if;
  select * into current_stage from public.stages where id = ka.stage_id;
  select * into target from public.stages where id = _new_stage_id and sector_id = ka.sector_id and active;
  if target.id is null then raise exception 'A etapa de destino não pertence ao setor ou está inativa.'; end if;
  if target.id = ka.stage_id then raise exception 'A ficha já está nesta etapa.'; end if;

  movement := case when target.position < current_stage.position then 'retorno' else 'avanco' end;

  if movement = 'retorno' then
    if coalesce(trim(_return_reason_category), '') = '' then raise exception 'Selecione o motivo do retorno da etapa.'; end if;
    if coalesce(trim(_observation), '') = '' then raise exception 'Descreva o motivo do retorno da etapa.'; end if;
    update public.kanban_assignments
    set stage_id = target.id, entered_stage_at = now(), last_changed_by = _changed_by,
        completed_at = null, production_started_at = coalesce(production_started_at, now()),
        production_returned = true, return_count = return_count + 1,
        last_return_reason_category = trim(_return_reason_category),
        last_return_reason = trim(_observation), last_returned_at = now(),
        last_returned_by = _changed_by, updated_at = now()
    where ficha_id = _ficha_id;
  else
    update public.kanban_assignments
    set stage_id = target.id, entered_stage_at = now(), last_changed_by = _changed_by,
        completed_at = case when target.is_final then now() else null end,
        production_started_at = coalesce(production_started_at, now()), updated_at = now()
    where ficha_id = _ficha_id;
  end if;

  insert into public.status_history(
    ficha_id, sector_id, previous_stage_id, new_stage_id, changed_by_user_id,
    performed_by_user_id, changed_at, observation, source, movement_type,
    return_reason_category, return_reason
  )
  values(
    _ficha_id, ka.sector_id, ka.stage_id, target.id, _changed_by, auth.uid(),
    now(), nullif(trim(_observation), ''), coalesce(_source, 'kanban'), movement,
    case when movement = 'retorno' then nullif(trim(_return_reason_category), '') else null end,
    case when movement = 'retorno' then nullif(trim(_observation), '') else null end
  )
  returning id into history_id;

  return history_id;
end
$func$;

create or replace function public.update_customer_code(_ficha_id uuid, _customer_code text)
returns uuid language plpgsql security definer set search_path = public
as $func$
declare result_id uuid;
begin
  if not public.can_operate(auth.uid()) then raise exception 'Usuário sem permissão para editar o código do cliente.'; end if;
  update public.fichas set customer_code = nullif(trim(_customer_code), ''), updated_at = now()
  where id = _ficha_id
  returning id into result_id;
  if result_id is null then raise exception 'Ficha não encontrada.'; end if;
  return result_id;
end
$func$;

revoke execute on function public.transition_ficha(uuid,uuid,uuid,text,text,text) from public, anon;
revoke execute on function public.update_customer_code(uuid,text) from public, anon;
grant execute on function public.transition_ficha(uuid,uuid,uuid,text,text,text) to authenticated;
grant execute on function public.update_customer_code(uuid,text) to authenticated;
