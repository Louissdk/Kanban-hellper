-- Ensure the reversible test-mode storage exists and scope temporary elevated permissions
-- strictly to the user who activated the test session.
create schema if not exists private;

create table if not exists private.kanban_test_mode (
  singleton boolean primary key default true check (singleton),
  active boolean not null default false,
  activated_by uuid null,
  activated_at timestamptz null,
  snapshot jsonb null
);

insert into private.kanban_test_mode(singleton,active)
values(true,false)
on conflict(singleton) do nothing;

revoke all on private.kanban_test_mode from public,anon,authenticated;

create or replace function public.has_role(_user_id uuid,_role app_role)
returns boolean
language sql
stable
security definer
set search_path=public,private
as $function$
  select case
    when coalesce((select active from private.kanban_test_mode where singleton),false)
      and _user_id=(select activated_by from private.kanban_test_mode where singleton)
      then true
    else exists(
      select 1 from public.user_roles
      where user_id=_user_id and role=_role
    )
  end;
$function$;

revoke execute on function public.has_role(uuid,public.app_role) from public,anon;
grant execute on function public.has_role(uuid,public.app_role) to authenticated,service_role;
