-- Only administrators may choose a non-default priority during creation.
create or replace function public.create_manual_ficha_with_items(
  _order_number text,
  _customer text,
  _items jsonb default '[]'::jsonb,
  _delivery_date date default null,
  _sector_id uuid default null,
  _priority text default 'normal',
  _seller_name text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $function$
declare
  f_id uuid;
  target_stage uuid;
  item_count integer;
  first_product text;
  first_quantity numeric;
  first_unit text;
  row_item record;
  effective_priority text;
begin
  if not public.can_operate(auth.uid()) then raise exception 'Usuário sem permissão para criar fichas.'; end if;
  if coalesce(trim(_order_number),'')='' then raise exception 'Número da ficha é obrigatório.'; end if;
  if coalesce(trim(_customer),'')='' then raise exception 'Cliente é obrigatório.'; end if;
  if not exists(select 1 from public.sectors where id=_sector_id and active) then raise exception 'Setor inválido ou inativo.'; end if;
  if jsonb_typeof(_items)<>'array' or jsonb_array_length(_items)=0 then raise exception 'Adicione pelo menos um item ao pedido.'; end if;

  for row_item in
    select * from jsonb_to_recordset(_items) as x(code text,product text,description text,quantity numeric,unit text)
  loop
    if coalesce(trim(row_item.product),'')='' and coalesce(trim(row_item.description),'')='' then raise exception 'Cada item precisa de produto ou descrição.'; end if;
    if row_item.quantity is not null and row_item.quantity<0 then raise exception 'A quantidade de um item não pode ser negativa.'; end if;
  end loop;

  effective_priority := case when public.has_role(auth.uid(),'admin') then coalesce(_priority,'normal') else 'normal' end;
  if effective_priority not in ('baixa','normal','alta','urgente') then raise exception 'Prioridade inválida.'; end if;

  select id into target_stage from public.stages where sector_id=_sector_id and active order by position limit 1;
  if target_stage is null then raise exception 'O setor não possui etapa ativa.'; end if;

  select coalesce(nullif(trim(product),''),nullif(trim(description),'')),quantity,nullif(trim(coalesce(unit,'UND')),'')
  into first_product,first_quantity,first_unit
  from jsonb_to_record(_items->0) as x(code text,product text,description text,quantity numeric,unit text);

  insert into public.fichas(order_number,customer,product_summary,quantity,unit,delivery_date,seller_name,source_system,source_synced_at,sync_state)
  values(trim(_order_number),trim(_customer),first_product,
         case when jsonb_array_length(_items)=1 then first_quantity else null end,
         case when jsonb_array_length(_items)=1 then first_unit else null end,
         _delivery_date,nullif(trim(coalesce(_seller_name,'')),''),
         'manual',null,'active')
  returning id into f_id;

  insert into public.ficha_items(ficha_id,line_no,code,product,description,quantity,unit)
  select f_id,row_number() over(),nullif(trim(x.code),''),nullif(trim(x.product),''),
         nullif(trim(x.description),''),x.quantity,nullif(trim(coalesce(x.unit,'UND')),'')
  from jsonb_to_recordset(_items) as x(code text,product text,description text,quantity numeric,unit text);

  insert into public.kanban_assignments(ficha_id,sector_id,stage_id,priority,last_changed_by)
  values(f_id,_sector_id,target_stage,effective_priority,auth.uid());

  insert into public.status_history(ficha_id,sector_id,previous_stage_id,new_stage_id,changed_by_user_id,performed_by_user_id,changed_at,observation,source)
  values(f_id,_sector_id,null,target_stage,auth.uid(),auth.uid(),now(),'Ficha manual criada','manual');

  return f_id;
end
$function$;

create or replace function public.create_smb_ficha_from_lookup(
  _order jsonb,
  _sector_id uuid,
  _priority text default 'normal'
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $function$
declare
  f_id uuid;
  target_stage uuid;
  customer_matches integer;
  resolved_customer_code text;
  normalized_status text;
  status_code text;
  pdd text;
  opened timestamptz;
  due date;
  customer_name text;
  order_items jsonb;
  item jsonb;
  line_no integer:=0;
  duplicate_sector text;
  duplicate_stage text;
  effective_priority text;
begin
  if not public.can_operate(auth.uid()) then raise exception 'Usuário sem permissão para inserir pedidos.'; end if;
  pdd:=nullif(trim(coalesce(_order->>'external_order_id',_order->>'pdd_id')),'');
  if pdd is null then raise exception 'pdd_id é obrigatório.'; end if;

  effective_priority := case when public.has_role(auth.uid(),'admin') then coalesce(_priority,'normal') else 'normal' end;
  if effective_priority not in ('baixa','normal','alta','urgente') then raise exception 'Prioridade inválida.'; end if;

  status_code:=upper(trim(coalesce(_order->>'status_smb',_order->>'smb_status','')));
  normalized_status:=case
    when status_code='I' then 'INICIADO'
    when status_code='P' then 'EM PRODUÇÃO'
    when status_code='A' then 'EM ATRASO'
    when status_code='C' then 'CONCLUÍDO'
    when status_code='' and upper(trim(coalesce(_order->>'status_smb_descricao','')))='INICIADO' then 'INICIADO'
    when status_code='' and upper(trim(coalesce(_order->>'status_smb_descricao','')))='EM PRODUÇÃO' then 'EM PRODUÇÃO'
    when status_code='' and upper(trim(coalesce(_order->>'status_smb_descricao','')))='EM ATRASO' then 'EM ATRASO'
    when status_code='' and upper(trim(coalesce(_order->>'status_smb_descricao','')))='CONCLUÍDO' then 'CONCLUÍDO'
    else null
  end;

  select f.id,s.name,st.name into f_id,duplicate_sector,duplicate_stage
  from public.fichas f
  left join public.kanban_assignments ka on ka.ficha_id=f.id
  left join public.sectors s on s.id=ka.sector_id
  left join public.stages st on st.id=ka.stage_id
  where f.pdd_id=pdd limit 1;

  if f_id is not null then
    return jsonb_build_object('created',false,'duplicate',true,'ficha_id',f_id,'pdd_id',pdd,'sector_name',duplicate_sector,'stage_name',duplicate_stage);
  end if;

  if not exists(select 1 from public.sectors where id=_sector_id and active) then raise exception 'Setor inválido ou inativo.'; end if;

  opened:=public.parse_smb_datetime(coalesce(_order->>'abertura',_order->>'opened_at'));
  due:=public.parse_smb_date(coalesce(_order->>'data_entrega',_order->>'delivery_date'));
  if opened is null then raise exception 'Data/hora de abertura do SMB é obrigatória.'; end if;

  if normalized_status='CONCLUÍDO' then
    select st.id into target_stage from public.stages st
    where st.sector_id=_sector_id and st.active=true and st.name='Enviado/Finalizado'
    order by st.is_final desc,st.position desc limit 1;
  else
    target_stage:=public.first_active_stage(_sector_id);
  end if;
  if target_stage is null then raise exception 'O setor não possui uma etapa de destino configurada.'; end if;

  customer_name:=nullif(trim(coalesce(_order->'cliente'->>'nome',_order->>'customer')),'');
  select count(*),max(c.codigo_cliente) into customer_matches,resolved_customer_code
  from public.clientes c where c.ativo=true and upper(trim(c.nome))=upper(trim(coalesce(customer_name,'')));
  if customer_matches<>1 then resolved_customer_code:=null; end if;

  order_items:=case
    when jsonb_typeof(_order->'itens')='array' then _order->'itens'
    when jsonb_typeof(_order->'items')='array' then _order->'items'
    else '[]'::jsonb
  end;

  insert into public.fichas(
    pdd_id,external_order_id,order_number,customer,codigo_cliente,customer_code,seller_name,
    product_summary,quantity,unit,order_date,opened_at,delivery_date,
    smb_cliente_id,pedido_cliente,data_entrega,envio,status_smb,status_smb_descricao,
    smb_ranking,source_observations,source_system,source_synced_at,source_hash,
    sync_state,sync_warning,smb_status
  )
  values(
    pdd,pdd,
    coalesce(nullif(trim(coalesce(_order->>'pedido_cliente',_order->>'customer_order_number',_order->>'order_number')),''),pdd),
    coalesce(customer_name,''),resolved_customer_code,resolved_customer_code,
    nullif(trim(coalesce(_order->>'vendedor',_order->>'seller')),''),
    nullif(trim(_order->>'product_summary'),''),
    case when nullif(trim(_order->>'quantity'),'') is null then null else (_order->>'quantity')::numeric end,
    nullif(trim(_order->>'unit'),''),
    opened::date,opened,due,
    nullif(trim(coalesce(_order->'cliente'->>'smb_cliente_id',_order->>'smb_cliente_id')),''),
    nullif(trim(coalesce(_order->>'pedido_cliente',_order->>'customer_order_number',_order->>'order_number')),''),
    due,nullif(trim(_order->>'envio'),''),
    case when status_code in ('I','P','A','C') then status_code else null end,
    nullif(trim(_order->>'status_smb_descricao'),''),
    case when nullif(trim(_order->>'ranking'),'') ~ '^\\d+$' then (_order->>'ranking')::integer else null end,
    nullif(trim(coalesce(_order->>'observacoes',_order->>'source_observations')),''),
    'SMB',now(),nullif(trim(_order->>'source_hash'),''),
    'active',
    case
      when customer_matches>1 then 'Código do cliente não resolvido: múltiplas correspondências.'
      when customer_matches=0 and coalesce(customer_name,'')<>'' then 'Código do cliente não resolvido: cliente não encontrado.'
      else null
    end,
    normalized_status
  )
  returning id into f_id;

  insert into public.kanban_assignments(ficha_id,sector_id,stage_id,priority,last_changed_by,completed_at)
  values(f_id,_sector_id,target_stage,effective_priority,auth.uid(),case when status_code='C' then now() else null end);

  insert into public.status_history(ficha_id,sector_id,previous_stage_id,new_stage_id,changed_by_user_id,performed_by_user_id,changed_at,observation,source,movement_type)
  values(f_id,_sector_id,null,target_stage,auth.uid(),auth.uid(),now(),
    case when status_code='C' then 'Inserido via consulta SMB; pedido estava CONCLUÍDO no SMB.' else 'Pedido inserido via consulta SMB.' end,
    'SMB_LOOKUP','entrada');

  for item in select value from jsonb_array_elements(order_items)
  loop
    line_no:=line_no+1;
    insert into public.ficha_items(ficha_id,pdd_id,line_no,code,product,description,quantity,unit)
    values(
      f_id,pdd,
      coalesce(nullif(item->>'sequencia','')::integer,nullif(item->>'sequence','')::integer,nullif(item->>'item_sequence','')::integer,line_no),
      nullif(trim(coalesce(item->>'codigo',item->>'code')),''),
      nullif(trim(coalesce(item->>'produto',item->>'product')),''),
      nullif(trim(coalesce(item->>'descricao',item->>'description')),''),
      case
        when nullif(trim(coalesce(item->>'quantidade',item->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
        then replace(coalesce(item->>'quantidade',item->>'quantity'),',','.')::numeric
        else null
      end,
      nullif(trim(coalesce(item->>'unidade',item->>'unit')),'')
    );
  end loop;

  return jsonb_build_object('created',true,'duplicate',false,'ficha_id',f_id,'pdd_id',pdd,'completed_in_smb',status_code='C','stage_id',target_stage);
exception when unique_violation then
  select f.id,s.name,st.name into f_id,duplicate_sector,duplicate_stage
  from public.fichas f
  left join public.kanban_assignments ka on ka.ficha_id=f.id
  left join public.sectors s on s.id=ka.sector_id
  left join public.stages st on st.id=ka.stage_id
  where f.pdd_id=pdd limit 1;
  if f_id is not null then
    return jsonb_build_object('created',false,'duplicate',true,'ficha_id',f_id,'pdd_id',pdd,'sector_name',duplicate_sector,'stage_name',duplicate_stage);
  end if;
  raise;
end
$function$;
