revoke execute on function public.create_manual_ficha_with_items(
  text, text, jsonb, date, uuid, text, text
) from public;

grant execute on function public.create_manual_ficha_with_items(
  text, text, jsonb, date, uuid, text, text
) to authenticated;
