-- Kanban de Produção: schema operacional + integração SMB somente leitura
-- Safe to run against an existing Supabase project: tables/functions use IF NOT EXISTS / CREATE OR REPLACE.

create extension if not exists pgcrypto;

do $$ begin
  create type public.app_role as enum ('admin','supervisor','operator','viewer');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  role public.app_role not null,
  unique(user_id, role)
);

create table if not exists public.sectors (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text,
  active boolean not null default true,
  position integer not null default 1,
  is_default_import boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.stages (
  id uuid primary key default gen_random_uuid(),
  sector_id uuid not null references public.sectors(id) on delete cascade,
  name text not null,
  position integer not null default 1,
  active boolean not null default true,
  is_final boolean not null default false,
  color text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(sector_id, name)
);

create table if not exists public.fichas (
  id uuid primary key default gen_random_uuid(),
  external_order_id text unique,
  order_number text not null,
  customer text not null default '',
  product_summary text,
  quantity numeric,
  unit text,
  order_date date,
  delivery_date date,
  source_observations text,
  source_system text not null default 'manual',
  source_synced_at timestamptz,
  source_hash text,
  sync_state text not null default 'active' check (sync_state in ('active','not_seen_in_last_sync','archived')),
  sync_warning text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ficha_items (
  id uuid primary key default gen_random_uuid(),
  ficha_id uuid not null references public.fichas(id) on delete cascade,
  line_no integer not null default 1,
  code text,
  product text,
  description text,
  quantity numeric,
  unit text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(ficha_id, line_no)
);

create table if not exists public.kanban_assignments (
  ficha_id uuid primary key references public.fichas(id) on delete cascade,
  sector_id uuid not null references public.sectors(id),
  stage_id uuid not null references public.stages(id),
  priority text not null default 'normal' check (priority in ('baixa','normal','alta','urgente')),
  responsible_id uuid references public.profiles(id),
  internal_notes text,
  production_started_at timestamptz,
  completed_at timestamptz,
  entered_stage_at timestamptz not null default now(),
  last_changed_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.status_history (
  id uuid primary key default gen_random_uuid(),
  ficha_id uuid not null references public.fichas(id) on delete cascade,
  sector_id uuid not null references public.sectors(id),
  previous_stage_id uuid references public.stages(id),
  new_stage_id uuid not null references public.stages(id),
  changed_by_user_id uuid references public.profiles(id),
  performed_by_user_id uuid references public.profiles(id),
  changed_at timestamptz not null default now(),
  observation text,
  source text not null default 'kanban'
);

create table if not exists public.sector_transfer_history (
  id uuid primary key default gen_random_uuid(),
  ficha_id uuid not null references public.fichas(id) on delete cascade,
  previous_sector_id uuid references public.sectors(id),
  new_sector_id uuid not null references public.sectors(id),
  previous_stage_id uuid references public.stages(id),
  new_stage_id uuid not null references public.stages(id),
  changed_by_user_id uuid references public.profiles(id),
  performed_by_user_id uuid references public.profiles(id),
  changed_at timestamptz not null default now(),
  observation text
);

create table if not exists public.sync_runs (
  id uuid primary key default gen_random_uuid(),
  status text not null default 'requested' check (status in ('requested','running','success','partial','failed')),
  trigger text not null default 'manual',
  requested_by uuid references public.profiles(id),
  started_at timestamptz,
  finished_at timestamptz,
  created_at timestamptz not null default now(),
  total_read integer not null default 0,
  inserted integer not null default 0,
  updated integer not null default 0,
  skipped integer not null default 0,
  errors integer not null default 0,
  warnings integer not null default 0,
  error_details text
);

create table if not exists public.sync_errors (
  id uuid primary key default gen_random_uuid(),
  sync_run_id uuid not null references public.sync_runs(id) on delete cascade,
  external_order_id text,
  level text not null default 'error',
  message text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.system_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

create index if not exists idx_stages_sector_position on public.stages(sector_id, position);
create index if not exists idx_fichas_external_order_id on public.fichas(external_order_id);
create index if not exists idx_fichas_delivery_date on public.fichas(delivery_date);
create index if not exists idx_fichas_sync_state on public.fichas(sync_state);
create index if not exists idx_kanban_sector_stage on public.kanban_assignments(sector_id, stage_id);
create index if not exists idx_status_history_ficha_changed on public.status_history(ficha_id, changed_at desc);
create index if not exists idx_sync_runs_created on public.sync_runs(created_at desc);

create or replace function public.first_active_stage(_sector_id uuid)
returns uuid language sql stable security definer set search_path = public as $$
  select id from public.stages
  where sector_id = _sector_id and active
  order by position, name limit 1
$$;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create or replace function public.can_manage(_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(_user_id,'admin') or public.has_role(_user_id,'supervisor')
$$;

create or replace function public.can_operate(_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.can_manage(_user_id) or public.has_role(_user_id,'operator')
$$;

create or replace function public.reorder_stages(_sector_id uuid, _stage_ids uuid[])
returns void language plpgsql security definer set search_path = public as $$
declare i integer; sid uuid;
begin
  if not public.has_role(auth.uid(),'admin') then raise exception 'Apenas administradores podem reordenar etapas.'; end if;
  for i in 1..coalesce(array_length(_stage_ids,1),0) loop
    sid := _stage_ids[i];
    update public.stages set position=i, updated_at=now() where id=sid and sector_id=_sector_id;
  end loop;
end $$;

create or replace function public.delete_stage_safe(_stage_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare n integer; sid uuid; remaining integer;
begin
  if not public.has_role(auth.uid(),'admin') then raise exception 'Apenas administradores podem excluir etapas.'; end if;
  select sector_id into sid from public.stages where id=_stage_id;
  if sid is null then raise exception 'Etapa não encontrada.'; end if;
  select count(*) into n from public.kanban_assignments where stage_id=_stage_id;
  if n > 0 then raise exception 'A etapa possui fichas. Transfira as fichas antes de excluir.'; end if;
  select count(*) into remaining from public.stages where sector_id=sid and id<>_stage_id and active;
  if remaining < 1 then raise exception 'O setor precisa manter pelo menos uma etapa ativa.'; end if;
  delete from public.stages where id=_stage_id;
end $$;

create or replace function public.transition_ficha(
  _ficha_id uuid, _new_stage_id uuid, _changed_by uuid, _observation text default '', _source text default 'kanban'
)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  ka public.kanban_assignments%rowtype;
  target public.stages%rowtype;
  history_id uuid;
begin
  if not public.can_operate(auth.uid()) then raise exception 'Usuário sem permissão para alterar etapas.'; end if;
  if not exists(select 1 from public.profiles where id=_changed_by and active) then raise exception 'Usuário responsável inválido.'; end if;
  select * into ka from public.kanban_assignments where ficha_id=_ficha_id for update;
  if ka.ficha_id is null then raise exception 'Ficha não encontrada no Kanban.'; end if;
  select * into target from public.stages where id=_new_stage_id and sector_id=ka.sector_id and active;
  if target.id is null then raise exception 'A etapa de destino não pertence ao setor ou está inativa.'; end if;
  if target.id=ka.stage_id then raise exception 'A ficha já está nesta etapa.'; end if;

  update public.kanban_assignments
    set stage_id=target.id,
        entered_stage_at=now(),
        last_changed_by=_changed_by,
        completed_at=case when target.is_final then now() else null end,
        updated_at=now(),
        production_started_at=coalesce(production_started_at, now())
    where ficha_id=_ficha_id;

  insert into public.status_history(ficha_id,sector_id,previous_stage_id,new_stage_id,changed_by_user_id,performed_by_user_id,changed_at,observation,source)
  values(_ficha_id,ka.sector_id,ka.stage_id,target.id,_changed_by,auth.uid(),now(),nullif(trim(_observation),''),coalesce(_source,'kanban'))
  returning id into history_id;

  return history_id;
end $$;

create or replace function public.transfer_ficha_sector(
  _ficha_id uuid, _new_sector_id uuid, _changed_by uuid, _observation text default ''
)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  ka public.kanban_assignments%rowtype;
  ns public.sectors%rowtype;
  old_stage uuid;
  new_stage uuid;
  event_id uuid;
begin
  if not public.can_manage(auth.uid()) then raise exception 'Usuário sem permissão para transferir setores.'; end if;
  if not exists(select 1 from public.profiles where id=_changed_by and active) then raise exception 'Usuário responsável inválido.'; end if;
  select * into ka from public.kanban_assignments where ficha_id=_ficha_id for update;
  select * into ns from public.sectors where id=_new_sector_id and active;
  if ka.ficha_id is null or ns.id is null then raise exception 'Ficha ou setor inválido.'; end if;
  if ka.sector_id=_new_sector_id then raise exception 'A ficha já pertence a este setor.'; end if;
  old_stage := ka.stage_id;
  new_stage := public.first_active_stage(_new_sector_id);
  if new_stage is null then raise exception 'O setor de destino não possui etapa ativa.'; end if;

  update public.kanban_assignments set sector_id=_new_sector_id, stage_id=new_stage, entered_stage_at=now(), completed_at=null, last_changed_by=_changed_by, updated_at=now()
  where ficha_id=_ficha_id;

  insert into public.sector_transfer_history(ficha_id,previous_sector_id,new_sector_id,previous_stage_id,new_stage_id,changed_by_user_id,performed_by_user_id,observation)
  values(_ficha_id,ka.sector_id,_new_sector_id,old_stage,new_stage,_changed_by,auth.uid(),nullif(trim(_observation),''))
  returning id into event_id;
  return event_id;
end $$;

create or replace function public.ingest_smb_order(_order jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  f_id uuid;
  sector_id uuid;
  stage_id uuid;
  item jsonb;
  line integer := 0;
  existing_hash text;
begin
  -- This function is intended for the service-role worker only.
  if coalesce(current_setting('request.jwt.claims', true)::jsonb->>'role','') <> 'service_role' then raise exception 'Somente o worker de integração pode importar pedidos.'; end if;
  if coalesce(_order->>'external_order_id','') = '' then raise exception 'external_order_id é obrigatório.'; end if;

  select id, source_hash into f_id, existing_hash
  from public.fichas where external_order_id=_order->>'external_order_id' for update;

  if f_id is null then
    select id into sector_id from public.sectors where active and is_default_import order by position limit 1;
    if sector_id is null then
      select id into sector_id from public.sectors where active order by position limit 1;
    end if;
    if sector_id is null then raise exception 'Nenhum setor ativo configurado para importação.'; end if;
    stage_id := public.first_active_stage(sector_id);
    if stage_id is null then raise exception 'O setor de importação não possui etapa ativa.'; end if;

    insert into public.fichas(external_order_id,order_number,customer,product_summary,quantity,unit,order_date,delivery_date,source_observations,source_system,source_synced_at,source_hash,sync_state,sync_warning)
    values(
      _order->>'external_order_id',
      coalesce(_order->>'order_number',_order->>'external_order_id'),
      coalesce(_order->>'customer',''),
      nullif(_order->>'product_summary',''),
      nullif(_order->>'quantity','')::numeric,
      nullif(_order->>'unit',''),
      nullif(_order->>'order_date','')::date,
      nullif(_order->>'delivery_date','')::date,
      nullif(_order->>'source_observations',''),
      coalesce(_order->>'source_system','SMB'),
      now(),
      nullif(_order->>'source_hash',''),
      'active', null
    ) returning id into f_id;

    insert into public.kanban_assignments(ficha_id,sector_id,stage_id) values(f_id,sector_id,stage_id);
    insert into public.status_history(ficha_id,sector_id,previous_stage_id,new_stage_id,changed_at,observation,source)
    values(f_id,sector_id,null,stage_id,now(),'Importado do SMB','system');
  else
    update public.fichas set
      order_number=coalesce(_order->>'order_number',order_number),
      customer=coalesce(_order->>'customer',customer),
      product_summary=case when _order ? 'product_summary' then nullif(_order->>'product_summary','') else product_summary end,
      quantity=case when _order ? 'quantity' and nullif(_order->>'quantity','') is not null then (_order->>'quantity')::numeric else quantity end,
      unit=case when _order ? 'unit' then nullif(_order->>'unit','') else unit end,
      order_date=case when _order ? 'order_date' and nullif(_order->>'order_date','') is not null then (_order->>'order_date')::date else order_date end,
      delivery_date=case when _order ? 'delivery_date' and nullif(_order->>'delivery_date','') is not null then (_order->>'delivery_date')::date else delivery_date end,
      source_observations=case when _order ? 'source_observations' then nullif(_order->>'source_observations','') else source_observations end,
      source_system=coalesce(_order->>'source_system',source_system),
      source_synced_at=now(),
      source_hash=nullif(_order->>'source_hash',''),
      sync_state='active',
      sync_warning=null,
      updated_at=now()
    where id=f_id;
  end if;

  delete from public.ficha_items where ficha_id=f_id;
  for item in select * from jsonb_array_elements(coalesce(_order->'items','[]'::jsonb)) loop
    line := line + 1;
    insert into public.ficha_items(ficha_id,line_no,code,product,description,quantity,unit)
    values(f_id,line,nullif(item->>'code',''),nullif(item->>'product',''),nullif(item->>'description',''),
      case when nullif(item->>'quantity','') is null then null else (item->>'quantity')::numeric end,
      nullif(item->>'unit',''));
  end loop;
  return f_id;
end $$;

create or replace function public.mark_unseen_orders(_seen_ids text[])
returns integer language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  if coalesce(current_setting('request.jwt.claims', true)::jsonb->>'role','') <> 'service_role' then raise exception 'Somente o worker de integração pode executar esta operação.'; end if;
  if coalesce(array_length(_seen_ids,1),0)=0 then raise exception 'Lista vazia não é uma sincronização válida.'; end if;
  update public.fichas
    set sync_state='not_seen_in_last_sync', updated_at=now()
    where source_system='SMB'
      and sync_state='active'
      and not (external_order_id = any(_seen_ids));
  get diagnostics n = row_count;
  return n;
end $$;

create or replace function public.stage_avg_durations(_sector_id uuid)
returns table(stage_id uuid, avg_hours numeric)
language sql stable security definer set search_path = public as $func$
  select x.new_stage_id,
         round(avg(extract(epoch from (x.next_at-x.changed_at))/3600)::numeric,2)
  from (
    select h.new_stage_id, h.changed_at,
           lead(h.changed_at) over(partition by h.ficha_id order by h.changed_at) as next_at
    from public.status_history h
    where h.sector_id=_sector_id
  ) x
  where x.next_at is not null
  group by x.new_stage_id
$func$;

-- First sector + exact initial Cartucho workflow.
insert into public.sectors(name,description,active,position,is_default_import)
values('Cartucho','Fluxo inicial do setor Cartucho.',true,1,true)
on conflict (name) do update set is_default_import=true;

insert into public.stages(sector_id,name,position,active,is_final)
select s.id, v.name, v.position, true, v.position=13
from public.sectors s
cross join (values
 ('Corte de porcelana',1),('Enrolar porcelana',2),('Montagem',3),('Soldagem',4),
 ('Enchimento',5),('Laminador',6),('Retífica',7),('Tirar umidade',8),
 ('Detalhe',9),('Acabamento',10),('Expedição',11),('Embalado',12),('Enviado/Finalizado',13)
) v(name,position)
where s.name='Cartucho'
on conflict (sector_id,name) do update set position=excluded.position, active=true, is_final=excluded.is_final;

insert into public.system_settings(key,value)
values
 ('card_fields','["customer","product","quantity","delivery","responsible","priority","last_move"]'::jsonb),
 ('stale_hours','48'::jsonb),
 ('sync','{"interval_minutes":30,"enabled":true}'::jsonb)
on conflict (key) do nothing;

-- Profiles for new auth users.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id,full_name,email)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),new.email)
  on conflict (id) do update set email=excluded.email, full_name=case when public.profiles.full_name='' then excluded.full_name else public.profiles.full_name end;
  if not exists(select 1 from public.user_roles) then
    insert into public.user_roles(user_id,role) values(new.id,'admin');
  else
    insert into public.user_roles(user_id,role) values(new.id,'viewer') on conflict do nothing;
  end if;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.sectors enable row level security;
alter table public.stages enable row level security;
alter table public.fichas enable row level security;
alter table public.ficha_items enable row level security;
alter table public.kanban_assignments enable row level security;
alter table public.status_history enable row level security;
alter table public.sector_transfer_history enable row level security;
alter table public.sync_runs enable row level security;
alter table public.sync_errors enable row level security;
alter table public.system_settings enable row level security;

drop policy if exists profiles_select_authenticated on public.profiles;
create policy profiles_select_authenticated on public.profiles for select to authenticated using (true);
drop policy if exists profiles_admin_update on public.profiles;
create policy profiles_admin_update on public.profiles for update to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

drop policy if exists roles_select_authenticated on public.user_roles;
create policy roles_select_authenticated on public.user_roles for select to authenticated using (true);
drop policy if exists roles_admin_write on public.user_roles;
create policy roles_admin_write on public.user_roles for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

drop policy if exists sectors_select_authenticated on public.sectors;
create policy sectors_select_authenticated on public.sectors for select to authenticated using (true);
drop policy if exists sectors_admin_write on public.sectors;
create policy sectors_admin_write on public.sectors for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

drop policy if exists stages_select_authenticated on public.stages;
create policy stages_select_authenticated on public.stages for select to authenticated using (true);
drop policy if exists stages_admin_write on public.stages;
create policy stages_admin_write on public.stages for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

drop policy if exists fichas_select_authenticated on public.fichas;
create policy fichas_select_authenticated on public.fichas for select to authenticated using (true);
drop policy if exists ficha_items_select_authenticated on public.ficha_items;
create policy ficha_items_select_authenticated on public.ficha_items for select to authenticated using (true);

drop policy if exists kanban_select_authenticated on public.kanban_assignments;
create policy kanban_select_authenticated on public.kanban_assignments for select to authenticated using (true);
drop policy if exists kanban_manage_authenticated on public.kanban_assignments;
create policy kanban_manage_authenticated on public.kanban_assignments for update to authenticated using (public.can_operate(auth.uid())) with check (public.can_operate(auth.uid()));

drop policy if exists history_select_authenticated on public.status_history;
create policy history_select_authenticated on public.status_history for select to authenticated using (true);
drop policy if exists transfer_history_select_authenticated on public.sector_transfer_history;
create policy transfer_history_select_authenticated on public.sector_transfer_history for select to authenticated using (true);

drop policy if exists sync_runs_select_authenticated on public.sync_runs;
create policy sync_runs_select_authenticated on public.sync_runs for select to authenticated using (true);
drop policy if exists sync_runs_request_authenticated on public.sync_runs;
create policy sync_runs_request_authenticated on public.sync_runs for insert to authenticated with check (public.has_role(auth.uid(),'admin') and requested_by=auth.uid());

drop policy if exists sync_errors_select_authenticated on public.sync_errors;
create policy sync_errors_select_authenticated on public.sync_errors for select to authenticated using (true);

drop policy if exists settings_select_authenticated on public.system_settings;
create policy settings_select_authenticated on public.system_settings for select to authenticated using (true);
drop policy if exists settings_admin_write on public.system_settings;
create policy settings_admin_write on public.system_settings for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- Audit history is append-only: no UPDATE/DELETE policy is created for authenticated users.
revoke update, delete on public.status_history from authenticated;
revoke update, delete on public.sector_transfer_history from authenticated;



-- Explicit Data API grants for the frontend and integration worker.
grant usage on schema public to authenticated, service_role;
grant select on public.profiles, public.user_roles, public.sectors, public.stages, public.fichas, public.ficha_items, public.kanban_assignments, public.status_history, public.sector_transfer_history, public.sync_runs, public.sync_errors, public.system_settings to authenticated;
grant update on public.profiles to authenticated;
grant insert, update, delete on public.user_roles, public.sectors, public.stages, public.system_settings to authenticated;
grant update on public.kanban_assignments to authenticated;
grant insert on public.sync_runs to authenticated;
grant execute on function public.reorder_stages(uuid,uuid[]) to authenticated;
grant execute on function public.delete_stage_safe(uuid) to authenticated;
grant execute on function public.transition_ficha(uuid,uuid,uuid,text,text) to authenticated;
grant execute on function public.transfer_ficha_sector(uuid,uuid,uuid,text) to authenticated;
grant execute on function public.create_manual_ficha(text,text,text,numeric,text,date,uuid,text) to authenticated;
grant execute on function public.first_active_stage(uuid) to authenticated, service_role;
grant execute on function public.has_role(uuid,public.app_role) to authenticated, service_role;
grant execute on function public.can_manage(uuid) to authenticated, service_role;
grant execute on function public.can_operate(uuid) to authenticated, service_role;
grant execute on function public.stage_avg_durations(uuid) to authenticated;
grant execute on function public.ingest_smb_order(jsonb) to service_role;
grant execute on function public.mark_unseen_orders(text[]) to service_role;
revoke execute on function public.handle_new_user() from public;
