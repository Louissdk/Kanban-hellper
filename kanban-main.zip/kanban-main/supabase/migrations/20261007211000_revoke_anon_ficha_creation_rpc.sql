DO $$
BEGIN
  REVOKE EXECUTE ON FUNCTION public.create_manual_ficha(
    text, text, text, numeric, text, date, uuid, text
  ) FROM PUBLIC, anon;
  REVOKE EXECUTE ON FUNCTION public.create_manual_ficha(
    text, text, text, numeric, text, date, uuid, text, text
  ) FROM PUBLIC, anon;

  REVOKE EXECUTE ON FUNCTION public.create_manual_ficha_with_items(
    text, text, jsonb, date, uuid, text, text
  ) FROM PUBLIC, anon;
  REVOKE EXECUTE ON FUNCTION public.create_manual_ficha_with_items(
    text, text, jsonb, date, uuid, text, text, boolean
  ) FROM PUBLIC, anon;

  REVOKE EXECUTE ON FUNCTION public.create_smb_ficha_from_lookup(
    jsonb, uuid, text
  ) FROM PUBLIC, anon;
END
$$;
