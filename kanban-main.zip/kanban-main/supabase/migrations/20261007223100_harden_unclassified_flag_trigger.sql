CREATE OR REPLACE FUNCTION public.clear_sector_classification_pending_on_move()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO 'public'
AS $function$
BEGIN
  IF NEW.sector_id IS DISTINCT FROM OLD.sector_id
     OR NEW.stage_id IS DISTINCT FROM OLD.stage_id THEN
    NEW.sector_classification_pending := false;
  END IF;

  RETURN NEW;
END;
$function$;
