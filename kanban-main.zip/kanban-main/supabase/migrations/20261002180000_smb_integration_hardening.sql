CREATE OR REPLACE FUNCTION public.process_smb_sync_result(_sync_run_id uuid, _result jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  run_row public.sync_runs%rowtype;
  order_row record;
  item jsonb;
  f_id uuid;
  customer_matches integer;
  resolved_customer_code text;
  normalized_status text;
  item_count integer;
  derived_summary text;
  derived_quantity numeric;
  derived_unit text;
  created_count integer := 0;
  updated_count integer := 0;
  ignored_count integer := 0;
  eligible_count integer := 0;
  error_count integer := 0;
  warning_count integer := 0;
  error_messages text[] := '{}';
begin
  if coalesce(current_setting('request.jwt.claims', true)::jsonb->>'role','') <> 'service_role' then
    raise exception 'Somente o serviço de integração pode processar resultados do robô.';
  end if;

  select * into run_row from public.sync_runs where id = _sync_run_id for update;
  if run_row.id is null then raise exception 'Execução de sincronização não encontrada.'; end if;
  if run_row.status not in ('requested','running') then
    raise exception 'A execução de sincronização não está aguardando processamento.';
  end if;

  update public.sync_runs
  set status='running',
      started_at=coalesce(started_at,now()),
      robot_status='available',
      robot_message=null,
      error_message=null
  where id=_sync_run_id;

  create temporary table if not exists tmp_smb_orders (
    external_order_id text,
    customer_order_number text,
    customer text,
    customer_code_hint text,
    seller text,
    opened_at timestamptz,
    delivery_date date,
    smb_status text,
    product_summary text,
    quantity numeric,
    unit text,
    source_observations text,
    source_hash text,
    items jsonb,
    seller_rank bigint
  ) on commit drop;

  truncate tmp_smb_orders;

  insert into tmp_smb_orders(
    external_order_id,customer_order_number,customer,customer_code_hint,seller,
    opened_at,delivery_date,smb_status,product_summary,quantity,unit,
    source_observations,source_hash,items
  )
  select
    d.external_order_id,d.customer_order_number,d.customer,d.customer_code_hint,d.seller,
    d.opened_at,d.delivery_date,d.smb_status,d.product_summary,d.quantity,d.unit,
    d.source_observations,d.source_hash,d.items
  from (
    select
      nullif(trim(x.value->>'external_order_id'),'') as external_order_id,
      nullif(trim(coalesce(x.value->>'customer_order_number',x.value->>'order_number')),'') as customer_order_number,
      nullif(trim(x.value->>'customer'),'') as customer,
      nullif(trim(x.value->>'customer_code'),'') as customer_code_hint,
      nullif(trim(coalesce(x.value->>'seller',x.value->>'seller_name')),'') as seller,
      case when trim(coalesce(x.value->>'opened_at','')) ~ '^\\d{4}-\\d{2}-\\d{2}T'
        then (x.value->>'opened_at')::timestamptz else null end as opened_at,
      case when trim(coalesce(x.value->>'delivery_date','')) ~ '^\\d{4}-\\d{2}-\\d{2}$'
        then (x.value->>'delivery_date')::date else null end as delivery_date,
      upper(trim(coalesce(x.value->>'smb_status',x.value->>'status'))) as smb_status,
      nullif(trim(x.value->>'product_summary'),'') as product_summary,
      case when nullif(trim(x.value->>'quantity'),'') is null then null else (x.value->>'quantity')::numeric end as quantity,
      nullif(trim(x.value->>'unit'),'') as unit,
      nullif(trim(x.value->>'source_observations'),'') as source_observations,
      nullif(trim(x.value->>'source_hash'),'') as source_hash,
      case when jsonb_typeof(x.value->'items')='array' then x.value->'items' else '[]'::jsonb end as items,
      row_number() over (
        partition by nullif(trim(x.value->>'external_order_id'),'')
        order by
          case when trim(coalesce(x.value->>'opened_at','')) ~ '^\\d{4}-\\d{2}-\\d{2}T'
            then (x.value->>'opened_at')::timestamptz else null end desc nulls last,
          jsonb_array_length(case when jsonb_typeof(x.value->'items')='array' then x.value->'items' else '[]'::jsonb end) desc,
          x.value->>'external_order_id' desc
      ) as duplicate_rank
    from jsonb_array_elements(coalesce(_result->'orders','[]'::jsonb)) x(value)
  ) d
  where d.external_order_id is not null
    and d.duplicate_rank=1;

  update tmp_smb_orders t
  set seller_rank=r.seller_rank
  from (
    select external_order_id,
           row_number() over(
             partition by upper(trim(seller))
             order by opened_at desc, external_order_id desc
           ) as seller_rank
    from tmp_smb_orders
    where opened_at is not null
      and opened_at::date >= date '2026-09-21'
      and nullif(trim(seller),'') is not null
  ) r
  where r.external_order_id=t.external_order_id;

  select count(*) into run_row.total_read from tmp_smb_orders;

  for order_row in
    select * from tmp_smb_orders
    order by upper(coalesce(seller,'__missing_seller__')), seller_rank nulls last
  loop
    normalized_status := upper(trim(coalesce(order_row.smb_status,'')));

    if order_row.external_order_id is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'Pedido sem external_order_id/pdd_id.');
      insert into public.sync_errors(sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at)
      values(_sync_run_id,null,'error','Pedido sem external_order_id/pdd_id.','missing_external_order_id','Pedido sem external_order_id/pdd_id.',now());
      continue;
    end if;

    if order_row.opened_at is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||order_row.external_order_id||'] data/hora de abertura inválida ou ausente.');
      insert into public.sync_errors(sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at)
      values(_sync_run_id,order_row.external_order_id,'error','Data/hora de abertura inválida ou ausente.','invalid_opened_at','Data/hora de abertura inválida ou ausente.',now());
      continue;
    end if;

    if order_row.opened_at::date < date '2026-09-21' then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    if nullif(trim(order_row.seller),'') is null or order_row.seller_rank is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||order_row.external_order_id||'] vendedor ausente; pedido não pode ser ranqueado.');
      insert into public.sync_errors(sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at)
      values(_sync_run_id,order_row.external_order_id,'error','Vendedor ausente; pedido não pode ser ranqueado.','missing_seller','Vendedor ausente; pedido não pode ser ranqueado.',now());
      continue;
    end if;

    if order_row.seller_rank <= 2 then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    if normalized_status not in ('INICIADO','EM PRODUÇÃO','EM ATRASO') then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    eligible_count:=eligible_count+1;

    select count(*), max(c.codigo_cliente)
      into customer_matches, resolved_customer_code
    from public.clientes c
    where c.ativo=true
      and coalesce(trim(order_row.customer),'') <> ''
      and upper(trim(c.nome))=upper(trim(order_row.customer));

    if customer_matches <> 1 then
      resolved_customer_code:=null;
      if customer_matches > 1 then
        warning_count:=warning_count+1;
        insert into public.sync_errors(sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at)
        values(_sync_run_id,order_row.external_order_id,'warning','Cliente com correspondência ambígua; código mantido NULL.','ambiguous_customer','Cliente com correspondência ambígua; código mantido NULL.',now());
      end if;
    end if;

    select count(*) into item_count from jsonb_array_elements(order_row.items);

    derived_summary:=coalesce(
      order_row.product_summary,
      (select nullif(trim(coalesce(i.value->>'description',i.value->>'product','')),'')
       from jsonb_array_elements(order_row.items) i(value)
       order by coalesce(nullif(i.value->>'sequence','')::integer,nullif(i.value->>'item_sequence','')::integer,999999)
       limit 1)
    );

    derived_quantity:=order_row.quantity;
    derived_unit:=order_row.unit;

    if derived_quantity is null then
      select sum((i.value->>'quantity')::numeric)
        into derived_quantity
      from jsonb_array_elements(order_row.items) i(value)
      where nullif(trim(i.value->>'quantity'),'') is not null;
    end if;

    if derived_unit is null and item_count=1 then
      select nullif(trim(i.value->>'unit'),'')
        into derived_unit
      from jsonb_array_elements(order_row.items) i(value)
      limit 1;
    end if;

    begin
      select f.id into f_id
      from public.fichas f
      where f.external_order_id=order_row.external_order_id
      for update;

      if f_id is null then
        insert into public.fichas(
          external_order_id,order_number,customer,product_summary,quantity,unit,
          order_date,opened_at,delivery_date,source_observations,source_system,
          source_synced_at,source_hash,sync_state,sync_warning,customer_code,seller_name,
          smb_status
        )
        values(
          order_row.external_order_id,
          coalesce(order_row.customer_order_number,order_row.external_order_id),
          coalesce(order_row.customer,''),
          derived_summary,derived_quantity,derived_unit,
          order_row.opened_at::date,order_row.opened_at,order_row.delivery_date,
          order_row.source_observations,'SMB',now(),
          coalesce(order_row.source_hash,md5(to_jsonb(order_row)::text)),
          'active',null,resolved_customer_code,order_row.seller,normalized_status
        )
        returning id into f_id;

        insert into public.kanban_assignments(ficha_id,sector_id,stage_id,priority)
        select f_id,s.id,public.first_active_stage(s.id),'normal'
        from public.sectors s
        where s.active and s.is_default_import
        order by s.position
        limit 1;

        if not exists(select 1 from public.kanban_assignments where ficha_id=f_id) then
          raise exception 'Nenhum setor ativo configurado para importação.';
        end if;

        insert into public.status_history(
          ficha_id,sector_id,previous_stage_id,new_stage_id,changed_at,observation,source,movement_type
        )
        select f_id,ka.sector_id,null,ka.stage_id,now(),'Importado do SMB','system','entrada'
        from public.kanban_assignments ka
        where ka.ficha_id=f_id;

        created_count:=created_count+1;
      else
        update public.fichas
        set order_number=coalesce(order_row.customer_order_number,order_number),
            customer=coalesce(order_row.customer,customer),
            product_summary=coalesce(derived_summary,product_summary),
            quantity=coalesce(derived_quantity,quantity),
            unit=coalesce(derived_unit,unit),
            order_date=order_row.opened_at::date,
            opened_at=order_row.opened_at,
            delivery_date=coalesce(order_row.delivery_date,delivery_date),
            source_observations=coalesce(order_row.source_observations,source_observations),
            source_system='SMB',
            source_synced_at=now(),
            source_hash=coalesce(order_row.source_hash,source_hash),
            sync_state='active',
            sync_warning=null,
            customer_code=case
              when nullif(trim(customer_code),'') is null then resolved_customer_code
              else customer_code
            end,
            seller_name=coalesce(order_row.seller,seller_name),
            smb_status=normalized_status,
            updated_at=now()
        where id=f_id;

        updated_count:=updated_count+1;
      end if;

      delete from public.ficha_items where ficha_id=f_id;

      for item in select value from jsonb_array_elements(order_row.items)
      loop
        insert into public.ficha_items(
          ficha_id,line_no,code,product,description,quantity,unit
        )
        values(
          f_id,
          coalesce(
            nullif(item->>'sequence','')::integer,
            nullif(item->>'item_sequence','')::integer,
            (select coalesce(max(line_no),0)+1 from public.ficha_items where ficha_id=f_id)
          ),
          nullif(trim(item->>'code'),''),
          nullif(trim(item->>'product'),''),
          nullif(trim(item->>'description'),''),
          case when nullif(trim(item->>'quantity'),'') is null then null else (item->>'quantity')::numeric end,
          nullif(trim(item->>'unit'),'')
        )
        on conflict (ficha_id,line_no) do update set
          code=excluded.code,
          product=excluded.product,
          description=excluded.description,
          quantity=excluded.quantity,
          unit=excluded.unit,
          updated_at=now();
      end loop;
    exception when others then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||order_row.external_order_id||'] '||sqlerrm);
      insert into public.sync_errors(sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at)
      values(_sync_run_id,order_row.external_order_id,'error',sqlerrm,'order_processing_error',sqlerrm,now());
    end;
  end loop;

  update public.sync_runs
  set status=case when error_count>0 then 'partial' else 'success' end,
      finished_at=now(),
      total_read=run_row.total_read,
      inserted=created_count,
      updated=updated_count,
      skipped=ignored_count,
      errors=error_count,
      warnings=warning_count,
      orders_scanned=run_row.total_read,
      orders_eligible=eligible_count,
      orders_created=created_count,
      orders_updated=updated_count,
      orders_ignored=ignored_count,
      errors_count=error_count,
      error_details=case when coalesce(array_length(error_messages,1),0)>0 then array_to_string(error_messages,E'\n') else null end,
      error_message=case when coalesce(array_length(error_messages,1),0)>0 then array_to_string(error_messages,E'\n') else null end,
      robot_status='available',
      robot_message=coalesce(nullif(trim(_result->>'message'),''),'Resultado recebido do serviço de leitura.')
  where id=_sync_run_id;

  return jsonb_build_object(
    'success',error_count=0,
    'sync_run_id',_sync_run_id,
    'orders_scanned',run_row.total_read,
    'orders_eligible',eligible_count,
    'orders_created',created_count,
    'orders_updated',updated_count,
    'orders_ignored',ignored_count,
    'errors_count',error_count,
    'warnings_count',warning_count,
    'status',case when error_count>0 then 'partial' else 'success' end
  );
end
$function$

