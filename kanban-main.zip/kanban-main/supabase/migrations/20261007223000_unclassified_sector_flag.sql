ALTER TABLE public.kanban_assignments
  ADD COLUMN IF NOT EXISTS sector_classification_pending boolean NOT NULL DEFAULT false;

COMMENT ON COLUMN public.kanban_assignments.sector_classification_pending
  IS 'Indica que a ficha foi colocada automaticamente em Cartucho por falta de classificação segura de setor. Deve ser removida quando a ficha mudar de etapa ou setor.';

CREATE OR REPLACE FUNCTION public.clear_sector_classification_pending_on_move()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  IF NEW.sector_id IS DISTINCT FROM OLD.sector_id
     OR NEW.stage_id IS DISTINCT FROM OLD.stage_id THEN
    NEW.sector_classification_pending := false;
  END IF;

  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS trg_clear_sector_classification_pending_on_move
  ON public.kanban_assignments;

CREATE TRIGGER trg_clear_sector_classification_pending_on_move
BEFORE UPDATE OF sector_id, stage_id
ON public.kanban_assignments
FOR EACH ROW
EXECUTE FUNCTION public.clear_sector_classification_pending_on_move();
