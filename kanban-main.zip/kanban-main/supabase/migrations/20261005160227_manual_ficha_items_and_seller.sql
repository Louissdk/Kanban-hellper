create or replace function public.create_manual_ficha_with_items(
  _order_number text,
  _customer text,
  _items jsonb default '[]'::jsonb,
  _delivery_date date default null,
  _sector_id uuid default null,
  _priority text default 'normal',
  _seller_name text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $function$
declare
  f_id uuid;
  target_stage uuid;
  item_count integer;
  first_product text;
  first_quantity numeric;
  first_unit text;
  row_item record;
begin
  if not public.can_operate(auth.uid()) then
    raise exception 'Usuário sem permissão para criar fichas.';
  end if;

  if coalesce(trim(_order_number), '') = '' then
    raise exception 'Número da ficha é obrigatório.';
  end if;

  if coalesce(trim(_customer), '') = '' then
    raise exception 'Cliente é obrigatório.';
  end if;

  if _priority not in ('baixa', 'normal', 'alta', 'urgente') then
    raise exception 'Prioridade inválida.';
  end if;

  if not exists (
    select 1 from public.sectors where id = _sector_id and active
  ) then
    raise exception 'Setor inválido ou inativo.';
  end if;

  if jsonb_typeof(_items) <> 'array' then
    raise exception 'Itens inválidos: esperado um array.';
  end if;

  item_count := jsonb_array_length(_items);

  if item_count = 0 then
    raise exception 'Adicione pelo menos um item ao pedido.';
  end if;

  for row_item in
    select *
    from jsonb_to_recordset(_items) as x(
      code text,
      product text,
      description text,
      quantity numeric,
      unit text
    )
  loop
    if coalesce(trim(row_item.product), '') = ''
       and coalesce(trim(row_item.description), '') = '' then
      raise exception 'Cada item precisa de produto ou descrição.';
    end if;

    if row_item.quantity is not null and row_item.quantity < 0 then
      raise exception 'A quantidade de um item não pode ser negativa.';
    end if;
  end loop;

  select id
    into target_stage
  from public.stages
  where sector_id = _sector_id
    and active
  order by position
  limit 1;

  if target_stage is null then
    raise exception 'O setor não possui etapa ativa.';
  end if;

  select
    coalesce(nullif(trim(product), ''), nullif(trim(description), '')),
    quantity,
    nullif(trim(coalesce(unit, 'UND')), '')
  into first_product, first_quantity, first_unit
  from jsonb_to_record(_items->0) as x(
    code text,
    product text,
    description text,
    quantity numeric,
    unit text
  );

  insert into public.fichas(
    order_number,
    customer,
    product_summary,
    quantity,
    unit,
    delivery_date,
    seller_name,
    source_system,
    source_synced_at,
    sync_state
  )
  values(
    trim(_order_number),
    trim(_customer),
    first_product,
    case when item_count = 1 then first_quantity else null end,
    case when item_count = 1 then first_unit else null end,
    _delivery_date,
    nullif(trim(coalesce(_seller_name, '')), ''),
    'manual',
    null,
    'active'
  )
  returning id into f_id;

  insert into public.ficha_items(
    ficha_id,
    line_no,
    code,
    product,
    description,
    quantity,
    unit
  )
  select
    f_id,
    row_number() over (),
    nullif(trim(x.code), ''),
    nullif(trim(x.product), ''),
    nullif(trim(x.description), ''),
    x.quantity,
    nullif(trim(coalesce(x.unit, 'UND')), '')
  from jsonb_to_recordset(_items) as x(
    code text,
    product text,
    description text,
    quantity numeric,
    unit text
  );

  insert into public.kanban_assignments(
    ficha_id,
    sector_id,
    stage_id,
    priority,
    last_changed_by
  )
  values(
    f_id,
    _sector_id,
    target_stage,
    coalesce(_priority, 'normal'),
    auth.uid()
  );

  insert into public.status_history(
    ficha_id,
    sector_id,
    previous_stage_id,
    new_stage_id,
    changed_by_user_id,
    performed_by_user_id,
    changed_at,
    observation,
    source
  )
  values(
    f_id,
    _sector_id,
    null,
    target_stage,
    auth.uid(),
    auth.uid(),
    now(),
    'Ficha manual criada',
    'manual'
  );

  return f_id;
end
$function$;

grant execute on function public.create_manual_ficha_with_items(
  text, text, jsonb, date, uuid, text, text
) to authenticated;
