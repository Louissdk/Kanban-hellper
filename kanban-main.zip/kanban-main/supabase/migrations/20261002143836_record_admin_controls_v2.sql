create schema if not exists private;

create table if not exists private.kanban_security (
  singleton boolean primary key default true check (singleton),
  delete_pin_hash text not null,
  manager_emails text[] not null default '{}',
  updated_at timestamptz not null default now()
);

insert into private.kanban_security(singleton, delete_pin_hash, manager_emails)
values(true, crypt('0123', gen_salt('bf')), array['dynatecompras@gmail.com','dynatec.adm@gmail.com'])
on conflict (singleton) do update
set manager_emails = excluded.manager_emails;

create table if not exists private.kanban_delete_authorizers (
  profile_id uuid primary key references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  created_by uuid references public.profiles(id)
);

create table if not exists public.ficha_deletion_history (
  id uuid primary key default gen_random_uuid(),
  ficha_id uuid not null,
  order_number text,
  deleted_at timestamptz not null default now(),
  deleted_by_user_id uuid references public.profiles(id),
  authorized_profile_id uuid references public.profiles(id),
  record_snapshot jsonb not null default '{}'::jsonb
);

alter table public.ficha_deletion_history enable row level security;
revoke all on public.ficha_deletion_history from public, anon, authenticated;

drop policy if exists "admins can read deletion audit" on public.ficha_deletion_history;
create policy "admins can read deletion audit"
on public.ficha_deletion_history
for select
to authenticated
using ((select public.has_role(auth.uid(),'admin')));

grant select on public.ficha_deletion_history to authenticated;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public, private
as $func$
declare
  is_manager boolean;
  first_name text;
begin
  insert into public.profiles(id,full_name,email)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),new.email)
  on conflict (id) do update
  set email=excluded.email,
      full_name=case when public.profiles.full_name='' then excluded.full_name else public.profiles.full_name end;

  is_manager := lower(coalesce(new.email,'')) = any(
    coalesce((select manager_emails from private.kanban_security where singleton), '{}')
  );

  if not exists(select 1 from public.user_roles) or is_manager then
    insert into public.user_roles(user_id,role)
    values(new.id,'admin')
    on conflict (user_id,role) do nothing;
  else
    insert into public.user_roles(user_id,role)
    values(new.id,'viewer')
    on conflict (user_id,role) do nothing;
  end if;

  first_name := lower(split_part(trim(coalesce(new.raw_user_meta_data->>'full_name','')), ' ', 1));
  if first_name in ('matheus','henrique','gabrielly') then
    insert into private.kanban_delete_authorizers(profile_id, created_by)
    values(new.id, null)
    on conflict (profile_id) do nothing;
  end if;

  return new;
end
$func$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.manager_delete_control()
returns boolean
language sql
security definer
set search_path = public, private
as $func$
  select public.has_role(auth.uid(),'admin')
     and lower(coalesce((select email from auth.users where id = auth.uid()), '')) =
         any(coalesce((select manager_emails from private.kanban_security where singleton), '{}'))
$func$;

create or replace function public.get_delete_security_state()
returns jsonb
language sql
security definer
set search_path = public, private
as $func$
  select jsonb_build_object(
    'can_manage', public.manager_delete_control(),
    'authorized_profile_ids',
      coalesce(
        (select jsonb_agg(profile_id order by profile_id)
         from private.kanban_delete_authorizers),
        '[]'::jsonb
      )
  )
$func$;

create or replace function public.get_delete_authorizers()
returns table(profile_id uuid, full_name text, email text, active boolean)
language sql
security definer
set search_path = public, private
as $func$
  select p.id, p.full_name, p.email, p.active
  from private.kanban_delete_authorizers a
  join public.profiles p on p.id=a.profile_id
  where public.has_role(auth.uid(),'admin')
  order by p.full_name
$func$;

create or replace function public.set_delete_authorizers(_profile_ids uuid[])
returns integer
language plpgsql
security definer
set search_path = public, private
as $func$
declare n integer;
begin
  if not public.manager_delete_control() then
    raise exception 'Somente Matheus ou Henrique podem gerenciar os perfis autorizadores de exclusão.';
  end if;

  if exists(
    select 1
    from unnest(coalesce(_profile_ids,'{}'::uuid[])) x(id)
    left join public.profiles p on p.id=x.id
    where p.id is null or lower(split_part(trim(p.full_name),' ',1)) not in ('matheus','henrique','gabrielly')
  ) then
    raise exception 'Somente os perfis de Matheus, Henrique ou Gabrielly podem ser autorizados.';
  end if;

  delete from private.kanban_delete_authorizers;

  insert into private.kanban_delete_authorizers(profile_id, created_by)
  select x.id, auth.uid()
  from unnest(coalesce(_profile_ids,'{}'::uuid[])) x(id);

  get diagnostics n = row_count;
  return n;
end
$func$;

create or replace function public.set_delete_pin(_pin text)
returns boolean
language plpgsql
security definer
set search_path = public, private
as $func$
begin
  if not public.manager_delete_control() then
    raise exception 'Somente Matheus ou Henrique podem gerenciar o PIN de exclusão.';
  end if;
  if length(coalesce(_pin,'')) < 4 then
    raise exception 'O PIN deve ter pelo menos 4 caracteres.';
  end if;

  update private.kanban_security
  set delete_pin_hash=crypt(_pin, gen_salt('bf')),
      updated_at=now()
  where singleton;

  return true;
end
$func$;

create or replace function public.delete_ficha(
  _ficha_id uuid,
  _authorized_profile_id uuid,
  _pin text
)
returns uuid
language plpgsql
security definer
set search_path = public, private
as $func$
declare
  f public.fichas%rowtype;
  ka public.kanban_assignments%rowtype;
  items jsonb;
  history jsonb;
  result_id uuid;
begin
  if not public.has_role(auth.uid(),'admin') then
    raise exception 'Apenas administradores podem excluir pedidos.';
  end if;

  if not exists(
    select 1
    from private.kanban_delete_authorizers a
    join public.profiles p on p.id=a.profile_id
    where a.profile_id=_authorized_profile_id
      and p.active
      and lower(split_part(trim(p.full_name),' ',1)) in ('matheus','henrique','gabrielly')
  ) then
    raise exception 'O perfil selecionado não está autorizado para exclusão.';
  end if;

  if not exists(
    select 1
    from private.kanban_security
    where singleton
      and delete_pin_hash=crypt(coalesce(_pin,''), delete_pin_hash)
  ) then
    raise exception 'PIN de exclusão inválido.';
  end if;

  select * into f from public.fichas where id=_ficha_id for update;
  if f.id is null then raise exception 'Pedido não encontrado.'; end if;

  select * into ka from public.kanban_assignments where ficha_id=f.id;
  select coalesce(jsonb_agg(to_jsonb(i) order by i.line_no),'[]'::jsonb)
    into items from public.ficha_items i where i.ficha_id=f.id;
  select coalesce(jsonb_agg(to_jsonb(h) order by h.changed_at),'[]'::jsonb)
    into history from public.status_history h where h.ficha_id=f.id;

  insert into public.ficha_deletion_history(
    ficha_id, order_number, deleted_by_user_id, authorized_profile_id, record_snapshot
  )
  values(
    f.id, f.order_number, auth.uid(), _authorized_profile_id,
    jsonb_build_object(
      'ficha', to_jsonb(f),
      'kanban_assignment', to_jsonb(ka),
      'items', items,
      'status_history', history,
      'deleted_at', now()
    )
  );

  delete from public.fichas where id=f.id returning id into result_id;
  return result_id;
end
$func$;

revoke execute on function public.manager_delete_control() from public, anon, authenticated;
revoke execute on function public.get_delete_security_state() from public, anon;
revoke execute on function public.get_delete_authorizers() from public, anon;
revoke execute on function public.set_delete_authorizers(uuid[]) from public, anon, authenticated;
revoke execute on function public.set_delete_pin(text) from public, anon, authenticated;
revoke execute on function public.delete_ficha(uuid,uuid,text) from public, anon;

grant execute on function public.get_delete_security_state() to authenticated;
grant execute on function public.get_delete_authorizers() to authenticated;
grant execute on function public.set_delete_authorizers(uuid[]) to authenticated;
grant execute on function public.set_delete_pin(text) to authenticated;
grant execute on function public.delete_ficha(uuid,uuid,text) to authenticated;

revoke all on private.kanban_security, private.kanban_delete_authorizers from public, anon, authenticated;
