-- Restrict all application-facing ficha creation RPCs to Manager roles
-- (Administrador/Supervisor). Operators retain movement permissions via can_operate.
DO $$
DECLARE
  target record;
  definition text;
  changed_definition text;
BEGIN
  FOR target IN
    SELECT p.oid
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND p.proname IN (
        'create_manual_ficha',
        'create_manual_ficha_with_items',
        'create_smb_ficha_from_lookup'
      )
      AND pg_get_functiondef(p.oid) ILIKE '%can_operate(auth.uid())%'
  LOOP
    definition := pg_get_functiondef(target.oid);
    changed_definition := replace(
      definition,
      'can_operate(auth.uid())',
      'can_manage(auth.uid())'
    );

    IF changed_definition = definition THEN
      RAISE EXCEPTION 'Não foi possível restringir %', target.oid::text;
    END IF;

    EXECUTE changed_definition;
  END LOOP;
END
$$;

DO $$
BEGIN
  REVOKE EXECUTE ON FUNCTION public.create_manual_ficha(
    text, text, text, numeric, text, date, uuid, text
  ) FROM PUBLIC;
  REVOKE EXECUTE ON FUNCTION public.create_manual_ficha(
    text, text, text, numeric, text, date, uuid, text, text
  ) FROM PUBLIC;

  REVOKE EXECUTE ON FUNCTION public.create_manual_ficha_with_items(
    text, text, jsonb, date, uuid, text, text
  ) FROM PUBLIC;
  REVOKE EXECUTE ON FUNCTION public.create_manual_ficha_with_items(
    text, text, jsonb, date, uuid, text, text, boolean
  ) FROM PUBLIC;

  REVOKE EXECUTE ON FUNCTION public.create_smb_ficha_from_lookup(
    jsonb, uuid, text
  ) FROM PUBLIC;

  GRANT EXECUTE ON FUNCTION public.create_manual_ficha(
    text, text, text, numeric, text, date, uuid, text
  ) TO authenticated;
  GRANT EXECUTE ON FUNCTION public.create_manual_ficha(
    text, text, text, numeric, text, date, uuid, text, text
  ) TO authenticated;

  GRANT EXECUTE ON FUNCTION public.create_manual_ficha_with_items(
    text, text, jsonb, date, uuid, text, text
  ) TO authenticated;
  GRANT EXECUTE ON FUNCTION public.create_manual_ficha_with_items(
    text, text, jsonb, date, uuid, text, text, boolean
  ) TO authenticated;

  GRANT EXECUTE ON FUNCTION public.create_smb_ficha_from_lookup(
    jsonb, uuid, text
  ) TO authenticated;
END
$$;
