-- Make the primary administrative account explicit in the application profile.
update public.profiles
set full_name='Henrique',
    active=true,
    email='dynatecompras@gmail.com',
    updated_at=now()
where lower(email)=lower('dynatecompras@gmail.com');

insert into public.user_roles(user_id,role)
select p.id,'admin'::public.app_role
from public.profiles p
where lower(p.email)=lower('dynatecompras@gmail.com')
and not exists (
  select 1 from public.user_roles ur
  where ur.user_id=p.id and ur.role='admin'::public.app_role
);

insert into private.kanban_delete_authorizers(profile_id,created_by)
select p.id,p.id
from public.profiles p
where lower(p.email)=lower('dynatecompras@gmail.com')
on conflict (profile_id) do nothing;

-- Priority changes are performed only through this Admin-guarded RPC.
create or replace function public.update_ficha_priority(
  _ficha_id uuid,
  _priority text
)
returns text
language plpgsql
security definer
set search_path=public
as $function$
declare
  result_priority text;
begin
  if not public.has_role(auth.uid(),'admin') then
    raise exception 'Apenas administradores podem alterar a prioridade.';
  end if;

  if _priority not in ('baixa','normal','alta','urgente') then
    raise exception 'Prioridade inválida.';
  end if;

  update public.kanban_assignments
  set priority=_priority,
      last_changed_by=auth.uid(),
      updated_at=now()
  where ficha_id=_ficha_id
  returning priority into result_priority;

  if result_priority is null then
    raise exception 'Ficha não encontrada.';
  end if;

  return result_priority;
end
$function$;

revoke execute on function public.update_ficha_priority(uuid,text) from public,anon;
grant execute on function public.update_ficha_priority(uuid,text) to authenticated;

-- Non-admin users can still edit operational fields, but not priority.
revoke update on public.kanban_assignments from authenticated;
grant update (responsible_id,internal_notes) on public.kanban_assignments to authenticated;
