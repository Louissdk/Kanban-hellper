drop function if exists public.search_finalized_fichas(uuid,uuid,text,integer);

alter table public.fichas
  add column if not exists smb_cliente_id text,
  add column if not exists pedido_cliente text,
  add column if not exists data_entrega date,
  add column if not exists envio text,
  add column if not exists status_smb text,
  add column if not exists status_smb_descricao text,
  add column if not exists smb_ranking integer;

alter table public.ficha_items
  add column if not exists pdd_id text;

update public.fichas
set pedido_cliente=coalesce(pedido_cliente,nullif(order_number,'')),
    data_entrega=coalesce(data_entrega,delivery_date),
    status_smb=coalesce(status_smb,case
      when upper(trim(coalesce(smb_status,'')))='INICIADO' then 'I'
      when upper(trim(coalesce(smb_status,'')))='EM PRODUÇÃO' then 'P'
      when upper(trim(coalesce(smb_status,'')))='EM ATRASO' then 'A'
      when upper(trim(coalesce(smb_status,'')))='CONCLUÍDO' then 'C'
      else null end),
    status_smb_descricao=coalesce(status_smb_descricao,nullif(trim(smb_status),''));

update public.ficha_items fi
set pdd_id=f.external_order_id
from public.fichas f
where f.id=fi.ficha_id and fi.pdd_id is null;

create unique index if not exists idx_fichas_external_order_id_unique on public.fichas(external_order_id) where external_order_id is not null;
create index if not exists idx_fichas_smb_cliente_id on public.fichas(smb_cliente_id);
create index if not exists idx_fichas_pedido_cliente on public.fichas(pedido_cliente);
create index if not exists idx_fichas_status_smb on public.fichas(status_smb);
create index if not exists idx_fichas_opened_at_smb on public.fichas(opened_at desc);
create index if not exists idx_ficha_items_pdd_id on public.ficha_items(pdd_id);

CREATE OR REPLACE FUNCTION public.create_smb_ficha_from_lookup(_order jsonb, _sector_id uuid, _priority text DEFAULT 'normal'::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  f_id uuid;
  target_stage uuid;
  customer_matches integer;
  resolved_customer_code text;
  normalized_status text;
  status_code text;
  pdd text;
  opened timestamptz;
  due date;
  customer_name text;
  order_items jsonb;
  item jsonb;
  line_no integer:=0;
  duplicate_sector text;
  duplicate_stage text;
begin
  if not public.can_operate(auth.uid()) then raise exception 'Usuário sem permissão para inserir pedidos.'; end if;

  pdd:=nullif(trim(coalesce(_order->>'external_order_id',_order->>'pdd_id')),'');
  if pdd is null then raise exception 'pdd_id é obrigatório.'; end if;

  status_code:=upper(trim(coalesce(_order->>'status_smb',_order->>'smb_status','')));
  normalized_status:=case
    when status_code='I' then 'INICIADO'
    when status_code='P' then 'EM PRODUÇÃO'
    when status_code='A' then 'EM ATRASO'
    when status_code='C' then 'CONCLUÍDO'
    when status_code='' and upper(trim(coalesce(_order->>'status_smb_descricao','')))= 'INICIADO' then 'INICIADO'
    when status_code='' and upper(trim(coalesce(_order->>'status_smb_descricao','')))= 'EM PRODUÇÃO' then 'EM PRODUÇÃO'
    when status_code='' and upper(trim(coalesce(_order->>'status_smb_descricao','')))= 'EM ATRASO' then 'EM ATRASO'
    when status_code='' and upper(trim(coalesce(_order->>'status_smb_descricao','')))= 'CONCLUÍDO' then 'CONCLUÍDO'
    else null
  end;

  select f.id,s.name,st.name into f_id,duplicate_sector,duplicate_stage
  from public.fichas f
  left join public.kanban_assignments ka on ka.ficha_id=f.id
  left join public.sectors s on s.id=ka.sector_id
  left join public.stages st on st.id=ka.stage_id
  where f.external_order_id=pdd limit 1;

  if f_id is not null then
    return jsonb_build_object(
      'created',false,'duplicate',true,'ficha_id',f_id,'pdd_id',pdd,
      'sector_name',duplicate_sector,'stage_name',duplicate_stage
    );
  end if;

  if _priority not in ('baixa','normal','alta','urgente') then raise exception 'Prioridade inválida.'; end if;
  if not exists(select 1 from public.sectors where id=_sector_id and active) then raise exception 'Setor inválido ou inativo.'; end if;

  opened:=public.parse_smb_datetime(coalesce(_order->>'abertura',_order->>'opened_at'));
  due:=public.parse_smb_date(coalesce(_order->>'data_entrega',_order->>'delivery_date'));
  if opened is null then raise exception 'Data/hora de abertura do SMB é obrigatória.'; end if;

  if normalized_status='CONCLUÍDO' then
    select st.id into target_stage from public.stages st
    where st.sector_id=_sector_id and st.active=true and st.name='Enviado/Finalizado'
    order by st.is_final desc,st.position desc limit 1;
  else
    target_stage:=public.first_active_stage(_sector_id);
  end if;

  if target_stage is null then raise exception 'O setor não possui uma etapa de destino configurada.'; end if;

  customer_name:=nullif(trim(coalesce(_order->'cliente'->>'nome',_order->>'customer')),'');
  select count(*),max(c.codigo_cliente) into customer_matches,resolved_customer_code
  from public.clientes c where c.ativo=true and upper(trim(c.nome))=upper(trim(coalesce(customer_name,'')));
  if customer_matches<>1 then resolved_customer_code:=null; end if;

  order_items:=case
    when jsonb_typeof(_order->'itens')='array' then _order->'itens'
    when jsonb_typeof(_order->'items')='array' then _order->'items'
    else '[]'::jsonb
  end;

  insert into public.fichas(
    external_order_id,order_number,customer,customer_code,seller_name,
    product_summary,quantity,unit,order_date,opened_at,delivery_date,
    smb_cliente_id,pedido_cliente,data_entrega,envio,status_smb,status_smb_descricao,
    smb_ranking,source_observations,source_system,source_synced_at,source_hash,
    sync_state,sync_warning,smb_status
  )
  values(
    pdd,
    coalesce(nullif(trim(coalesce(_order->>'pedido_cliente',_order->>'customer_order_number',_order->>'order_number')),''),pdd),
    coalesce(customer_name,''),
    resolved_customer_code,
    nullif(trim(coalesce(_order->>'vendedor',_order->>'seller')),''),
    nullif(trim(_order->>'product_summary'),''),
    case when nullif(trim(_order->>'quantity'),'') is null then null else (_order->>'quantity')::numeric end,
    nullif(trim(_order->>'unit'),''),
    opened::date,opened,due,
    nullif(trim(coalesce(_order->'cliente'->>'smb_cliente_id',_order->>'smb_cliente_id')),''),
    nullif(trim(coalesce(_order->>'pedido_cliente',_order->>'customer_order_number',_order->>'order_number')),''),
    due,
    nullif(trim(_order->>'envio'),''),
    case when status_code in ('I','P','A','C') then status_code else null end,
    nullif(trim(_order->>'status_smb_descricao'),''),
    case when nullif(trim(_order->>'ranking'),'') ~ '^\d+$' then (_order->>'ranking')::integer else null end,
    nullif(trim(coalesce(_order->>'observacoes',_order->>'source_observations')),''),
    'SMB',now(),nullif(trim(_order->>'source_hash'),''),
    'active',
    case
      when customer_matches>1 then 'Código do cliente não resolvido: múltiplas correspondências.'
      when customer_matches=0 and coalesce(customer_name,'')<>'' then 'Código do cliente não resolvido: cliente não encontrado.'
      else null
    end,
    normalized_status
  )
  returning id into f_id;

  insert into public.kanban_assignments(
    ficha_id,sector_id,stage_id,priority,last_changed_by,completed_at
  )
  values(f_id,_sector_id,target_stage,_priority,auth.uid(),case when status_code='C' then now() else null end);

  insert into public.status_history(
    ficha_id,sector_id,previous_stage_id,new_stage_id,changed_by_user_id,performed_by_user_id,
    changed_at,observation,source,movement_type
  )
  values(
    f_id,_sector_id,null,target_stage,auth.uid(),auth.uid(),now(),
    case when status_code='C' then 'Inserido via consulta SMB; pedido estava CONCLUÍDO no SMB.' else 'Pedido inserido via consulta SMB.' end,
    'SMB_LOOKUP','entrada'
  );

  for item in select value from jsonb_array_elements(order_items)
  loop
    line_no:=line_no+1;
    insert into public.ficha_items(
      ficha_id,pdd_id,line_no,code,product,description,quantity,unit
    )
    values(
      f_id,pdd,
      coalesce(nullif(item->>'sequencia','')::integer,nullif(item->>'sequence','')::integer,nullif(item->>'item_sequence','')::integer,line_no),
      nullif(trim(coalesce(item->>'codigo',item->>'code')),''),
      nullif(trim(coalesce(item->>'produto',item->>'product')),''),
      nullif(trim(coalesce(item->>'descricao',item->>'description')),''),
      case
        when nullif(trim(coalesce(item->>'quantidade',item->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
        then replace(coalesce(item->>'quantidade',item->>'quantity'),',','.')::numeric
        else null
      end,
      nullif(trim(coalesce(item->>'unidade',item->>'unit')),'')
    );
  end loop;

  return jsonb_build_object(
    'created',true,'duplicate',false,'ficha_id',f_id,'pdd_id',pdd,
    'completed_in_smb',status_code='C','stage_id',target_stage
  );
exception when unique_violation then
  select f.id,s.name,st.name into f_id,duplicate_sector,duplicate_stage
  from public.fichas f
  left join public.kanban_assignments ka on ka.ficha_id=f.id
  left join public.sectors s on s.id=ka.sector_id
  left join public.stages st on st.id=ka.stage_id
  where f.external_order_id=pdd limit 1;
  if f_id is not null then
    return jsonb_build_object('created',false,'duplicate',true,'ficha_id',f_id,'pdd_id',pdd,'sector_name',duplicate_sector,'stage_name',duplicate_stage);
  end if;
  raise;
end
$function$;

CREATE OR REPLACE FUNCTION public.finalize_smb_order(_ficha_id uuid, _source text DEFAULT 'SMB_SYNC'::text, _observation text DEFAULT 'Pedido identificado como CONCLUÍDO no SMB.'::text)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  ka public.kanban_assignments%rowtype;
  target public.stages%rowtype;
begin
  select * into ka
  from public.kanban_assignments
  where ficha_id=_ficha_id
  for update;
  if ka.ficha_id is null then raise exception 'Ficha não encontrada no Kanban.'; end if;

  select * into target
  from public.stages
  where sector_id=ka.sector_id and active=true and name='Enviado/Finalizado'
  order by is_final desc,position desc limit 1;
  if target.id is null then raise exception 'A etapa Enviado/Finalizado não está configurada neste setor.'; end if;

  if ka.stage_id=target.id then return false; end if;

  update public.kanban_assignments
  set stage_id=target.id,entered_stage_at=now(),completed_at=now(),updated_at=now()
  where ficha_id=_ficha_id;

  insert into public.status_history(
    ficha_id,sector_id,previous_stage_id,new_stage_id,
    changed_by_user_id,performed_by_user_id,changed_at,observation,source,movement_type
  )
  values(
    _ficha_id,ka.sector_id,ka.stage_id,target.id,null,null,now(),
    nullif(trim(_observation),''),
    coalesce(nullif(trim(_source),''),'SMB_SYNC'),'avanco'
  );
  return true;
end
$function$;

CREATE OR REPLACE FUNCTION public.parse_smb_date(_value text)
 RETURNS date
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
declare v text := trim(coalesce(_value,''));
begin
  if v='' then return null; end if;
  if v ~ '^\d{4}-\d{2}-\d{2}$' then
    begin return v::date; exception when others then return null; end;
  end if;
  if v ~ '^\d{2}/\d{2}/\d{4}$' then
    begin
      return make_date(substring(v,7,4)::integer,substring(v,4,2)::integer,substring(v,1,2)::integer);
    exception when others then return null; end;
  end if;
  return null;
end
$function$;

CREATE OR REPLACE FUNCTION public.parse_smb_datetime(_value text)
 RETURNS timestamp with time zone
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
declare v text := trim(coalesce(_value,''));
begin
  if v='' then return null; end if;
  if v ~ '^\d{4}-\d{2}-\d{2}T' then
    begin return v::timestamptz; exception when others then return null; end;
  end if;
  if v ~ '^\d{2}/\d{2}/\d{4}(\s+\d{2}:\d{2}(:\d{2})?)?$' then
    begin
      return make_timestamptz(
        substring(v,7,4)::integer,
        substring(v,4,2)::integer,
        substring(v,1,2)::integer,
        coalesce(nullif(substring(v,12,2),''),'0')::integer,
        coalesce(nullif(substring(v,15,2),''),'0')::integer,
        coalesce(nullif(substring(v,18,2),''),'0')::integer,
        'America/Sao_Paulo'
      );
    exception when others then return null; end;
  end if;
  return null;
end
$function$;

CREATE OR REPLACE FUNCTION public.process_smb_sync_result(_sync_run_id uuid, _result jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  run_row public.sync_runs%rowtype;
  raw jsonb;
  order_row record;
  item jsonb;
  f_id uuid;
  target_stage uuid;
  import_sector_id uuid;
  customer_name text;
  resolved_customer_code text;
  customer_matches integer;
  pdd text;
  seller_value text;
  opened_value timestamptz;
  delivery_value date;
  normalized_status text;
  status_code text;
  status_description text;
  status_is_completed boolean;
  order_items jsonb;
  item_count integer;
  derived_product_summary text;
  derived_quantity numeric;
  derived_unit text;
  created_count integer := 0;
  updated_count integer := 0;
  ignored_count integer := 0;
  eligible_count integer := 0;
  error_count integer := 0;
  warning_count integer := 0;
  error_messages text[] := '{}';
  ranking_value integer;
  existing_stage_id uuid;
  existing_sector_id uuid;
  sequence_value integer;
begin
  if coalesce(current_setting('request.jwt.claims',true)::jsonb->>'role','') <> 'service_role' then
    raise exception 'Somente o serviço de integração pode processar resultados do robô.';
  end if;

  select * into run_row from public.sync_runs where id=_sync_run_id for update;
  if run_row.id is null then raise exception 'Execução de sincronização não encontrada.'; end if;
  if run_row.status not in ('requested','running') then raise exception 'A execução de sincronização não está aguardando processamento.'; end if;

  update public.sync_runs
  set status='running',started_at=coalesce(started_at,now()),robot_status='available',
      robot_message=null,error_message=null
  where id=_sync_run_id;

  select s.id into import_sector_id
  from public.sectors s
  where s.active and s.is_default_import
  order by s.position
  limit 1;

  create temporary table if not exists tmp_smb_orders(
    external_order_id text,
    customer_order_number text,
    customer text,
    smb_cliente_id text,
    seller text,
    opened_at timestamptz,
    delivery_date date,
    envio text,
    status_smb text,
    status_smb_descricao text,
    ranking integer,
    source_observations text,
    source_hash text,
    product_summary text,
    quantity numeric,
    unit text,
    items jsonb
  ) on commit drop;
  truncate tmp_smb_orders;

  insert into tmp_smb_orders(
    external_order_id,customer_order_number,customer,smb_cliente_id,seller,
    opened_at,delivery_date,envio,status_smb,status_smb_descricao,ranking,
    source_observations,source_hash,product_summary,quantity,unit,items
  )
  select
    nullif(trim(coalesce(raw->>'external_order_id',raw->>'pdd_id')),''),
    nullif(trim(coalesce(raw->>'pedido_cliente',raw->>'customer_order_number',raw->>'order_number')),''),
    nullif(trim(coalesce(raw->'cliente'->>'nome',raw->>'customer')),''),
    nullif(trim(coalesce(raw->'cliente'->>'smb_cliente_id',raw->>'smb_cliente_id')),''),
    nullif(trim(coalesce(raw->>'vendedor',raw->>'seller')),''),
    public.parse_smb_datetime(coalesce(raw->>'abertura',raw->>'opened_at')),
    public.parse_smb_date(coalesce(raw->>'data_entrega',raw->>'delivery_date')),
    nullif(trim(coalesce(raw->>'envio',raw->>'shipping')),''),
    upper(trim(coalesce(raw->>'status_smb',raw->>'smb_status',''))),
    nullif(trim(coalesce(raw->>'status_smb_descricao',raw->>'smb_status_descricao')),''),
    case
      when nullif(trim(coalesce(raw->>'ranking',raw->>'rank')),'') ~ '^\d+$'
      then (coalesce(raw->>'ranking',raw->>'rank'))::integer
      else null
    end,
    nullif(trim(coalesce(raw->>'observacoes',raw->>'source_observations')),''),
    nullif(trim(raw->>'source_hash'),''),
    nullif(trim(raw->>'product_summary'),''),
    case when nullif(trim(raw->>'quantity'),'') is null then null else (raw->>'quantity')::numeric end,
    nullif(trim(raw->>'unit'),''),
    case
      when jsonb_typeof(raw->'itens')='array' then raw->'itens'
      when jsonb_typeof(raw->'items')='array' then raw->'items'
      else '[]'::jsonb
    end
  from jsonb_array_elements(coalesce(_result->'orders','[]'::jsonb)) raw;

  for order_row in
    select distinct on (external_order_id) *
    from tmp_smb_orders
    where external_order_id is not null
    order by external_order_id,opened_at desc nulls last,jsonb_array_length(items) desc,ranking nulls last
  loop
    pdd := order_row.external_order_id;
    seller_value := order_row.seller;
    opened_value := order_row.opened_at;
    delivery_value := order_row.delivery_date;
    status_code := upper(trim(coalesce(order_row.status_smb,'')));
    status_description := upper(trim(coalesce(order_row.status_smb_descricao,'')));

    normalized_status := case
      when status_code='I' then 'INICIADO'
      when status_code='P' then 'EM PRODUÇÃO'
      when status_code='A' then 'EM ATRASO'
      when status_code='C' then 'CONCLUÍDO'
      when status_code='' and status_description='INICIADO' then 'INICIADO'
      when status_code='' and status_description='EM PRODUÇÃO' then 'EM PRODUÇÃO'
      when status_code='' and status_description='EM ATRASO' then 'EM ATRASO'
      when status_code='' and status_description='CONCLUÍDO' then 'CONCLUÍDO'
      else null
    end;
    status_is_completed := status_code='C';

    if pdd is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'Pedido sem pdd_id/external_order_id.');
      insert into public.sync_errors(sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at)
      values(_sync_run_id,null,'error','Pedido sem pdd_id/external_order_id.','missing_external_order_id','Pedido sem pdd_id/external_order_id.',now());
      continue;
    end if;

    select f.id,ka.stage_id,ka.sector_id
      into f_id,existing_stage_id,existing_sector_id
    from public.fichas f
    left join public.kanban_assignments ka on ka.ficha_id=f.id
    where f.external_order_id=pdd
    limit 1;

    customer_name := order_row.customer;

    select count(*),max(c.codigo_cliente)
      into customer_matches,resolved_customer_code
    from public.clientes c
    where c.ativo=true
      and coalesce(customer_name,'')<>''
      and upper(trim(c.nome))=upper(trim(customer_name));

    if customer_matches<>1 then
      resolved_customer_code:=null;
      if customer_matches>1 then
        warning_count:=warning_count+1;
        insert into public.sync_errors(sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at)
        values(_sync_run_id,pdd,'warning','Cliente com correspondência ambígua; código mantido NULL.','ambiguous_customer','Cliente com correspondência ambígua; código mantido NULL.',now());
      end if;
    end if;

    order_items := order_row.items;
    select count(*) into item_count from jsonb_array_elements(order_items);

    derived_product_summary := order_row.product_summary;
    if derived_product_summary is null then
      select nullif(trim(coalesce(i.value->>'descricao',i.value->>'description',i.value->>'product')),'')
        into derived_product_summary
      from jsonb_array_elements(order_items) i(value)
      order by coalesce(
        nullif(i.value->>'sequencia','')::integer,
        nullif(i.value->>'sequence','')::integer,
        nullif(i.value->>'item_sequence','')::integer,
        999999
      )
      limit 1;
    end if;

    derived_quantity := order_row.quantity;
    if derived_quantity is null then
      select sum(
        case
          when nullif(trim(coalesce(i.value->>'quantidade',i.value->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
          then replace(coalesce(i.value->>'quantidade',i.value->>'quantity'),',','.')::numeric
          else null
        end
      ) into derived_quantity
      from jsonb_array_elements(order_items) i(value);
    end if;

    derived_unit := order_row.unit;
    if derived_unit is null and item_count=1 then
      select nullif(trim(coalesce(i.value->>'unidade',i.value->>'unit')),'') into derived_unit
      from jsonb_array_elements(order_items) i(value) limit 1;
    end if;

    if f_id is not null then
      update public.fichas f
      set order_number=coalesce(order_row.customer_order_number,f.order_number),
          pedido_cliente=coalesce(order_row.customer_order_number,f.pedido_cliente),
          customer=coalesce(order_row.customer,f.customer),
          smb_cliente_id=coalesce(order_row.smb_cliente_id,f.smb_cliente_id),
          seller_name=coalesce(order_row.seller,f.seller_name),
          product_summary=coalesce(derived_product_summary,f.product_summary),
          quantity=coalesce(derived_quantity,f.quantity),
          unit=coalesce(derived_unit,f.unit),
          opened_at=coalesce(order_row.opened_at,f.opened_at),
          order_date=coalesce(order_row.opened_at::date,f.order_date),
          delivery_date=coalesce(delivery_value,f.delivery_date),
          data_entrega=coalesce(delivery_value,f.data_entrega),
          envio=coalesce(order_row.envio,f.envio),
          status_smb=case when status_code<>'' then status_code else f.status_smb end,
          status_smb_descricao=coalesce(nullif(trim(order_row.status_smb_descricao),''),f.status_smb_descricao),
          smb_status=coalesce(normalized_status,f.smb_status),
          customer_code=case when nullif(trim(f.customer_code),'') is null then resolved_customer_code else f.customer_code end,
          smb_ranking=coalesce(order_row.ranking,f.smb_ranking),
          source_observations=coalesce(order_row.source_observations,f.source_observations),
          source_system='SMB',
          source_synced_at=now(),
          source_hash=coalesce(order_row.source_hash,f.source_hash),
          sync_state='active',
          sync_warning=case
            when customer_matches>1 then 'Código do cliente não resolvido: múltiplas correspondências.'
            when customer_matches=0 and coalesce(customer_name,'')<>'' then 'Código do cliente não resolvido: cliente não encontrado.'
            else null
          end,
          updated_at=now()
      where f.id=f_id;

      delete from public.ficha_items where ficha_id=f_id;

      for item in select value from jsonb_array_elements(order_items)
      loop
        sequence_value:=coalesce(
          nullif(item->>'sequencia','')::integer,
          nullif(item->>'sequence','')::integer,
          nullif(item->>'item_sequence','')::integer
        );
        if sequence_value is null then
          sequence_value:=coalesce((select max(line_no)+1 from public.ficha_items where ficha_id=f_id),1);
        end if;

        insert into public.ficha_items(
          ficha_id,pdd_id,line_no,code,product,description,quantity,unit
        )
        values(
          f_id,pdd,sequence_value,
          nullif(trim(coalesce(item->>'codigo',item->>'code')),''),
          nullif(trim(coalesce(item->>'produto',item->>'product')),''),
          nullif(trim(coalesce(item->>'descricao',item->>'description')),''),
          case
            when nullif(trim(coalesce(item->>'quantidade',item->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
            then replace(coalesce(item->>'quantidade',item->>'quantity'),',','.')::numeric
            else null
          end,
          nullif(trim(coalesce(item->>'unidade',item->>'unit')),'')
        );
      end loop;

      updated_count:=updated_count+1;
      if status_is_completed then
        perform public.finalize_smb_order(f_id,'SMB_SYNC','Pedido identificado como CONCLUÍDO no SMB.');
      end if;
      continue;
    end if;

    if opened_value is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] data/hora de abertura ausente ou inválida.');
      insert into public.sync_errors(sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at)
      values(_sync_run_id,pdd,'error','Data/hora de abertura ausente ou inválida.','invalid_opened_at','Data/hora de abertura ausente ou inválida.',now());
      continue;
    end if;

    if opened_value::date < date '2026-09-21' then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    ranking_value:=order_row.ranking;
    if ranking_value is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] ranking não informado pelo robô.');
      insert into public.sync_errors(sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at)
      values(_sync_run_id,pdd,'error','Ranking não informado pelo robô.','missing_ranking','Ranking não informado pelo robô.',now());
      continue;
    end if;

    if ranking_value<=2 then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    if normalized_status is null then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    if normalized_status not in ('INICIADO','EM PRODUÇÃO','EM ATRASO') then
      ignored_count:=ignored_count+1;
      continue;
    end if;

    if seller_value is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] vendedor ausente; pedido não pode entrar no Kanban.');
      insert into public.sync_errors(sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at)
      values(_sync_run_id,pdd,'error','Vendedor ausente; pedido não pode entrar no Kanban.','missing_seller','Vendedor ausente; pedido não pode entrar no Kanban.',now());
      continue;
    end if;

    if import_sector_id is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] nenhum setor de importação configurado.');
      insert into public.sync_errors(sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at)
      values(_sync_run_id,pdd,'error','Nenhum setor de importação configurado.','missing_import_sector','Nenhum setor de importação configurado.',now());
      continue;
    end if;

    target_stage:=public.first_active_stage(import_sector_id);
    if target_stage is null then
      error_count:=error_count+1;
      error_messages:=array_append(error_messages,'['||pdd||'] nenhum estágio inicial ativo configurado.');
      insert into public.sync_errors(sync_run_id,external_order_id,level,message,error_type,error_message,occurred_at)
      values(_sync_run_id,pdd,'error','Nenhum estágio inicial ativo configurado.','missing_import_stage','Nenhum estágio inicial ativo configurado.',now());
      continue;
    end if;

    eligible_count:=eligible_count+1;

    insert into public.fichas(
      external_order_id,order_number,customer,customer_code,seller_name,
      product_summary,quantity,unit,order_date,opened_at,delivery_date,
      smb_cliente_id,pedido_cliente,data_entrega,envio,status_smb,status_smb_descricao,
      smb_ranking,source_observations,source_system,source_synced_at,source_hash,
      sync_state,sync_warning,smb_status
    )
    values(
      pdd,coalesce(order_row.customer_order_number,pdd),coalesce(order_row.customer,''),
      resolved_customer_code,order_row.seller,derived_product_summary,derived_quantity,derived_unit,
      opened_value::date,opened_value,delivery_value,
      order_row.smb_cliente_id,order_row.customer_order_number,delivery_value,order_row.envio,
      case when status_code in ('I','P','A','C') then status_code else null end,
      coalesce(nullif(trim(order_row.status_smb_descricao),''),normalized_status),
      ranking_value,order_row.source_observations,'SMB',now(),
      coalesce(order_row.source_hash,md5(order_row::text)),
      'active',
      case
        when customer_matches>1 then 'Código do cliente não resolvido: múltiplas correspondências.'
        when customer_matches=0 and coalesce(customer_name,'')<>'' then 'Código do cliente não resolvido: cliente não encontrado.'
        else null
      end,
      normalized_status
    )
    returning id into f_id;

    insert into public.kanban_assignments(ficha_id,sector_id,stage_id,priority,last_changed_by)
    values(f_id,import_sector_id,target_stage,'normal',null);

    insert into public.status_history(
      ficha_id,sector_id,previous_stage_id,new_stage_id,changed_at,observation,source,movement_type
    )
    values(f_id,import_sector_id,null,target_stage,now(),'Importado do SMB','SMB_SYNC','entrada');

    for item in select value from jsonb_array_elements(order_items)
    loop
      sequence_value:=coalesce(
        nullif(item->>'sequencia','')::integer,
        nullif(item->>'sequence','')::integer,
        nullif(item->>'item_sequence','')::integer
      );
      if sequence_value is null then
        sequence_value:=coalesce((select max(line_no)+1 from public.ficha_items where ficha_id=f_id),1);
      end if;

      insert into public.ficha_items(
        ficha_id,pdd_id,line_no,code,product,description,quantity,unit
      )
      values(
        f_id,pdd,sequence_value,
        nullif(trim(coalesce(item->>'codigo',item->>'code')),''),
        nullif(trim(coalesce(item->>'produto',item->>'product')),''),
        nullif(trim(coalesce(item->>'descricao',item->>'description')),''),
        case
          when nullif(trim(coalesce(item->>'quantidade',item->>'quantity')),'') ~ '^[0-9]+([.,][0-9]+)?$'
          then replace(coalesce(item->>'quantidade',item->>'quantity'),',','.')::numeric
          else null
        end,
        nullif(trim(coalesce(item->>'unidade',item->>'unit')),'')
      );
    end loop;

    created_count:=created_count+1;
  end loop;

  update public.sync_runs
  set status=case when error_count>0 then 'partial' else 'success' end,
      finished_at=now(),
      total_read=jsonb_array_length(coalesce(_result->'orders','[]'::jsonb)),
      inserted=created_count,updated=updated_count,skipped=ignored_count,
      errors=error_count,warnings=warning_count,
      orders_scanned=jsonb_array_length(coalesce(_result->'orders','[]'::jsonb)),
      orders_eligible=eligible_count,orders_created=created_count,
      orders_updated=updated_count,orders_ignored=ignored_count,
      errors_count=error_count,
      error_details=case when coalesce(array_length(error_messages,1),0)>0 then array_to_string(error_messages,E'\n') else null end,
      error_message=case when coalesce(array_length(error_messages,1),0)>0 then array_to_string(error_messages,E'\n') else null end,
      robot_status='available',
      robot_message=coalesce(nullif(trim(_result->>'message'),''),'Resultado recebido do serviço de leitura.')
  where id=_sync_run_id;

  return jsonb_build_object(
    'success',error_count=0,'sync_run_id',_sync_run_id,
    'orders_scanned',jsonb_array_length(coalesce(_result->'orders','[]'::jsonb)),
    'orders_eligible',eligible_count,'orders_created',created_count,
    'orders_updated',updated_count,'orders_ignored',ignored_count,
    'errors_count',error_count,'warnings_count',warning_count,
    'status',case when error_count>0 then 'partial' else 'success' end
  );
end
$function$;

CREATE OR REPLACE FUNCTION public.search_finalized_fichas(_sector_id uuid, _stage_id uuid, _query text DEFAULT ''::text, _limit integer DEFAULT 100)
 RETURNS TABLE(ficha_id uuid, sector_id uuid, stage_id uuid, priority text, responsible_id uuid, entered_stage_at timestamp with time zone, completed_at timestamp with time zone, updated_at timestamp with time zone, production_returned boolean, return_count integer, last_return_reason_category text, last_return_reason text, order_number text, pedido_cliente text, customer text, customer_code text, smb_cliente_id text, seller_name text, product_summary text, quantity numeric, unit text, delivery_date date, data_entrega date, envio text, status_smb text, status_smb_descricao text, source_system text, sync_state text)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select
    ka.ficha_id,ka.sector_id,ka.stage_id,ka.priority,ka.responsible_id,
    ka.entered_stage_at,ka.completed_at,ka.updated_at,ka.production_returned,
    ka.return_count,ka.last_return_reason_category,ka.last_return_reason,
    f.order_number,f.pedido_cliente,f.customer,f.customer_code,
    f.smb_cliente_id,f.seller_name,f.product_summary,f.quantity,f.unit,
    f.delivery_date,f.data_entrega,f.envio,f.status_smb,f.status_smb_descricao,
    f.source_system,f.sync_state
  from public.kanban_assignments ka
  join public.fichas f on f.id=ka.ficha_id
  where ka.sector_id=_sector_id and ka.stage_id=_stage_id
    and f.sync_state<>'archived'
    and (
      nullif(trim(_query),'') is null
      or f.external_order_id ilike '%'||trim(_query)||'%'
      or f.order_number ilike '%'||trim(_query)||'%'
      or f.pedido_cliente ilike '%'||trim(_query)||'%'
      or f.customer_code ilike '%'||trim(_query)||'%'
      or f.seller_name ilike '%'||trim(_query)||'%'
      or f.smb_cliente_id ilike '%'||trim(_query)||'%'
      or f.product_summary ilike '%'||trim(_query)||'%'
      or exists (
        select 1 from public.ficha_items fi
        where fi.ficha_id=f.id
          and (
            fi.description ilike '%'||trim(_query)||'%'
            or fi.product ilike '%'||trim(_query)||'%'
            or fi.code ilike '%'||trim(_query)||'%'
          )
      )
    )
  order by coalesce(ka.completed_at,ka.updated_at) desc
  limit greatest(1,least(coalesce(_limit,100),250));
$function$;

grant execute on function public.search_finalized_fichas(uuid,uuid,text,integer) to authenticated;
