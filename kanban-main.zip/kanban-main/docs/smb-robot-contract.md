# Contrato do robô SMB — PEDIFLOW

## Princípios
- SMB é somente leitura.
- O navegador do PEDIFLOW nunca acessa ou automatiza o SMB.
- pdd_id é o identificador técnico externo e mapeia para fichas.external_order_id.
- O estágio do Kanban nunca é derivado do status do SMB.
- O resultado do robô não deve ser filtrado antes do ranking.

## Solicitação manual
POST /api/sync/smb

Headers:
Authorization: Bearer <SUPABASE_ACCESS_TOKEN>
Content-Type: application/json

Body: {"trigger":"manual"}

Sem URL de robô configurada, o endpoint registra um sync_run com status requested e o worker Docker o consome.
Com SMB_ROBOT_URL configurado, o backend chama o serviço HTTP e pode aguardar o resultado ou aceitar 202.

## Resultado do robô
200: resultado processado imediatamente.
202: solicitação aceita; o robô deve chamar POST /api/sync/smb/result.

Callback header:
Authorization: Bearer <SMB_ROBOT_API_KEY>
X-Sync-Run-Id: <UUID> (opcional, deve coincidir quando enviado)

Payload:
{
  "success": true,
  "sync_run_id": "UUID",
  "orders_scanned": 100,
  "orders": [
    {
      "external_order_id": "9503",
      "customer_order_number": null,
      "customer": "Cliente real",
      "customer_code": null,
      "seller": "Taina",
      "opened_at": "2026-09-21T11:24:00-03:00",
      "delivery_date": "2026-09-30",
      "smb_status": "INICIADO",
      "items": [
        {"sequence": 1, "quantity": 18, "unit": "UN", "description": "Descrição real lida do SMB"}
      ]
    }
  ],
  "errors": [
    {"external_order_id": "9515", "error_type": "order_read_error", "error_message": "Detalhe do erro"}
  ]
}

Os valores acima são somente exemplo de formato e não são inseridos como dados de produção.

## Ranking
Para cada vendedor:
1. considerar pedidos com abertura em ou após 21/09/2026;
2. ordenar por opened_at decrescente;
3. ignorar posições 1 e 2;
4. somente da posição 3 em diante aplicar o filtro de status;
5. manter INICIADO, EM PRODUÇÃO e EM ATRASO.
CONCLUÍDO pode ocupar a posição 1 ou 2 e continua influenciando o ranking.

## Cliente
O customer_code recebido do robô é apenas uma dica.
O processador busca o cliente ativo pelo nome em public.clientes.
Exatamente 1 correspondência: usa codigo_cliente.
0 correspondências: NULL.
Mais de 1 correspondência: NULL e aviso em sync_errors.
Nunca é feito guessing.

## Itens
Uma ordem pode ter vários itens. Cada item aceita sequence, quantity, unit, description, com code e product opcionais.

## Idempotência
external_order_id/pdd_id é único.
Pedido existente é atualizado apenas nos dados de origem SMB e itens.
kanban_assignments e status_history não são recriados nem movidos pelo status do SMB.

## Variáveis de servidor
SMB_ROBOT_URL: URL opcional do serviço HTTP do robô.
SMB_ROBOT_API_KEY: segredo usado no callback, somente servidor.
SMB_ROBOT_TIMEOUT_MS: timeout HTTP, padrão 120000.
SUPABASE_SERVICE_ROLE_KEY: somente no worker/servidor.

## Automático
No modo fila, o worker Docker usa system_settings.sync.enabled e interval_minutes e cria sync_runs com trigger_type=automatic.
O mesmo process_smb_sync_result trata os resultados manuais e automáticos.
O navegador não precisa ficar aberto.

## Paginação SMB
A paginação final ainda não foi definida porque os testes encontraram duplicações entre páginas.
O adapter mantém a paginação como responsabilidade separada e apenas deduplica o mesmo pdd_id que chegar ao worker.
Não há algoritmo inventado de paginação nesta versão.