# PEDIFLOW — integração SMB / contrato do robô

O SMB é READ-ONLY. O frontend não acessa o SMB. Node.js + Playwright é o único componente responsável pela autenticação e leitura.

Payload de pedido aceito pelo processamento:
{
  external_order_id: "9704",
  cliente: { smb_cliente_id: "3864", nome: "NOME REAL", codigo_cliente: null },
  vendedor: "Taina",
  abertura: "02/10/2026 14:27",
  status_smb: "I",
  status_smb_descricao: "INICIADO",
  pedido_cliente: null,
  data_entrega: null,
  envio: null,
  ranking: 3,
  itens: [{ sequencia: "1", quantidade: "30", unidade: "UN", descricao: "Descrição real" }]
}

Campos do SMB armazenados separadamente:
- pdd_id = chave técnica canônica e UNIQUE
- external_order_id = alias de compatibilidade do pdd_id
- smb_cliente_id = identificador do cliente dentro do SMB, TEXT; nunca convertido para integer
- codigo_cliente = código do cliente na base interna/planilha; não é o mesmo campo que smb_cliente_id
- status_smb = código I/P/A/C
- status_smb_descricao = descrição recebida

codigo_cliente nunca é copiado do payload. O PEDIFLOW procura o cliente na base clientes; apenas uma correspondência única gera código. Ausente ou ambíguo fica NULL e a sincronização registra aviso.

Ranking é fornecido pelo robô/backend. O frontend não recalcula. Para pedidos novos, as posições 1 e 2 são ignoradas e somente I/P/A da posição 3 em diante entram no Kanban.

Pedido já existente é atualizado por pdd_id sem duplicar. Histórico, etapa e dados operacionais são preservados.

Somente status_smb = C dispara a regra especial: pedido existente -> etapa Enviado/Finalizado. Status I/P/A nunca movimentam etapa.

A operação é idempotente: se a ficha já estiver em Enviado/Finalizado, nova sincronização não cria novo histórico.

Consulta individual:
POST /api/sync/smb/lookup
{ pdd_id: "9704" }
O backend consulta o serviço do robô, verifica duplicidade no Supabase e devolve setor/etapa quando o pedido já estiver no Kanban.

Sincronização:
POST /api/sync/smb
{ trigger: "manual" | "automatic" }

Resultado do robô:
POST /api/sync/smb/result
Authorization: Bearer <SMB_ROBOT_API_KEY>

URL do pedido SMB é construída dinamicamente no detalhe:
https://dynatec.smbempresa.com.br/pedido.php?pdd_id={pdd_id}

A pesquisa de Enviado/Finalizado é somente no Supabase e aceita pdd_id, pedido_cliente, codigo_cliente, vendedor e descrição/código dos itens.

A paginação/descoberta final do SMB continua sendo responsabilidade do robô; o PEDIFLOW não inventa uma estratégia. O banco deduplica por pdd_id.

`pedido_cliente` nunca é usado como chave técnica. A deduplicação usa exclusivamente `pdd_id`.
