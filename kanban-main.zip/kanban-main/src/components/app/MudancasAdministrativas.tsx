import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { CalendarDays, Database, ExternalLink, History, Search, UserRound } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useAuth } from "@/lib/auth";
import { maskCustomerName } from "@/lib/data";

type ChangeRow = {
  id: string;
  ficha_id: string;
  external_order_id: string | null;
  sync_run_id: string | null;
  field_name: string;
  field_label: string;
  old_value: unknown;
  new_value: unknown;
  change_type: string;
  source: string;
  actor_type: string;
  actor_label: string;
  item_line_no: number | null;
  changed_at: string;
  metadata: unknown;
  fichas: { order_number: string; customer: string; seller_name: string | null; pdd_id: string | null } | null;
};

function valueText(value: unknown) {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value);
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

export function MudancasAdministrativasPage() {
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const [search, setSearch] = useState("");
  const [orderFilter, setOrderFilter] = useState("");
  const [pddFilter, setPddFilter] = useState("");
  const [customerFilter, setCustomerFilter] = useState("");
  const [sellerFilter, setSellerFilter] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [field, setField] = useState("all");
  const [source, setSource] = useState("all");
  const [syncRun, setSyncRun] = useState("");

  const query = useQuery({
    queryKey: ["smb-admin-changes-global"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("smb_admin_changes")
.select("id,ficha_id,external_order_id,sync_run_id,field_name,field_label,old_value,new_value,change_type,source,actor_type,actor_label,item_line_no,changed_at,metadata,fichas(order_number,customer,seller_name,pdd_id)")
        .order("changed_at", { ascending: false })
        .limit(2000);
      if (error) throw new Error(error.message);
      return (data ?? []) as unknown as ChangeRow[];
    },
    refetchInterval: 10000,
  });

  const rows = query.data ?? [];
  const fieldOptions = useMemo(
    () => [...new Set(rows.map((row) => row.field_label))].sort((a, b) => a.localeCompare(b, "pt-BR")),
    [rows],
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLocaleLowerCase("pt-BR");
    const orderQ = orderFilter.trim().toLocaleLowerCase("pt-BR");
    const pddQ = pddFilter.trim().toLocaleLowerCase("pt-BR");
    const customerQ = customerFilter.trim().toLocaleLowerCase("pt-BR");
    const sellerQ = sellerFilter.trim().toLocaleLowerCase("pt-BR");
    const fromAt = from ? new Date(from + "T00:00:00").getTime() : -Infinity;
    const toAt = to ? new Date(to + "T23:59:59.999").getTime() : Infinity;

    return rows.filter((row) => {
      const time = new Date(row.changed_at).getTime();
      if (time < fromAt || time > toAt) return false;
      if (field !== "all" && row.field_label !== field) return false;
      if (source !== "all" && row.source !== source) return false;
      if (orderFilter && !((row.fichas?.order_number ?? "").toLocaleLowerCase("pt-BR").includes(orderQ))) return false;
      if (pddFilter && !((row.external_order_id ?? row.fichas?.pdd_id ?? "").toLocaleLowerCase("pt-BR").includes(pddQ))) return false;
      if (isAdmin && customerFilter && !((row.fichas?.customer ?? "").toLocaleLowerCase("pt-BR").includes(customerQ))) return false;
      if (sellerFilter && !((row.fichas?.seller_name ?? "").toLocaleLowerCase("pt-BR").includes(sellerQ))) return false;
      if (syncRun && !(row.sync_run_id ?? "").toLowerCase().includes(syncRun.trim().toLowerCase())) return false;
      if (!q) return true;

      const ficha = row.fichas;
      return [
        row.field_label,
        row.field_name,
        row.actor_label,
        row.source,
        row.change_type,
        row.external_order_id ?? "",
        row.sync_run_id ?? "",
        ficha?.order_number ?? "",
        ficha?.pdd_id ?? "",
        isAdmin ? (ficha?.customer ?? "") : "",
        ficha?.seller_name ?? "",
        valueText(row.old_value),
        valueText(row.new_value),
      ].join(" ").toLocaleLowerCase("pt-BR").includes(q);
    });
  }, [rows, search, orderFilter, pddFilter, customerFilter, sellerFilter, from, to, field, source, syncRun]);

  return (
    <div className="min-h-full bg-background">
      <div className="border-b bg-card">
        <div className="mx-auto max-w-[1800px] px-4 py-5 sm:px-5 md:px-7">
          <div className="flex flex-wrap items-start gap-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-primary">AUDITORIA</p>
              <h1 className="text-2xl font-black">Mudanças Administrativas</h1>
              <p className="mt-1 max-w-3xl text-sm text-muted-foreground">Alterações nos dados administrativos das fichas. O Histórico de Produção permanece separado.</p>
            </div>
            <Badge variant="outline" className="ml-auto">Mais recentes primeiro</Badge>
          </div>

          <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            <div className="relative md:col-span-2 xl:col-span-2">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" placeholder={isAdmin ? "Pedido, PDD, cliente, vendedor ou valor" : "Pedido, PDD, vendedor ou valor"} />
            </div>
            <Input value={orderFilter} onChange={(e) => setOrderFilter(e.target.value)} placeholder="Pedido" aria-label="Filtro por pedido" />
            <Input value={pddFilter} onChange={(e) => setPddFilter(e.target.value)} placeholder="PDD / pedido SMB" aria-label="Filtro por PDD" />
            {isAdmin && <Input value={customerFilter} onChange={(e) => setCustomerFilter(e.target.value)} placeholder="Cliente" aria-label="Filtro por cliente" />}
            <Input value={sellerFilter} onChange={(e) => setSellerFilter(e.target.value)} placeholder="Vendedor" aria-label="Filtro por vendedor" />
            <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="Data inicial" />
            <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label="Data final" />
            <select value={field} onChange={(e) => setField(e.target.value)} className="h-10 rounded-md border bg-background px-3 text-sm">
              <option value="all">Todos os campos</option>
              {fieldOptions.map((item) => <option key={item} value={item}>{item}</option>)}
            </select>
            <select value={source} onChange={(e) => setSource(e.target.value)} className="h-10 rounded-md border bg-background px-3 text-sm">
              <option value="all">Todas as origens</option>
              <option value="SMB_SYNC">SMB / Robô SMB</option>
              <option value="KANBAN_ADMIN">Kanban / Administração</option>
            </select>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5"><CalendarDays className="size-3.5" /> {filtered.length} alteração(ões)</span>
            <div className="flex items-center gap-2">
              <span>Sincronização:</span>
              <Input value={syncRun} onChange={(e) => setSyncRun(e.target.value)} className="h-8 w-72 font-mono text-xs" placeholder="UUID da sync_run" />
            </div>
            {(search || orderFilter || pddFilter || customerFilter || sellerFilter || from || to || field !== "all" || source !== "all" || syncRun) && (
              <Button size="sm" variant="ghost" onClick={() => { setSearch(""); setOrderFilter(""); setPddFilter(""); setCustomerFilter(""); setSellerFilter(""); setFrom(""); setTo(""); setField("all"); setSource("all"); setSyncRun(""); }}>Limpar filtros</Button>
            )}
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-[1800px] space-y-3 p-4 sm:p-5 md:p-7">
        {filtered.length === 0 ? (
          <Card>
            <CardContent className="grid min-h-56 place-items-center text-center">
              <div>
                <History className="mx-auto size-10 text-muted-foreground" />
                <p className="mt-3 font-semibold">Nenhuma mudança administrativa encontrada</p>
                <p className="mt-1 text-sm text-muted-foreground">A próxima alteração real será registrada aqui.</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          filtered.map((row) => (
            <Card key={row.id} className="overflow-hidden">
              <CardHeader className="border-b bg-muted/20 px-4 py-3 sm:px-5">
                <div className="flex flex-wrap items-start gap-3">
                  <div className="min-w-0">
                    <button type="button" className="font-mono text-base font-bold text-left hover:underline" onClick={() => navigate({ to: "/fichas/$id", params: { id: row.ficha_id } })}>
                      FICHA #{row.fichas?.order_number ?? row.ficha_id.slice(0, 8)}
                    </button>
                    <p className="truncate text-sm font-semibold">{maskCustomerName(row.fichas?.customer, isAdmin)}</p>
                  </div>
                  <Badge variant={row.source === "SMB_SYNC" ? "default" : "secondary"} className="ml-auto">
                    {row.source === "SMB_SYNC" ? "SMB / Robô SMB" : "Kanban / Administração"}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="grid gap-4 p-4 md:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)_auto] md:items-start sm:p-5">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">
                    {row.field_label}{row.item_line_no ? " · Linha " + row.item_line_no : ""}
                  </p>
                  <p className="mt-2 text-sm font-semibold">{new Date(row.changed_at).toLocaleString("pt-BR")}</p>
                  <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground"><UserRound className="size-3.5" /> {row.actor_label}</p>
                </div>

                <div className="grid gap-2 sm:grid-cols-2">
                  <div className="rounded-xl border bg-muted/20 p-3">
                    <p className="text-[10px] font-bold uppercase tracking-[0.13em] text-muted-foreground">Valor anterior</p>
                    <p className="mt-1 break-words font-mono text-sm">{valueText(row.old_value)}</p>
                  </div>
                  <div className="rounded-xl border bg-primary/5 p-3">
                    <p className="text-[10px] font-bold uppercase tracking-[0.13em] text-muted-foreground">Novo valor</p>
                    <p className="mt-1 break-words font-mono text-sm">{valueText(row.new_value)}</p>
                  </div>
                </div>

                <Button size="sm" variant="outline" onClick={() => navigate({ to: "/fichas/$id", params: { id: row.ficha_id } })}>
                  <ExternalLink className="size-4" /> Abrir ficha
                </Button>

                <div className="col-span-full flex flex-wrap gap-4 border-t pt-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1.5"><Database className="size-3.5" /> PDD: {row.external_order_id ?? row.fichas?.pdd_id ?? "—"}</span>
                  <span>Campo: <strong>{row.field_name}</strong></span>
                  <span>Evento: <strong>{row.change_type}</strong></span>
                  {row.sync_run_id && <span>Sync: <strong className="font-mono">{row.sync_run_id}</strong></span>}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </main>
    </div>
  );
}
