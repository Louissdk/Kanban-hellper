import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertCircle, ArrowRight, Loader2, PackageX } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SearchSelect } from "./SearchSelect";
import { profilesQuery, stagesQuery, errMsg, maskCustomerName } from "@/lib/data";
import { supabase } from "@/integrations/supabase/client";
import { transitionFicha } from "@/lib/transitions";
import { useAuth } from "@/lib/auth";

export interface TransitionFicha {
  ficha_id: string;
  order_number: string;
  customer: string;
  stage_id: string;
}

interface FichaItem {
  id: string;
  line_no: number;
  code: string | null;
  product: string | null;
  description: string | null;
  quantity: number | null;
  unit: string | null;
}

const RETURN_REASONS = [
  "Peça morreu / queimou",
  "Produção interrompida",
  "Retífica incorreta",
  "Perda de material",
  "Retrabalho necessário",
  "Erro de montagem",
  "Erro de soldagem",
  "Problema de qualidade",
  "Outro",
] as const;

interface TransitionModalProps {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  sectorId: string;
  fichas: TransitionFicha[];
  initialFichaId?: string | null;
  initialStageId?: string | null;
  source: "kanban" | "manual";
}

/** "Alterar etapa da ficha" — the mandatory, audited transition dialog. */
export function TransitionModal({ open, onOpenChange, sectorId, fichas, initialFichaId, initialStageId, source }: TransitionModalProps) {
  const qc = useQueryClient();
  const { userId, isAdmin } = useAuth();

  const [fichaId, setFichaId] = useState<string | null>(null);
  const [userSel, setUserSel] = useState<string | null>(null);
  const [stageId, setStageId] = useState<string | null>(null);
  const [obs, setObs] = useState("");
  const [returnReasonCategory, setReturnReasonCategory] = useState<string | null>(null);
  const [lostItemIds, setLostItemIds] = useState<string[]>([]);
  const [lostQuantities, setLostQuantities] = useState<Record<string, string>>({});
  const [tried, setTried] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [saving, setSaving] = useState(false);

  const { data: stages = [] } = useQuery(stagesQuery(sectorId));
  const { data: profiles = [] } = useQuery(profilesQuery);
  const { data: fichaItems = [], isLoading: itemsLoading, error: itemsError } = useQuery({
    queryKey: ["ficha-items", fichaId],
    enabled: open && !!fichaId,
    queryFn: async () => {
      const { data, error } = await supabase.from("ficha_items").select("id,line_no,code,product,description,quantity,unit").eq("ficha_id", fichaId!).order("line_no");
      if (error) throw new Error(error.message);
      return (data ?? []) as FichaItem[];
    },
  });

  useEffect(() => {
    if (open) {
      setFichaId(initialFichaId ?? null);
      setStageId(initialStageId ?? null);
      setUserSel(null);
      setObs("");
      setReturnReasonCategory(null);
      setLostItemIds([]);
      setLostQuantities({});
      setTried(false);
    }
  }, [open, initialFichaId, initialStageId, userId]);

  useEffect(() => {
    setLostItemIds([]);
    setLostQuantities({});
  }, [fichaId]);

  const ficha = fichas.find((f) => f.ficha_id === fichaId);
  const current = stages.find((s) => s.id === ficha?.stage_id);
  const target = stages.find((s) => s.id === stageId);
  const isReturn = !!current && !!target && target.position < current.position;
  const stageOptions = useMemo(
    () => stages.filter((s) => s.active && s.id !== ficha?.stage_id).map((s) => ({ value: s.id, label: `${s.position}. ${s.name}` })),
    [stages, ficha],
  );

  function requestConfirm() {
    setTried(true);
    if (!fichaId) return toast.error("Selecione a ficha.");
    if (!userSel) return toast.error("Selecione o usuário responsável pela mudança.");
    if (!stageId) return toast.error("Selecione a nova etapa.");
    if (isReturn && !returnReasonCategory) return toast.error("Selecione o motivo do retorno.");
    if (isReturn && !obs.trim()) return toast.error("Descreva por que a ficha está voltando de etapa.");
    if (isReturn) {
      for (const itemId of lostItemIds) {
        const item = (fichaItems as FichaItem[]).find((entry) => entry.id === itemId);
        const amount = Number(lostQuantities[itemId]);
        if (!item || !Number.isFinite(amount) || amount <= 0) {
          return toast.error("Informe a quantidade perdida para cada item selecionado.");
        }
        if (item.quantity != null && amount > Number(item.quantity)) {
          return toast.error(`A quantidade perdida do item ${item.line_no} não pode ser maior que ${item.quantity}.`);
        }
      }
    }
    setConfirming(true);
  }

  async function save() {
    if (!fichaId || !userSel || !stageId) return;
    setSaving(true);
    try {
      await transitionFicha({
        fichaId,
        newStageId: stageId,
        changedByUserId: userSel,
        observation: obs,
        ...(isReturn && returnReasonCategory ? { returnReasonCategory } : {}),
        source,
      });

      let lossErrors = 0;
      if (isReturn && lostItemIds.length > 0) {
        for (const itemId of lostItemIds) {
          const item = (fichaItems as FichaItem[]).find((entry) => entry.id === itemId);
          if (!item) continue;
          const amount = Number(lostQuantities[itemId]);
          const itemLabel = item.product?.trim() || item.description?.trim() || `Item ${item.line_no}`;
          const details = [
            `Perda registrada durante retorno de etapa.`,
            `Item do pedido: ${item.line_no}.`,
            item.code ? `Código: ${item.code}.` : "",
            item.description?.trim() ? `Descrição: ${item.description.trim()}.` : "",
            `Retorno: ${returnReasonCategory ?? "Outro"}.`,
          ].filter(Boolean).join(" ");
          const { error } = await supabase.rpc("record_production_loss", {
            _ficha_id: fichaId,
            _occurrence_date: new Date().toISOString().slice(0, 10),
            _sector_id: sectorId,
            _stage_id: current?.id ?? null,
            _responsible_id: userSel,
            _description: itemLabel,
            _quantity: amount,
            _unit: item.unit?.trim() || "UND",
            _reason_category: returnReasonCategory ?? "Outro",
            _details: details,
          });
          if (error) lossErrors += 1;
        }
      }

      if (lossErrors > 0) {
        toast.warning(`Etapa retornada, mas ${lossErrors} registro(s) de perda não puderam ser salvos. Verifique o histórico de perdas.`);
      } else {
        toast.success(
          lostItemIds.length > 0
            ? "Etapa retornada e perdas registradas no histórico."
            : "Etapa alterada e registrada no histórico."
        );
      }
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["board"] }),
        qc.invalidateQueries({ queryKey: ["ficha", fichaId] }),
      ]);
      setConfirming(false);
      onOpenChange(false);
    } catch (e) {
      toast.error(errMsg(e));
      setConfirming(false);
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Alterar etapa da ficha</DialogTitle>
            <DialogDescription>Ficha, usuário e nova etapa são obrigatórios. A mudança fica registrada no histórico.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="tm-ficha">Ficha *</Label>
              <SearchSelect
                id="tm-ficha"
                options={fichas.map((f) => ({ value: f.ficha_id, label: `#${f.order_number}`, hint: maskCustomerName(f.customer, isAdmin) }))}
                value={fichaId}
                onChange={(v) => {
                  setFichaId(v);
                  setStageId(null);
                }}
                placeholder="Selecione a ficha"
                invalid={tried && !fichaId}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Etapa atual</Label>
              <div className="rounded-md border bg-muted px-3 py-2 text-sm">{current?.name ?? "—"}</div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="tm-user">Usuário da mudança *</Label>
              <SearchSelect
                id="tm-user"
                options={profiles.filter((p) => p.active).map((p) => ({ value: p.id, label: p.full_name || p.email || p.id, hint: p.email ?? undefined }))}
                value={userSel}
                onChange={setUserSel}
                placeholder="Selecione o usuário"
                invalid={tried && !userSel}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="tm-stage">Nova etapa *</Label>
              <SearchSelect
                id="tm-stage"
                options={stageOptions}
                value={stageId}
                onChange={setStageId}
                placeholder="Selecione a nova etapa"
                disabled={!ficha}
                invalid={tried && !stageId}
              />
            </div>
            {isReturn && (
              <div className="rounded-lg border border-destructive/40 bg-destructive/5 p-3">
                <div className="mb-3 flex items-start gap-2 text-destructive">
                  <AlertCircle className="mt-0.5 size-4 shrink-0" />
                  <div>
                    <p className="text-sm font-semibold">Retorno de etapa — erro de produção</p>
                    <p className="text-xs">A ficha está voltando para uma etapa anterior. O motivo e a descrição serão salvos no histórico.</p>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="tm-return-reason">Motivo do retorno *</Label>
                  <Select value={returnReasonCategory ?? ""} onValueChange={setReturnReasonCategory}>
                    <SelectTrigger id="tm-return-reason" className={tried && isReturn && !returnReasonCategory ? "border-destructive" : ""}><SelectValue placeholder="Selecione o motivo" /></SelectTrigger>
                    <SelectContent>{RETURN_REASONS.map((reason) => <SelectItem key={reason} value={reason}>{reason}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
            )}
            {isReturn && (
              <div className="rounded-lg border border-warning/40 bg-warning/5 p-3">
                <div className="mb-3 flex items-start gap-2">
                  <PackageX className="mt-0.5 size-4 shrink-0 text-warning-foreground" />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold">Itens perdidos neste retorno</p>
                    <p className="text-xs text-muted-foreground">
                      Se alguma peça foi perdida, selecione o item e informe quantas unidades foram perdidas. É possível selecionar mais de um item.
                    </p>
                  </div>
                </div>
                {itemsLoading ? (
                  <div className="rounded-md border bg-background/60 px-3 py-3 text-sm text-muted-foreground">Carregando itens do pedido...</div>
                ) : itemsError ? (
                  <div className="rounded-md border border-destructive/30 bg-destructive/5 px-3 py-3 text-sm text-destructive">
                    Não foi possível carregar os itens deste pedido: {errMsg(itemsError)}
                  </div>
                ) : (fichaItems as FichaItem[]).length === 0 ? (
                  <div className="rounded-md border border-dashed bg-background/40 px-3 py-3 text-sm text-muted-foreground">
                    Este pedido não possui itens cadastrados para selecionar.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {(fichaItems as FichaItem[]).map((item) => {
                      const selected = lostItemIds.includes(item.id);
                      const itemLabel = item.product?.trim() || item.description?.trim() || `Item ${item.line_no}`;
                      const availableQuantity = item.quantity != null ? Number(item.quantity) : null;
                      return (
                        <div key={item.id} className="rounded-lg border bg-background/70 p-2.5">
                          <div className="flex items-start gap-2">
                            <Checkbox
                              id={`tm-loss-item-${item.id}`}
                              checked={selected}
                              disabled={saving}
                              onCheckedChange={(checked) => {
                                setLostItemIds((current) =>
                                  checked
                                    ? [...current, item.id]
                                    : current.filter((id) => id !== item.id),
                                );
                                if (checked && !lostQuantities[item.id]) {
                                  setLostQuantities((current) => ({
                                    ...current,
                                    [item.id]: availableQuantity != null && availableQuantity > 0 ? "1" : "",
                                  }));
                                }
                              }}
                              className="mt-0.5"
                            />
                            <label htmlFor={`tm-loss-item-${item.id}`} className="min-w-0 flex-1 cursor-pointer">
                              <span className="block truncate text-sm font-medium">
                                {item.line_no}. {itemLabel}
                              </span>
                              <span className="block truncate text-xs text-muted-foreground">
                                {item.code ? `Código: ${item.code} · ` : ""}
                                Pedido: {availableQuantity != null ? availableQuantity : "quantidade não informada"} {item.unit || "UND"}
                              </span>
                            </label>
                            {selected && (
                              <div className="w-24 shrink-0 space-y-1">
                                <Label htmlFor={`tm-loss-qty-${item.id}`} className="text-[11px]">Perdidas</Label>
                                <Input
                                  id={`tm-loss-qty-${item.id}`}
                                  type="number"
                                  min="0.01"
                                  step="0.01"
                                  max={availableQuantity ?? undefined}
                                  value={lostQuantities[item.id] ?? ""}
                                  onChange={(event) =>
                                    setLostQuantities((current) => ({
                                      ...current,
                                      [item.id]: event.target.value,
                                    }))
                                  }
                                  disabled={saving}
                                  className="h-8"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
                {lostItemIds.length > 0 && (
                  <p className="mt-2 text-[11px] text-muted-foreground">
                    {lostItemIds.length} item(ns) selecionado(s) para registrar como perda.
                  </p>
                )}
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="tm-obs">Observação {isReturn ? "*" : ""}</Label>
              <Textarea id="tm-obs" value={obs} onChange={(e) => setObs(e.target.value)} maxLength={1000} rows={3} placeholder={isReturn ? "Descreva o que aconteceu na produção e por que a ficha está voltando." : "Opcional"} className={tried && isReturn && !obs.trim() ? "border-destructive" : ""} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button onClick={requestConfirm}>Confirmar alteração</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={confirming} onOpenChange={(o) => !saving && setConfirming(o)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{isReturn ? "Confirmar retorno da ficha por erro de produção?" : "Confirmar alteração da ficha para esta etapa?"}</AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-2 text-sm">
                <p>Ficha <strong>#{ficha?.order_number}</strong> — {maskCustomerName(ficha?.customer, isAdmin)}</p>
                <p className="flex flex-wrap items-center gap-2">
                  <span>{current?.name}</span> <ArrowRight className="size-4" /> <strong>{target?.name}</strong>
                </p>
                <p>Responsável: {profiles.find((p) => p.id === userSel)?.full_name}</p>
                {isReturn && <p className="font-semibold text-destructive">Retorno: {returnReasonCategory}</p>}
                {isReturn && obs.trim() && <p>Motivo: {obs.trim()}</p>}
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={saving}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              disabled={saving}
              onClick={(e) => {
                e.preventDefault();
                void save();
              }}
            >
              {saving && <Loader2 className="size-4 animate-spin" />} Confirmar alteração
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
