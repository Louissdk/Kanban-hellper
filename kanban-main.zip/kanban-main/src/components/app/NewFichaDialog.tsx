import { useEffect, useState, type FormEvent } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, Loader2, Plus, Search, AlertTriangle, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SearchSelect } from "@/components/app/SearchSelect";
import { PRIORITY_LABEL, errMsg, fmtDate, fmtDateTime, maskCustomerName, type Priority } from "@/lib/data";
import { useAuth } from "@/lib/auth";

type LookupItem = {
  sequence?: number | null;
  code?: string | null;
  product?: string | null;
  description?: string | null;
  quantity?: number | null;
  unit?: string | null;
};

type LookupOrder = {
  external_order_id: string;
  customer_order_number?: string | null;
  customer?: string | null;
  customer_code?: string | null;
  codigo_cliente?: string | null;
  smb_cliente_id?: string | null;
  seller?: string | null;
  opened_at?: string | null;
  delivery_date?: string | null;
  smb_status?: string | null;
  status_smb?: string | null;
  status_smb_descricao?: string | null;
  pedido_cliente?: string | null;
  data_entrega?: string | null;
  envio?: string | null;
  product_summary?: string | null;
  quantity?: number | null;
  unit?: string | null;
  source_observations?: string | null;
  items?: LookupItem[];
};

type LookupResponse = {
  order: LookupOrder;
  duplicate: {
    ficha_id: string;
    order_number: string;
    customer_code: string | null;
    seller_name: string | null;
    smb_status: string | null;
    sector_name: string | null;
    stage_name: string | null;
  } | null;
  completed_in_smb: boolean;
  customer_code_resolution?: "unique" | "not_found" | "ambiguous" | "no_customer";
};

type CreateResponse = {
  created: boolean;
  duplicate?: boolean;
  ficha_id?: string;
  pdd_id?: string;
  completed_in_smb?: boolean;
  sector_name?: string;
  stage_name?: string;
};

type ManualItem = {
  id: number;
  code: string;
  product: string;
  description: string;
  quantity: string;
  unit: string;
};

type ManualCreatePayload = {
  orderNumber: string;
  customer: string;
  items: Array<{
    code: string | null;
    product: string;
    description: string | null;
    quantity: number | null;
    unit: string;
  }>;
  deliveryDate: string | null;
  priority: Priority;
  sellerName: string;
};

type DuplicateCandidate = {
  id: string;
  order_number: string;
  customer: string;
  source_system: string;
};

const OTHER_SELLER = "__other__";

function createManualItem(id: number): ManualItem {
  return { id, code: "", product: "", description: "", quantity: "", unit: "UND" };
}

export function NewFichaDialog({ sectorId }: { sectorId: string }) {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<"lookup" | "manual">("lookup");
  const [pddId, setPddId] = useState("");
  const [lookupBusy, setLookupBusy] = useState(false);
  const [createBusy, setCreateBusy] = useState(false);
  const [lookup, setLookup] = useState<LookupResponse | null>(null);
  const [priority, setPriority] = useState<Priority>("normal");
  const [sellerChoice, setSellerChoice] = useState("");
  const [customSeller, setCustomSeller] = useState("");
  const [manualItems, setManualItems] = useState<ManualItem[]>([createManualItem(1)]);
  const [nextItemId, setNextItemId] = useState(2);
  const [duplicatePrompt, setDuplicatePrompt] = useState<{
    payload: ManualCreatePayload;
    existing: DuplicateCandidate[];
  } | null>(null);

  const { data: sellerOptions = [] } = useQuery({
    queryKey: ["seller-options"],
    staleTime: 60_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("fichas")
        .select("seller_name")
        .not("seller_name", "is", null)
        .order("seller_name")
        .limit(2000);

      if (error) throw new Error(error.message);
      return [...new Set((data ?? []).map((row) => row.seller_name?.trim()).filter((name): name is string => !!name))];
    },
  });

  function reset() {
    setMode("lookup");
    setPddId("");
    setLookupBusy(false);
    setCreateBusy(false);
    setLookup(null);
    setPriority("normal");
    setSellerChoice("");
    setCustomSeller("");
    setManualItems([createManualItem(1)]);
    setNextItemId(2);
    setDuplicatePrompt(null);
  }

  function updateManualItem(id: number, patch: Partial<Omit<ManualItem, "id">>) {
    setManualItems((items) => items.map((item) => (item.id === id ? { ...item, ...patch } : item)));
  }

  function addManualItem() {
    const id = nextItemId;
    setNextItemId((value) => value + 1);
    setManualItems((items) => [...items, createManualItem(id)]);
  }

  function removeManualItem(id: number) {
    setManualItems((items) => items.filter((item) => item.id !== id));
  }

  async function lookupOrder() {
    const value = pddId.trim();
    if (!value) {
      toast.error("Informe o pdd_id do SMB.");
      return;
    }

    setLookupBusy(true);
    setLookup(null);

    try {
      const session = await supabase.auth.getSession();
      const token = session.data.session?.access_token;
      if (!token) throw new Error("Sua sessão expirou. Entre novamente no sistema.");

      const response = await fetch("/api/sync/smb/lookup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token,
        },
        body: JSON.stringify({ pdd_id: value }),
      });

      const body = (await response.json().catch(() => ({}))) as Partial<LookupResponse> & { message?: string };

      if (!response.ok) {
        throw new Error(body.message || "Não foi possível consultar a ficha no SMB.");
      }

      if (!body.order) throw new Error("O robô não retornou a ficha solicitada.");
      setLookup(body as LookupResponse);
    } catch (error) {
      toast.error(errMsg(error));
    } finally {
      setLookupBusy(false);
    }
  }

  async function addFromSmb() {
    if (!lookup?.order) return;
    if (lookup.duplicate) {
      toast.error("Este pedido já está no Kanban.");
      return;
    }

    setCreateBusy(true);
    try {
      const { data, error } = await supabase.rpc("create_smb_ficha_from_lookup", {
        _order: lookup.order,
        _sector_id: sectorId,
        _priority: isAdmin ? priority : "normal",
      });

      if (error) throw error;

      const result = data as CreateResponse;
      if (result.duplicate) {
        toast.error("Este pedido já está no Kanban.");
        setLookup({
          ...lookup,
          duplicate: {
            ficha_id: result.ficha_id ?? "",
            order_number: result.pdd_id ?? lookup.order.external_order_id,
            customer_code: null,
            seller_name: null,
            smb_status: lookup.order.smb_status ?? null,
            sector_name: result.sector_name ?? null,
            stage_name: result.stage_name ?? null,
          },
        });
        return;
      }

      toast.success(
        result.completed_in_smb
          ? "Pedido concluído no SMB adicionado em Enviado/Finalizado."
          : "Pedido encontrado no SMB e adicionado ao Kanban.",
      );
      await qc.invalidateQueries({ queryKey: ["board"] });
      await qc.invalidateQueries({ queryKey: ["ficha"] });
      setOpen(false);
    } catch (error) {
      toast.error(errMsg(error));
    } finally {
      setCreateBusy(false);
    }
  }

  async function createManualRecord(payload: ManualCreatePayload, allowDuplicate: boolean) {
    setCreateBusy(true);
    try {
      const { data, error } = await supabase.rpc("create_manual_ficha_with_items", {
        _order_number: payload.orderNumber,
        _customer: payload.customer,
        _items: payload.items,
        _delivery_date: payload.deliveryDate || null,
        _sector_id: sectorId,
        _priority: isAdmin ? payload.priority : "normal",
        _seller_name: payload.sellerName,
        _allow_duplicate: allowDuplicate,
      });

      if (error) throw error;

      if (allowDuplicate) {
        toast.success("Duplicidade criada pela administração. As duas fichas permanecem visíveis no Kanban.");
      } else if (payload.items.length === 1) {
        toast.success("Ficha criada na primeira etapa do setor.");
      } else {
        toast.success("Ficha criada com " + payload.items.length + " itens na primeira etapa do setor.");
      }

      await qc.invalidateQueries({ queryKey: ["board"] });
      await qc.invalidateQueries({ queryKey: ["seller-options"] });
      await qc.invalidateQueries({ queryKey: ["ficha"] });

      setDuplicatePrompt(null);
      setOpen(false);

      const createdFichaId = typeof data === "string" ? data : null;
      if (allowDuplicate && createdFichaId) {
        navigate({ to: "/fichas/$id", params: { id: createdFichaId } });
      }
    } catch (error) {
      toast.error(errMsg(error));
    } finally {
      setCreateBusy(false);
    }
  }

  async function submitManual(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();

    const f = new FormData(e.currentTarget);
    const orderNumber = String(f.get("order_number") ?? "").trim();
    const customer = String(f.get("customer") ?? "").trim();
    const sellerName = sellerChoice === OTHER_SELLER ? customSeller.trim() : sellerChoice.trim();

    if (!orderNumber) {
      toast.error("Número do pedido é obrigatório.");
      return;
    }

    if (!customer) {
      toast.error("Cliente é obrigatório.");
      return;
    }

    if (!sellerName) {
      toast.error("Selecione ou informe o vendedor responsável.");
      return;
    }

    if (manualItems.length === 0) {
      toast.error("Adicione pelo menos um item ao pedido.");
      return;
    }

    const invalidItem = manualItems.find((item) => {
      const quantity = item.quantity.trim() ? Number(item.quantity) : null;
      return !item.product.trim() || (quantity != null && (!Number.isFinite(quantity) || quantity < 0));
    });

    if (invalidItem) {
      toast.error("Cada item precisa de produto e uma quantidade válida.");
      return;
    }

    const items = manualItems.map((item) => ({
      code: item.code.trim() || null,
      product: item.product.trim(),
      description: item.description.trim() || null,
      quantity: item.quantity.trim() ? Number(item.quantity) : null,
      unit: item.unit.trim() || "UND",
    }));

    const payload: ManualCreatePayload = {
      orderNumber,
      customer,
      items,
      deliveryDate: String(f.get("delivery") ?? "") || null,
      priority: isAdmin ? priority : "normal",
      sellerName,
    };

    try {
      const { data: candidates, error: duplicateError } = await supabase
        .from("fichas")
        .select("id,order_number,customer,source_system")
        .eq("order_number", orderNumber)
        .limit(100);

      if (duplicateError) throw new Error(duplicateError.message);

      const normalize = (value: string) => value.trim().toLocaleUpperCase("pt-BR");
      const matching = ((candidates ?? []) as DuplicateCandidate[]).filter(
        (candidate) => normalize(candidate.customer) === normalize(customer),
      );

      if (matching.length > 0) {
        if (!isAdmin) {
          toast.error("Este pedido já existe para este cliente (FICHA #" + matching[0].order_number + "). Somente a administração pode criar uma duplicidade.");
          return;
        }

        setDuplicatePrompt({ payload, existing: matching });
        return;
      }

      await createManualRecord(payload, false);
    } catch (error) {
      toast.error(errMsg(error));
    }
  }

  async function confirmManualDuplicate() {
    if (!duplicatePrompt) return;
    await createManualRecord(duplicatePrompt.payload, true);
  }

  const order = lookup?.order;
  const completed = lookup?.completed_in_smb;
  const duplicate = lookup?.duplicate;
  const customerCodeIssue =
    lookup?.customer_code_resolution === "not_found" || lookup?.customer_code_resolution === "ambiguous";

  return (
    <>
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) reset();
      }}
    >
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Search className="size-4" />
          Inserir pedido
        </Button>
      </DialogTrigger>

      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>{mode === "lookup" ? "Buscar pedido no SMB" : "Nova ficha manual"}</DialogTitle>
          <DialogDescription>
            {mode === "lookup"
              ? "Informe o pdd_id. O backend solicitará ao robô a ficha real no SMB, sem acesso do navegador ao sistema original."
              : "Cadastre o pedido manualmente. Você pode definir o vendedor e adicionar quantos itens forem necessários."}
          </DialogDescription>
        </DialogHeader>

        {mode === "lookup" ? (
          <div className="space-y-4">
            <div className="flex items-end gap-2">
              <div className="min-w-0 flex-1 space-y-1.5">
                <Label htmlFor="pdd-id">pdd_id do SMB</Label>
                <Input
                  id="pdd-id"
                  inputMode="numeric"
                  value={pddId}
                  onChange={(e) => setPddId(e.target.value.replace(/\D/g, ""))}
                  placeholder="Ex.: 9694"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      void lookupOrder();
                    }
                  }}
                />
              </div>
              <Button
                type="button"
                onClick={() => void lookupOrder()}
                disabled={lookupBusy || !pddId.trim()}
                aria-label="Pesquisar pedido no SMB"
              >
                {lookupBusy ? <Loader2 className="size-4 animate-spin" /> : <Search className="size-4" />}
                {lookupBusy ? "Consultando..." : "Pesquisar"}
              </Button>
            </div>

            {lookupBusy && (
              <div className="flex items-center gap-2 rounded-xl border bg-muted/40 p-3 text-sm text-muted-foreground">
                <Loader2 className="size-4 animate-spin" />
                Consultando o robô no SMB...
              </div>
            )}

            {duplicate && (
              <div className="rounded-xl border border-warning/50 bg-warning/10 p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="mt-0.5 size-5 shrink-0 text-warning-foreground" />
                  <div className="min-w-0">
                    <p className="font-semibold">Este pedido já está no Kanban</p>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Ficha #{duplicate.order_number} · Setor: {duplicate.sector_name ?? "—"} · Área/etapa: {duplicate.stage_name ?? "—"}
                    </p>
                    {duplicate.ficha_id && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="mt-3"
                        onClick={() => {
                          setOpen(false);
                          void navigate({ to: "/fichas/$id", params: { id: duplicate.ficha_id } });
                        }}
                      >
                        Abrir ficha no Kanban
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            )}

            {order && (
              <div className="space-y-4 rounded-2xl border bg-card p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="font-mono text-lg font-bold">PDD #{order.external_order_id}</p>
                    <p className="text-xs text-muted-foreground">Dados reais retornados pelo robô</p>
                  </div>
                  {order.smb_status && (
                    <span
                      className={
                        completed
                          ? "rounded-lg bg-success/15 px-2.5 py-1 text-xs font-semibold text-success-foreground"
                          : "rounded-lg bg-secondary px-2.5 py-1 text-xs font-semibold"
                      }
                    >
                      SMB: {order.smb_status}
                    </span>
                  )}
                </div>

                {customerCodeIssue && !duplicate && (
                  <div className="flex items-start gap-3 rounded-xl border border-warning/40 bg-warning/10 p-3">
                    <AlertTriangle className="mt-0.5 size-5 shrink-0 text-warning-foreground" />
                    <div>
                      <p className="font-semibold">Código do cliente não resolvido</p>
                      <p className="text-sm text-muted-foreground">
                        {lookup?.customer_code_resolution === "ambiguous"
                          ? "Há mais de um cliente compatível no cadastro. O código foi mantido NULL."
                          : "O cliente não foi encontrado de forma única no cadastro. O código foi mantido NULL."}
                      </p>
                    </div>
                  </div>
                )}

                {completed && !duplicate && (
                  <div className="flex items-start gap-3 rounded-xl border border-success/40 bg-success/10 p-3">
                    <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-success" />
                    <div>
                      <p className="font-semibold">Este pedido está CONCLUÍDO no SMB</p>
                      <p className="text-sm text-muted-foreground">Ao adicionar, ele será colocado diretamente em Enviado/Finalizado.</p>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <Info label="Pedido do cliente" value={order.pedido_cliente ?? order.customer_order_number} />
                  <Info label="Código do cliente" value={order.codigo_cliente ?? order.customer_code} />
                  <Info label="Cliente no SMB" value={order.smb_cliente_id} />
                  <Info label="Cliente" value={maskCustomerName(order.customer, isAdmin)} />
                  <Info label="Vendedor" value={order.seller} />
                  <Info label="Abertura" value={fmtDateTime(order.opened_at)} />
                  <Info label="Entrega" value={fmtDate(order.data_entrega ?? order.delivery_date)} />
                  <Info label="Envio" value={order.envio} />
                  <Info label="Status SMB" value={order.status_smb_descricao ?? order.smb_status} />
                  <Info
                    label="Quantidade"
                    value={order.quantity == null ? null : `${order.quantity} ${order.unit ?? ""}`}
                  />
                  <Info label="Produto" value={order.product_summary} />
                </div>

                <div>
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <h3 className="text-sm font-semibold">Itens do pedido</h3>
                    <span className="text-xs text-muted-foreground">{order.items?.length ?? 0} item(ns)</span>
                  </div>
                  <div className="space-y-2">
                    {(order.items ?? []).map((item, index) => (
                      <div key={`${item.sequence ?? index + 1}-${index}`} className="rounded-xl border p-3">
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
                          <span className="font-semibold">Item {item.sequence ?? index + 1}</span>
                          <span>
                            Qtd.: {item.quantity ?? "—"} {item.unit ?? ""}
                          </span>
                        </div>
                        <p className="mt-1 text-sm">{item.description ?? item.product ?? "Sem descrição"}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <p className="text-xs text-muted-foreground">
                  Consulta realizada pelo robô SMB. O navegador não acessa o sistema original.
                </p>

                {!duplicate && (
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <Label>Prioridade no Kanban</Label>
                      {!isAdmin && <span className="text-[11px] text-muted-foreground">Somente Admin</span>}
                    </div>
                    <Select value={priority} onValueChange={(v) => setPriority(v as Priority)} disabled={!isAdmin}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(PRIORITY_LABEL).map(([key, label]) => (
                          <SelectItem key={key} value={key}>
                            {label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <form id="manual-ficha-form" onSubmit={submitManual} className="space-y-5">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="nf-on">Nº da ficha *</Label>
                <Input id="nf-on" name="order_number" required maxLength={40} placeholder="Ex.: 10254" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="nf-d">Prazo de entrega</Label>
                <Input id="nf-d" name="delivery" type="date" />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="nf-c">Cliente *</Label>
                <Input id="nf-c" name="customer" required maxLength={200} placeholder="Nome do cliente" />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Vendedor responsável *</Label>
                <Select
                  value={sellerChoice}
                  onValueChange={(value) => {
                    setSellerChoice(value);
                    if (value !== OTHER_SELLER) setCustomSeller("");
                  }}
                >
                  <SelectTrigger aria-label="Vendedor responsável">
                    <SelectValue placeholder={sellerOptions.length ? "Selecione o vendedor" : "Informe o vendedor"} />
                  </SelectTrigger>
                  <SelectContent>
                    {sellerOptions.map((name) => (
                      <SelectItem key={name} value={name}>
                        {name}
                      </SelectItem>
                    ))}
                    <SelectItem value={OTHER_SELLER}>Outro vendedor...</SelectItem>
                  </SelectContent>
                </Select>
                {sellerOptions.length === 0 && (
                  <p className="text-xs text-muted-foreground">
                    Nenhum vendedor existente foi encontrado ainda. Escolha “Outro vendedor...” para cadastrar o nome nesta ficha.
                  </p>
                )}
                {sellerChoice === OTHER_SELLER && (
                  <Input
                    value={customSeller}
                    onChange={(e) => setCustomSeller(e.target.value)}
                    placeholder="Nome do vendedor"
                    maxLength={120}
                    autoFocus
                  />
                )}
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <Label>Prioridade no Kanban</Label>
                  {!isAdmin && <span className="text-[11px] text-muted-foreground">Somente Admin</span>}
                </div>
                <Select value={priority} onValueChange={(v) => setPriority(v as Priority)} disabled={!isAdmin}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(PRIORITY_LABEL).map(([key, label]) => (
                      <SelectItem key={key} value={key}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <section className="rounded-2xl border bg-muted/20 p-3 sm:p-4">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-semibold">Itens do pedido</h3>
                  <p className="text-xs text-muted-foreground">
                    Adicione um item por linha. O card do Kanban mostrará apenas um resumo compacto.
                  </p>
                </div>
                <span className="rounded-md bg-background px-2 py-1 text-xs font-semibold">
                  {manualItems.length} {manualItems.length === 1 ? "item" : "itens"}
                </span>
              </div>

              <div className="space-y-2.5">
                {manualItems.map((item, index) => (
                  <div key={item.id} className="rounded-xl border bg-card p-3">
                    <div className="mb-2 flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Item {index + 1}
                      </span>
                      {manualItems.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="size-8 text-muted-foreground hover:text-destructive"
                          onClick={() => removeManualItem(item.id)}
                          aria-label={`Remover item ${index + 1}`}
                          title="Remover item"
                        >
                          <Trash2 className="size-4" />
                        </Button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-6">
                      <div className="space-y-1 sm:col-span-2">
                        <Label className="text-xs" htmlFor={`item-product-${item.id}`}>
                          Produto *
                        </Label>
                        <Input
                          id={`item-product-${item.id}`}
                          value={item.product}
                          onChange={(e) => updateManualItem(item.id, { product: e.target.value })}
                          placeholder="Ex.: Resistência cartucho"
                          maxLength={200}
                        />
                      </div>

                      <div className="space-y-1 sm:col-span-2">
                        <Label className="text-xs" htmlFor={`item-description-${item.id}`}>
                          Descrição
                        </Label>
                        <Input
                          id={`item-description-${item.id}`}
                          value={item.description}
                          onChange={(e) => updateManualItem(item.id, { description: e.target.value })}
                          placeholder="Detalhes do item"
                          maxLength={300}
                        />
                      </div>

                      <div className="space-y-1">
                        <Label className="text-xs" htmlFor={`item-quantity-${item.id}`}>
                          Qtd.
                        </Label>
                        <Input
                          id={`item-quantity-${item.id}`}
                          value={item.quantity}
                          onChange={(e) => updateManualItem(item.id, { quantity: e.target.value })}
                          inputMode="decimal"
                          type="number"
                          min="0"
                          step="any"
                          placeholder="0"
                        />
                      </div>

                      <div className="space-y-1">
                        <Label className="text-xs" htmlFor={`item-unit-${item.id}`}>
                          Un.
                        </Label>
                        <Input
                          id={`item-unit-${item.id}`}
                          value={item.unit}
                          onChange={(e) => updateManualItem(item.id, { unit: e.target.value })}
                          maxLength={10}
                          placeholder="UND"
                        />
                      </div>

                      <div className="space-y-1 sm:col-span-2">
                        <Label className="text-xs" htmlFor={`item-code-${item.id}`}>
                          Código
                        </Label>
                        <Input
                          id={`item-code-${item.id}`}
                          value={item.code}
                          onChange={(e) => updateManualItem(item.id, { code: e.target.value })}
                          maxLength={100}
                          placeholder="Opcional"
                          className="font-mono"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <Button type="button" variant="outline" size="sm" className="mt-3" onClick={addManualItem}>
                <Plus className="size-4" />
                Adicionar item
              </Button>
            </section>
          </form>
        )}

        <DialogFooter className="flex-col-reverse gap-2 sm:flex-row sm:justify-between">
          {mode === "lookup" ? (
            <>
              <Button type="button" variant="ghost" onClick={() => setMode("manual")}>
                Preencher manualmente
              </Button>
              <div className="flex gap-2">
                {order && !duplicate && (
                  <Button type="button" onClick={() => void addFromSmb()} disabled={createBusy}>
                    {createBusy && <Loader2 className="size-4 animate-spin" />}
                    {completed ? "Adicionar mesmo assim" : "Adicionar ao Kanban"}
                  </Button>
                )}
              </div>
            </>
          ) : (
            <>
              <Button type="button" variant="ghost" onClick={() => setMode("lookup")}>
                Buscar no SMB
              </Button>
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" form="manual-ficha-form" disabled={createBusy}>
                  {createBusy && <Loader2 className="size-4 animate-spin" />}
                  Criar ficha
                </Button>
              </div>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>

    <AlertDialog
      open={!!duplicatePrompt}
      onOpenChange={(next) => {
        if (!next && !createBusy) setDuplicatePrompt(null);
      }}
    >
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Pedido já existente</AlertDialogTitle>
          <AlertDialogDescription>
            Já existe {duplicatePrompt?.existing.length === 1 ? "uma ficha" : String(duplicatePrompt?.existing.length ?? 0) + " fichas"} com o mesmo número e cliente.
            A administração pode criar o segundo registro de forma intencional. Depois, as fichas continuarão visíveis no Kanban e poderão ser resolvidas.
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="max-h-48 space-y-2 overflow-auto rounded-lg border bg-muted/20 p-3 text-sm">
          {duplicatePrompt?.existing.map((candidate) => (
            <div key={candidate.id} className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="font-mono font-semibold">FICHA #{candidate.order_number}</p>
                <p className="truncate text-xs text-muted-foreground">
                  Origem: {candidate.source_system === "SMB" ? "SMB" : "Manual"}
                </p>
              </div>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={() => {
                  setDuplicatePrompt(null);
                  setOpen(false);
                  navigate({ to: "/fichas/$id", params: { id: candidate.id } });
                }}
              >
                Abrir
              </Button>
            </div>
          ))}
        </div>

        <AlertDialogFooter>
          <AlertDialogCancel disabled={createBusy}>Cancelar</AlertDialogCancel>
          <AlertDialogAction
            onClick={(event) => {
              event.preventDefault();
              void confirmManualDuplicate();
            }}
            disabled={createBusy}
          >
            {createBusy && <Loader2 className="size-4 animate-spin" />}
            Criar duplicidade
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
    </>
  );
}

function Info({ label, value }: { label: string; value?: string | number | null }) {
  return (
    <div className="min-w-0 rounded-xl border bg-muted/20 p-3">
      <p className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 truncate text-sm font-medium">{value || "—"}</p>
    </div>
  );
}
