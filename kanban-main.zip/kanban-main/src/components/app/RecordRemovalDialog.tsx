import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, Loader2, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SearchSelect } from "./SearchSelect";
import { errMsg } from "@/lib/data";
import { supabase } from "@/integrations/supabase/client";

interface Authorizer { profile_id:string; full_name:string; email:string|null; active:boolean; }

export function ConfirmRecordRemovalDialog({open,onOpenChange,fichaId,orderNumber,onRemoved}:{open:boolean;onOpenChange:(open:boolean)=>void;fichaId:string;orderNumber:string;onRemoved:()=>void}) {
  const qc=useQueryClient();
  const [profileId,setProfileId]=useState<string|null>(null);
  const [pin,setPin]=useState("");
  const [confirming,setConfirming]=useState(false);
  const [saving,setSaving]=useState(false);
  const {data:profiles=[],isLoading,error}=useQuery({
    queryKey:["delete-authorizers"],enabled:open,
    queryFn:async()=>{const {data,error}=await supabase.rpc("get_delete_authorizers");if(error)throw new Error(error.message);return (data??[]) as Authorizer[]}
  });
  useEffect(()=>{if(open){setProfileId(null);setPin("");setConfirming(false)}},[open]);
  const request=()=>{if(!profileId)return toast.error("Selecione o perfil autorizador.");if(!pin)return toast.error("Digite o PIN de exclusão.");setConfirming(true)};
  const remove=async()=>{if(!profileId||!pin)return;setSaving(true);try{const {error}=await supabase.rpc("delete_ficha",{_ficha_id:fichaId,_authorized_profile_id:profileId,_pin:pin});if(error)throw new Error(error.message);toast.success(`Pedido #${orderNumber} excluído e registrado no histórico.`);await qc.invalidateQueries({queryKey:["board"]});await qc.invalidateQueries({queryKey:["ficha",fichaId]});setConfirming(false);onOpenChange(false);onRemoved()}catch(e){toast.error(errMsg(e));setConfirming(false)}finally{setSaving(false)}};
  return <><Dialog open={open} onOpenChange={v=>!saving&&onOpenChange(v)}><DialogContent className="sm:max-w-md"><DialogHeader><DialogTitle>Excluir pedido #{orderNumber}</DialogTitle><DialogDescription>Somente administradores podem excluir. É obrigatório selecionar um perfil autorizador e informar o PIN.</DialogDescription></DialogHeader><div className="space-y-4">{error&&<p className="rounded-md border border-destructive/40 bg-destructive/5 p-3 text-sm text-destructive">{errMsg(error)}</p>}<div className="rounded-md border border-warning/40 bg-warning/10 p-3 text-sm"><div className="flex gap-2"><AlertTriangle className="mt-0.5 size-4 shrink-0 text-warning"/><div><p className="font-semibold">Confirmação administrativa</p><p className="text-muted-foreground">Selecione Matheus, Henrique ou Gabrielly e informe o PIN configurado.</p></div></div></div><div className="space-y-1.5"><Label>Perfil autorizador *</Label><SearchSelect options={profiles.filter(p=>p.active).map(p=>({value:p.profile_id,label:p.full_name,...(p.email ? {hint:p.email} : {})}))} value={profileId} onChange={setProfileId} placeholder={isLoading?"Carregando perfis...":"Selecione o perfil"} disabled={isLoading||saving}/></div><div className="space-y-1.5"><Label htmlFor="record-removal-pin">PIN de exclusão *</Label><Input id="record-removal-pin" type="password" value={pin} onChange={e=>setPin(e.target.value)} disabled={saving} inputMode="numeric" autoComplete="off" placeholder="Digite o PIN"/></div></div><DialogFooter><Button variant="outline" onClick={()=>onOpenChange(false)} disabled={saving}>Cancelar</Button><Button variant="destructive" onClick={request} disabled={saving||!profileId||!pin}><Trash2 className="size-4"/> Excluir pedido</Button></DialogFooter></DialogContent></Dialog><AlertDialog open={confirming} onOpenChange={v=>!saving&&setConfirming(v)}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Confirmar exclusão definitiva?</AlertDialogTitle><AlertDialogDescription>O pedido será removido do quadro. O sistema conservará internamente um registro administrativo da exclusão.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel disabled={saving}>Cancelar</AlertDialogCancel><AlertDialogAction disabled={saving} onClick={e=>{e.preventDefault();void remove()}}>{saving&&<Loader2 className="size-4 animate-spin"/>} Confirmar exclusão</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog></>
}
