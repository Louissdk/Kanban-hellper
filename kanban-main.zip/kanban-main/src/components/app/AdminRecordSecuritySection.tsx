import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { errMsg, profilesQuery } from "@/lib/data";
import { supabase } from "@/integrations/supabase/client";

interface SecurityState { can_manage:boolean; authorized_profile_ids:string[]; }

export function AdminRecordSecuritySection({isAdmin}:{isAdmin:boolean}) {
 const qc=useQueryClient(); const {data:profiles=[]}=useQuery(profilesQuery);
 const {data:state}=useQuery({queryKey:["delete-security"],enabled:isAdmin,queryFn:async()=>{const {data,error}=await supabase.rpc("get_delete_security_state");if(error)throw new Error(error.message);return data as SecurityState}});
 const [authorizedIds,setAuthorizedIds]=useState<string[]>([]); const [securityCode,setSecurityCode]=useState(""); const [saving,setSaving]=useState(false);
 useEffect(()=>setAuthorizedIds(state?.authorized_profile_ids??[]),[state]); if(!isAdmin)return null;
 const eligible=profiles.filter(p=>["matheus","henrique","gabrielly"].includes((p.full_name||"").trim().split(/\s+/)[0]?.toLowerCase()));
 async function saveProfiles(){setSaving(true);try{const {error}=await supabase.rpc("set_delete_authorizers",{_profile_ids:authorizedIds});if(error)throw new Error(error.message);await qc.invalidateQueries({queryKey:["delete-security"]});await qc.invalidateQueries({queryKey:["delete-authorizers"]});toast.success("Perfis autorizadores atualizados.")}catch(e){toast.error(errMsg(e))}finally{setSaving(false)}}
 async function saveCode(){if(!securityCode.trim())return toast.error("Informe o novo código.");setSaving(true);try{const {error}=await supabase.rpc("set_delete_pin",{_pin:securityCode.trim()});if(error)throw new Error(error.message);setSecurityCode("");toast.success("Código de exclusão atualizado.")}catch(e){toast.error(errMsg(e))}finally{setSaving(false)}}
 return <section className="border-t bg-card p-4 md:p-6"><Separator className="mb-6"/><div className="rounded-xl border bg-background p-5"><h2 className="font-semibold">Segurança de exclusão de pedidos</h2><p className="mt-1 text-sm text-muted-foreground">A exclusão exige administrador, perfil autorizador e código de segurança. Somente Matheus e Henrique podem alterar estas regras.</p>{!state?.can_manage&&<div className="mt-4 rounded-md border bg-muted p-3 text-sm text-muted-foreground">Apenas Matheus e Henrique podem alterar esta configuração.</div>}<div className="mt-5 grid gap-5 lg:grid-cols-2"><div className="space-y-3 rounded-lg border p-4"><div><Label>Perfis autorizadores</Label><p className="text-xs text-muted-foreground">Permitidos: Matheus, Henrique e Gabrielly.</p></div>{eligible.length===0?<p className="text-sm text-muted-foreground">Os perfis ainda não estão cadastrados.</p>:eligible.map(p=>{const checked=authorizedIds.includes(p.id);return <label key={p.id} className="flex items-center gap-3 rounded-md border p-2"><Checkbox checked={checked} disabled={!state?.can_manage||saving} onCheckedChange={v=>setAuthorizedIds(current=>v?[...new Set([...current,p.id])]:current.filter(id=>id!==p.id))}/><span className="text-sm"><span className="font-medium">{p.full_name}</span><span className="block text-xs text-muted-foreground">{p.email??"Sem e-mail"}</span></span></label>})}<Button size="sm" onClick={()=>void saveProfiles()} disabled={!state?.can_manage||saving||eligible.length===0}>Salvar perfis</Button></div><div className="space-y-3 rounded-lg border p-4"><div><Label htmlFor="admin-security-code">Alterar código de exclusão</Label><p className="text-xs text-muted-foreground">O valor não é exibido no sistema.</p></div><Input id="admin-security-code" type="password" inputMode="numeric" autoComplete="new-password" value={securityCode} onChange={e=>setSecurityCode(e.target.value)} disabled={!state?.can_manage||saving} placeholder="Novo código"/><Button size="sm" onClick={()=>void saveCode()} disabled={!state?.can_manage||saving||!securityCode}>Atualizar código</Button></div></div></div></section>
}
