import { useSortable } from "@dnd-kit/sortable";
import { useEffect, useRef } from "react";
import { CSS } from "@dnd-kit/utilities";
import { Link, useNavigate } from "@tanstack/react-router";
import { CheckCircle2, Clock, Copy, Flame, GripVertical, Package2, RotateCcw, Sparkles, Star, UserRound } from "lucide-react";
import { cn } from "@/lib/utils";
import { type BoardCard, PRIORITY_LABEL, fmtDate, fmtDateTime, isOverdue } from "@/lib/data";

interface FichaCardProps {
  card: BoardCard;
  responsibleName?: string;
  fields: string[];
  staleHours: number;
  isFinalStage: boolean;
  draggable: boolean;
  overlay?: boolean;
}

const PRIORITY_CLS: Record<string, string> = {
  urgente: "border-destructive/40 bg-destructive/10 text-destructive",
  alta: "border-warning/40 bg-warning/10 text-warning-foreground",
  normal: "border-info/30 bg-info/5 text-info",
  baixa: "border-border bg-muted/60 text-muted-foreground",
};

const PRIORITY_CARD_CLS: Record<string, string> = {
  urgente: "border-destructive/60 bg-destructive/10 dark:bg-destructive/[0.055]",
  alta: "border-warning/60 bg-warning/10 dark:bg-warning/[0.055]",
  normal: "border-info/45 bg-info/[0.065] dark:bg-info/[0.035]",
  baixa: "border-border bg-muted/55 dark:border-border/80 dark:bg-muted/[0.32]",
};

const PRIORITY_RAIL_CLS: Record<string, string> = {
  urgente: "bg-destructive",
  alta: "bg-warning",
  normal: "bg-info",
  baixa: "bg-muted-foreground/35",
};

export function FichaCard({
  card,
  responsibleName,
  fields,
  staleHours,
  isFinalStage,
  draggable,
  overlay,
}: FichaCardProps) {
  const navigate = useNavigate();
  const { attributes, listeners, setNodeRef, setActivatorNodeRef, isDragging, transform, transition } = useSortable({
    id: card.ficha_id,
    disabled: !draggable || overlay,
    data: {
      type: "card",
      stageId: card.stage_id,
      fichaId: card.ficha_id,
    },
  });
  const wasDraggedRef = useRef(false);
  useEffect(() => {
    if (isDragging) {
      wasDraggedRef.current = true;
      return;
    }
    if (wasDraggedRef.current) {
      const timer = window.setTimeout(() => {
        wasDraggedRef.current = false;
      }, 250);
      return () => window.clearTimeout(timer);
    }
  }, [isDragging]);
  const f = card.fichas;
  const dragHandleLabel = isDragging ? "Movendo ficha. Solte em uma etapa." : "Arraste a ficha para outra etapa. No celular, segure por 2 segundos.";
  const overdue = isOverdue(f.delivery_date, card.completed_at);
  const hoursInStage = (Date.now() - new Date(card.entered_stage_at).getTime()) / 36e5;
  const stale = !isFinalStage && hoursInStage > staleHours;
  const recent = hoursInStage < 1;
  const returned = card.production_returned;
  const itemCount = card.item_count ?? 0;
  const show = (k: string) => fields.includes(k);

  return (
    <article
      ref={overlay ? undefined : setNodeRef}
      style={overlay ? undefined : {
        transform: CSS.Transform.toString(transform),
        transition,
      }}
      onClickCapture={(event) => {
        if (wasDraggedRef.current) {
          event.preventDefault();
          event.stopPropagation();
        }
      }}
      onClick={() => navigate({ to: "/fichas/$id", params: { id: card.ficha_id } })}
      onKeyDown={(event) => {
        if ((event.key === "Enter" || event.key === " ") && !isDragging) {
          event.preventDefault();
          navigate({ to: "/fichas/$id", params: { id: card.ficha_id } });
        }
      }}
      tabIndex={0}
      className={cn(
        "group relative min-w-0 rounded-xl border bg-card p-2.5 text-card-foreground shadow-card transition-all duration-150 max-[900px]:rounded-lg max-[900px]:p-2",
        "hover:-translate-y-px hover:shadow-md active:scale-[0.995] select-none max-[900px]:shadow-sm",
        draggable && "cursor-grab touch-manipulation active:cursor-grabbing",
        draggable && isDragging && "z-30",
        isDragging && "ring-2 ring-primary/50",
        isDragging && "opacity-40 shadow-lift",
        overlay && "rotate-1 shadow-lift",
        returned && "border-destructive/70 ring-1 ring-destructive/20",
        !returned && overdue && "border-warning/70",
        PRIORITY_CARD_CLS[card.priority] ?? PRIORITY_CARD_CLS.normal,
        isFinalStage && "border-success/50",
      )}
    >
      <span
        className={cn(
          "absolute inset-y-2 left-0 w-1 rounded-r max-[900px]:inset-y-1.5",
          PRIORITY_RAIL_CLS[card.priority] ?? PRIORITY_RAIL_CLS.normal,
        )}
      />

      <div className="flex items-start justify-between gap-1.5 max-[900px]:gap-1">
        <div className="flex min-w-0 items-center gap-1">
          {draggable && !overlay && (
            <button
              type="button"
              ref={setActivatorNodeRef}
              {...attributes}
              {...listeners}
              onClick={(event) => {
                event.preventDefault();
                event.stopPropagation();
              }}
              aria-label={dragHandleLabel}
              title={dragHandleLabel}
              className="grid size-8 shrink-0 touch-none select-none place-items-center rounded-md border bg-background/80 text-muted-foreground shadow-sm cursor-grab max-[900px]:size-7 active:cursor-grabbing"
            >
              <GripVertical className="size-3.5 max-[900px]:size-3" />
            </button>
          )}
          <div className="min-w-0">
            <Link
              to="/fichas/$id"
              params={{ id: card.ficha_id }}
              className="block truncate rounded-md px-0.5 py-0.5 font-mono text-sm font-semibold hover:text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              FICHA #{f.order_number || "—"}
            </Link>
            {(f.pdd_id || f.external_order_id) && (
              <p className="truncate px-0.5 font-mono text-[9px] font-semibold uppercase tracking-wide text-primary/80" title="Identificador da ficha no SMB">
                SMB/PDD #{f.pdd_id || f.external_order_id}
              </p>
            )}
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1.5 pt-0.5" aria-label="Indicadores">
          {recent && <Sparkles className="size-3 text-info max-[900px]:size-3" aria-label="Atualizada recentemente" />}
          {stale && <Clock className="size-3 text-warning max-[900px]:size-3" aria-label="Parada há muito tempo nesta etapa" />}
          {returned && <RotateCcw className="size-3 text-destructive max-[900px]:size-3" aria-label="Retorno por erro de produção" />}
          {overdue && <Clock className="size-3 text-warning max-[900px]:size-3" aria-label="Pedido atrasado" />}
          {isFinalStage && <CheckCircle2 className="size-3 text-success max-[900px]:size-3" aria-label="Finalizada" />}
          {card.priority === "urgente" && <Flame className="size-3 text-destructive max-[900px]:size-3" aria-label="Urgente" />}
          {card.sector_classification_pending && (
            <Star
              className="size-3 fill-warning/20 text-warning max-[900px]:size-3"
              aria-label="Setor sem classificação — revisão pendente"
              title="Setor sem classificação — revisar"
            />
          )}
          {f.duplicate_group_id && <Copy className="size-3 text-warning max-[900px]:size-3" aria-label="Pedido duplicado autorizado" />}
        </div>
      </div>

      {f.seller_name && (
        <p className="mt-0.5 truncate text-[10px] font-semibold uppercase tracking-wide text-muted-foreground max-[900px]:text-[9px]">
          Vendedor · {f.seller_name}
        </p>
      )}

      <div className="mt-1.5 rounded-lg border bg-muted/25 px-2 py-1.5 max-[900px]:mt-1 max-[900px]:px-1.5 max-[900px]:py-1">
        <div className="flex items-center justify-between gap-1.5">
          <span className="inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground max-[900px]:text-[9px]">
            <Package2 className="size-3 shrink-0" />
            Itens do pedido
          </span>
          {itemCount > 0 && (
            <span className="shrink-0 rounded-md bg-background px-1.5 py-0.5 text-[10px] font-semibold max-[900px]:text-[9px]">
              {itemCount} {itemCount === 1 ? "item" : "itens"}
            </span>
          )}
        </div>

        {show("product") && (
          <p className="mt-0.5 line-clamp-2 text-xs font-medium leading-4 text-foreground max-[900px]:text-[11px] max-[900px]:leading-[1.05rem]">
            {f.product_summary ?? "Ver detalhes da ficha"}
          </p>
        )}

        {itemCount === 1 && show("quantity") && f.quantity != null && (
          <p className="mt-0.5 text-[10px] text-muted-foreground max-[900px]:text-[9px]">
            Qtd. {f.quantity} {f.unit ?? ""}
          </p>
        )}
      </div>

      <div className="mt-1.5 grid grid-cols-2 gap-1.5 text-[10px] max-[900px]:mt-1 max-[900px]:gap-1">
        {show("delivery") && (
          <div className="min-w-0">
            <span className="text-muted-foreground">Prazo</span>
            <p className={cn("truncate font-medium", overdue && "text-destructive")}>{fmtDate(f.delivery_date)}</p>
          </div>
        )}

        {show("responsible") && (
          <div className="min-w-0">
            <span className="inline-flex items-center gap-1 text-muted-foreground max-[900px]:gap-0.5">
              <UserRound className="size-3 max-[900px]:size-2.5" />
              Responsável
            </span>
            <p className="truncate font-medium">{responsibleName ?? "Sem responsável"}</p>
          </div>
        )}

        {show("customer_code") && f.customer_code && (
          <div className="col-span-2 min-w-0">
            <span className="text-muted-foreground">Cód. cliente</span>
            <p className="truncate font-mono font-medium">{f.customer_code}</p>
          </div>
        )}
      </div>

      <div className="mt-1.5 flex min-h-5 flex-wrap gap-1 max-[900px]:mt-1 max-[900px]:min-h-4">
        {returned && (
          <span className="rounded-md border border-destructive/20 bg-destructive/10 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-destructive">
            Retorno
          </span>
        )}
        {overdue && (
          <span className="rounded-md border border-warning/20 bg-warning/15 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-warning-foreground">
            Atrasada
          </span>
        )}
        {f.duplicated_from_ficha_id && (
          <span className="rounded-md border border-primary/25 bg-primary/10 px-1.5 py-0.5 text-[10px] font-black uppercase tracking-wide text-primary">
            CÓPIA
          </span>
        )}
        {f.duplicate_group_id && !f.duplicated_from_ficha_id && (
          <span className="rounded-md border border-warning/20 bg-warning/10 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-warning-foreground">
            Grupo duplicado
          </span>
        )}
      </div>

      {(show("priority") || show("last_move")) && (
        <div className="mt-1.5 flex min-h-6 items-center justify-between gap-1.5 border-t pt-1.5 max-[900px]:mt-1 max-[900px]:min-h-5 max-[900px]:pt-1">
          {show("priority") ? (
            <span
              className={cn(
                "rounded-md border px-2 py-1 text-[10px] font-semibold uppercase tracking-wide",
                PRIORITY_CLS[card.priority],
              )}
            >
              {PRIORITY_LABEL[card.priority]}
            </span>
          ) : (
            <span />
          )}
          {show("last_move") && (
            <span className="truncate text-right text-[9px] text-muted-foreground max-[900px]:text-[8px]">
              {fmtDateTime(card.entered_stage_at)}
            </span>
          )}
        </div>
      )}
    </article>
  );
}
