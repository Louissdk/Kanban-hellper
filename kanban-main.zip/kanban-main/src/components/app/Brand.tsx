import { cn } from "@/lib/utils";

type BrandProps = {
  variant?: "full" | "icon";
  className?: string;
  surface?: boolean;
  priority?: boolean;
};

export function Brand({ variant = "full", className, surface = false, priority = false }: BrandProps) {
  const full = variant === "full";
  return (
    <span className={cn("inline-flex shrink-0 items-center justify-center", surface && "rounded-xl bg-white px-2 py-1.5 shadow-sm", className)}>
      <img
        src={full ? "/pediflow-logo.svg?v=2" : "/pediflow-icon.svg?v=2"}
        alt={full ? "PEDIFLOW — Sistema de Kanban de Pedidos" : "PEDIFLOW"}
        className={cn("block object-contain", full ? "h-10 w-auto max-w-[190px]" : "size-10")}
        {...(priority ? { fetchPriority: "high" } : {})}
      />
    </span>
  );
}
