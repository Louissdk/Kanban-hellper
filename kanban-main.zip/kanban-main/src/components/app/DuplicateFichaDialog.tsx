import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Copy, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { sectorsQuery, errMsg } from "@/lib/data";
import { SearchSelect } from "@/components/app/SearchSelect";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export function DuplicateFichaDialog({
  open,
  onOpenChange,
  fichaId,
  orderNumber,
  currentSectorId,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  fichaId: string;
  orderNumber: string;
  currentSectorId: string;
  onCreated?: (fichaId: string) => void;
}) {
  const qc = useQueryClient();
  const { data: sectors = [], isLoading } = useQuery(sectorsQuery);
  const [targetSectorId, setTargetSectorId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) setTargetSectorId(null);
  }, [open]);

  const options = [
    { value: currentSectorId, label: "Mesmo setor da ficha", hint: "A cópia permanece na etapa atual" },
    ...sectors
      .filter((sector) => sector.active && sector.id !== currentSectorId)
      .map((sector) => ({ value: sector.id, label: sector.name, hint: "A cópia será criada e transferida para a primeira etapa" })),
  ];

  async function duplicate() {
    if (!targetSectorId) return toast.error("Selecione onde a cópia deve começar.");
    setBusy(true);
    try {
      const { data, error } = await supabase.rpc("duplicate_ficha", {
        _ficha_id: fichaId,
        _target_sector_id: targetSectorId === currentSectorId ? null : targetSectorId,
      });
      if (error) throw new Error(error.message);
      const newId = typeof data === "string" ? data : null;
      if (!newId) throw new Error("A cópia foi criada sem retornar a nova ficha.");
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["board"] }),
        qc.invalidateQueries({ queryKey: ["ficha", fichaId] }),
        qc.invalidateQueries({ queryKey: ["ficha-duplicates"] }),
      ]);
      toast.success("Cópia criada. Ela está identificada como CÓPIA.");
      onOpenChange(false);
      onCreated?.(newId);
    } catch (error) {
      toast.error(errMsg(error));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(next) => !busy && onOpenChange(next)}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Copy className="size-4 text-primary" />
            <DialogTitle>Duplicar ficha #{orderNumber}</DialogTitle>
          </div>
          <DialogDescription>
            O pedido original permanece intacto. A nova ficha será criada como cópia, sem duplicar o identificador PDD do SMB.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2">
          <p className="text-sm font-semibold">Setor inicial da cópia</p>
          <SearchSelect
            options={options}
            value={targetSectorId}
            onChange={setTargetSectorId}
            placeholder={isLoading ? "Carregando setores..." : "Selecione o setor"}
            disabled={isLoading || busy}
          />
          <p className="text-xs text-muted-foreground">
            A cópia usa a regra central de movimentação existente. Quando outro setor for escolhido, a transferência fica registrada no histórico.
          </p>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>Cancelar</Button>
          <Button onClick={() => void duplicate()} disabled={busy || isLoading || !targetSectorId}>
            {busy && <Loader2 className="size-4 animate-spin" />}
            Criar CÓPIA
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
