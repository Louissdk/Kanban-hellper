import { useQuery } from "@tanstack/react-query";
import { CheckCircle2, Copy, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { fmtDateTime, maskCustomerName } from "@/lib/data";
import { useAuth } from "@/lib/auth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type DuplicateRecord = {
  id: string;
  order_number: string;
  customer: string;
  source_system: string;
  duplicate_group_id: string | null;
  created_at: string;
};

export function DuplicateResolutionDialog({
  open,
  onOpenChange,
  duplicateGroupId,
  currentFichaId,
  onRequestDelete,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  duplicateGroupId: string | null;
  currentFichaId: string;
  onRequestDelete: (fichaId: string, orderNumber: string) => void;
}) {
  const { isAdmin } = useAuth();

  const { data: duplicates = [], isLoading } = useQuery({
    queryKey: ["ficha-duplicates", duplicateGroupId],
    enabled: open && !!duplicateGroupId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("fichas")
        .select("id,order_number,customer,source_system,duplicate_group_id,created_at")
        .eq("duplicate_group_id", duplicateGroupId!)
        .order("created_at");
      if (error) throw new Error(error.message);
      return (data ?? []) as DuplicateRecord[];
    },
  });

  function keepBoth() {
    onOpenChange(false);
    toast.success("As fichas duplicadas foram mantidas. Elas continuarão visíveis no Kanban.");
  }
  const canResolve = isAdmin && duplicates.length >= 2;
  const twoRecords = duplicates.length === 2;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Copy className="size-4 text-warning" />
            <DialogTitle>Duplicidade detectada</DialogTitle>
          </div>
          <DialogDescription>
            Este grupo contém {duplicates.length || "mais de uma"} fichas do mesmo pedido. Ambas aparecem no Kanban.
            {isAdmin
              ? " A administração pode manter uma ficha e excluir a outra ou manter as duas."
              : " Somente a administração pode resolver a duplicidade."}
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="rounded-lg border p-4 text-sm text-muted-foreground">Carregando fichas duplicadas...</div>
        ) : duplicates.length < 2 ? (
          <div className="rounded-lg border bg-muted/20 p-4 text-sm text-muted-foreground">
            A duplicidade já foi resolvida ou não está mais disponível.
          </div>
        ) : (
          <div className="space-y-3">
            {duplicates.map((record) => (
              <div key={record.id} className="rounded-xl border bg-muted/10 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-mono font-semibold">FICHA #{record.order_number}</p>
                      {record.id === currentFichaId && <Badge variant="secondary">Ficha atual</Badge>}
                    </div>
                    <p className="mt-1 text-sm font-medium">{maskCustomerName(record.customer, isAdmin)}</p>
                    <p className="text-xs text-muted-foreground">
                      {record.source_system === "SMB" ? "Origem SMB" : "Origem manual"} · criada em {fmtDateTime(record.created_at)}
                    </p>
                  </div>
                  {record.duplicate_group_id && (
                    <Badge variant="outline" className="border-warning/30 text-warning-foreground">
                      Duplicado
                    </Badge>
                  )}
                </div>

                {canResolve && (
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    className="mt-3"
                    onClick={() => {
                      onOpenChange(false);
                      onRequestDelete(record.id, record.order_number);
                    }}
                  >
                    <Trash2 className="size-4" />
                    {twoRecords ? "Manter a outra e excluir esta" : "Excluir esta ficha"}
                  </Button>
                )}
              </div>
            ))}

            {canResolve && (
              <div className="rounded-lg border border-success/30 bg-success/5 p-3 text-sm">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 size-4 text-success" />
                  <div>
                    <p className="font-semibold">Manter as duas</p>
                    <p className="text-muted-foreground">
                      A duplicidade ficará registrada como autorizada pela administração e as fichas continuarão separadas.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Fechar</Button>
          {canResolve && <Button variant="secondary" onClick={keepBoth}>Manter as duas</Button>}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
