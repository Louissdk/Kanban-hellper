import { useDroppable } from "@dnd-kit/core";
import { ArrowDownAZ, ArrowUpAZ, ListOrdered, MoveDown } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import type { Stage } from "@/lib/data";

export function KanbanColumn({ stage, count, children, headerAction, sortMode = "recent", onSortToggle }: { stage: Stage; count: number; children: ReactNode; headerAction?: ReactNode; sortMode?: "recent" | "old" | "manual"; onSortToggle?: () => void }) {
  const { setNodeRef, isOver } = useDroppable({
    id: stage.id,
    data: {
      type: "stage",
      stageId: stage.id,
    },
  });
  const displayStageName = stage.is_final ? "Finalizados" : stage.name;

  return (
    <section
      ref={setNodeRef}
      aria-label={displayStageName}
      className={cn(
        "flex min-h-[calc(100dvh-170px)] w-[clamp(248px,28vw,336px)] max-w-[336px] shrink-0 self-start flex-col rounded-2xl border bg-column shadow-card transition-colors max-[900px]:min-h-[calc(100dvh-152px)] max-[900px]:w-[clamp(240px,76vw,304px)] max-[900px]:rounded-xl",
        isOver && "border-primary bg-accent shadow-lift",
      )}
    >
      <header className="sticky top-0 z-10 flex min-h-10 items-center gap-1.5 rounded-t-2xl border-b bg-column/95 px-2.5 py-2 backdrop-blur max-[900px]:min-h-9 max-[900px]:gap-1 max-[900px]:px-2 max-[900px]:py-1.5">
        <span className="font-mono text-[10px] font-semibold tracking-wide text-muted-foreground max-[900px]:text-[9px]">{String(stage.position).padStart(2, "0")}</span>
        <button
          type="button"
          onClick={onSortToggle}
          disabled={!onSortToggle}
          title={sortMode === "recent" ? "Pedidos recentes primeiro" : sortMode === "old" ? "Pedidos antigos primeiro" : "Ordem manual dos cards"}
          aria-label={sortMode === "recent" ? "Pedidos recentes primeiro" : sortMode === "old" ? "Pedidos antigos primeiro" : "Ordem manual dos cards"}
          className="min-w-0 flex-1 truncate text-left text-[13px] font-semibold hover:text-primary disabled:cursor-default disabled:hover:text-inherit max-[900px]:text-xs"
        >
          {stage.name}
        </button>
        {onSortToggle && (
          <button
            type="button"
            onClick={onSortToggle}
            aria-pressed={sortMode === "old"}
            aria-label={sortMode === "recent" ? "Alterar para pedidos antigos primeiro" : sortMode === "old" ? "Usar ordem manual dos cards" : "Alterar para pedidos recentes primeiro"}
            className="grid size-7 shrink-0 place-items-center rounded-md text-muted-foreground hover:bg-accent hover:text-foreground max-[900px]:size-6"
          >
            {sortMode === "recent" ? <ArrowDownAZ className="size-3.5 max-[900px]:size-3" /> : sortMode === "old" ? <ArrowUpAZ className="size-3.5 max-[900px]:size-3" /> : <ListOrdered className="size-3.5 max-[900px]:size-3" />}
          </button>
        )}
        {headerAction}
        <span className={cn("grid min-w-6 place-items-center rounded-full px-1.5 py-0.5 text-[11px] font-semibold max-[900px]:min-w-5 max-[900px]:text-[10px]", stage.is_final ? "bg-success text-success-foreground" : "bg-secondary text-secondary-foreground")}>
          {count}
        </span>
      </header>
      <div className={cn(
        "relative flex min-h-20 flex-col gap-2 p-2 transition-colors max-[900px]:gap-1.5 max-[900px]:p-1.5",
        isOver && "bg-primary/[0.035]",
      )}>
        {isOver && (
          <div className="pointer-events-none sticky top-1 z-20 -mb-1 flex items-center justify-center">
            <div className="flex items-center gap-1.5 rounded-xl border border-primary/40 bg-primary px-3 py-1.5 text-[11px] font-bold text-primary-foreground shadow-lg">
              <MoveDown className="size-3.5" /> SOLTE AQUI
            </div>
          </div>
        )}
        {children}
      </div>
    </section>
  );
}
