import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useState, type ReactNode } from "react";
import { FlaskConical, LayoutDashboard, KanbanSquare, Settings, Moon, Sun, LogOut, ShieldAlert, Tv, ClipboardList } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, ROLE_LABEL } from "@/lib/auth";
import { toast } from "sonner";
import { Brand } from "@/components/app/Brand";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const NAV = [
  { to: "/quadro", label: "Quadro", fullLabel: "Quadro de Produção", icon: KanbanSquare },
  { to: "/dashboard", label: "Dashboard", fullLabel: "Dashboard", icon: LayoutDashboard },
  { to: "/modo-tv", label: "TV", fullLabel: "Modo TV", icon: Tv },
  { to: "/mudancas-administrativas", label: "Mudanças", fullLabel: "Mudanças Administrativas", icon: ClipboardList },
] as const;

const SETTINGS = [
  { to: "/configuracoes/setores", label: "Setores e Etapas", admin: true },
  { to: "/configuracoes/usuarios", label: "Usuários", admin: true },
  { to: "/configuracoes/integracao", label: "Integração SMB", admin: false },
  { to: "/configuracoes/sistema", label: "Sistema e Cartões", admin: true },
  { to: "/modo-tv/configuracao", label: "Programação do Modo TV", admin: true },
] as const;

function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => setDark(document.documentElement.classList.contains("dark")), []);
  function toggle() {
    const next = !dark;
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("theme", next ? "dark" : "light");
    setDark(next);
  }
  return (
    <Button variant="ghost" size="icon" onClick={toggle} aria-label={dark ? "Ativar tema claro" : "Ativar tema escuro"} className="text-chrome-foreground hover:bg-sidebar-accent hover:text-chrome-foreground">
      {dark ? <Sun className="size-4" /> : <Moon className="size-4" />}
    </Button>
  );
}

function SettingsMenu({ isAdmin, compact = false }: { isAdmin: boolean; compact?: boolean }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size={compact ? "icon" : "default"} aria-label="Abrir configurações" className={compact ? "text-chrome-foreground hover:bg-sidebar-accent hover:text-chrome-foreground" : "text-chrome-muted hover:bg-sidebar-accent hover:text-chrome-foreground"}>
          <Settings className="size-4" />
          {!compact && <span>Configurações</span>}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align={compact ? "end" : "start"} className="min-w-52">
        {SETTINGS.filter((s) => !s.admin || isAdmin).map((s) => (
          <DropdownMenuItem key={s.to} asChild>
            <Link to={s.to}>{s.label}</Link>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { fullName, roles, isAdmin, isTestMode, testModeActive } = useAuth();
  const actualIsAdmin = roles.includes("admin");
  const qc = useQueryClient();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  async function toggleTestMode() {
    if (!isTestMode && !actualIsAdmin) {
      toast.error("Somente um administrador real pode iniciar o Modo Teste.");
      return;
    }
    const message = isTestMode
      ? "As alterações feitas durante o teste serão descartadas e o sistema voltará ao estado anterior."
      : "O sistema entrará em Modo Teste. As alterações operacionais serão revertidas ao desativar.";
    if (!window.confirm(message + "\n\nContinuar?")) return;

    const { error } = await supabase.rpc(isTestMode ? "deactivate_test_mode" : "activate_test_mode");
    if (error) {
      toast.error(error.message);
      return;
    }

    await qc.invalidateQueries();
    toast.success(isTestMode ? "Modo Teste desativado. Estado anterior restaurado." : "Modo Teste ativado. Você pode testar o sistema.");
  }

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  if (pathname === "/modo-tv") {
    return <main className="min-h-screen bg-background">{children}</main>;
  }

  const linkCls =
    "flex min-h-10 items-center gap-2 rounded-lg px-3 text-sm font-medium text-chrome-muted transition-colors hover:bg-sidebar-accent hover:text-chrome-foreground";

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-40 bg-chrome text-chrome-foreground shadow-sm">
        <div className="flex min-h-14 items-center gap-2 px-3 sm:px-4">
          <Link to="/quadro" aria-label="PEDIFLOW — ir para o quadro" className="flex min-w-0 shrink-0 items-center gap-2 rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-chrome">
            <Brand variant="icon" className="h-9 w-9" priority />
            <span className="hidden lg:inline font-display text-base font-extrabold tracking-tight text-white">PEDIFLOW</span>
          </Link>

          <nav className="hidden items-center gap-1 md:flex" aria-label="Principal">
            {NAV.map((n) => (
              <Link key={n.to} to={n.to} className={linkCls} activeProps={{ className: "bg-sidebar-accent text-chrome-foreground" }}>
                <n.icon className="size-4" />
                <span>{n.fullLabel}</span>
              </Link>
            ))}
            <SettingsMenu isAdmin={isAdmin} />
          </nav>

          <div className="ml-auto flex items-center gap-1">
            <ThemeToggle />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="h-10 gap-2 px-2 text-chrome-foreground hover:bg-sidebar-accent hover:text-chrome-foreground" aria-label="Abrir menu do usuário">
                  <span className="grid size-8 place-items-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                    {(fullName || "?").slice(0, 1).toUpperCase()}
                  </span>
                  <span className="hidden max-w-40 text-left text-xs leading-tight lg:block">
                    <span className="block truncate font-medium">{fullName}</span>
                    <span className="block truncate text-chrome-muted">{roles.map((r) => ROLE_LABEL[r]).join(", ") || "—"}</span>
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="min-w-52">
                <DropdownMenuLabel className="max-w-52 truncate">{fullName}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {(actualIsAdmin || testModeActive) ? (
                  <DropdownMenuItem
                    disabled={testModeActive && !isTestMode && !actualIsAdmin}
                    onClick={() => void toggleTestMode()}
                    className={isTestMode ? "text-warning-foreground" : undefined}
                  >
                    {isTestMode ? <ShieldAlert className="size-4" /> : <FlaskConical className="size-4" />}
                    {isTestMode ? "Desativar Modo Teste" : "Modo Teste em uso"}
                  </DropdownMenuItem>
                ) : null}
                <DropdownMenuItem onClick={signOut}>
                  <LogOut className="size-4" /> Sair
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <span className="md:hidden"><SettingsMenu isAdmin={isAdmin} compact /></span>
          </div>
        </div>
        <div className="hazard-stripe h-1 opacity-80" />
      </header>

      {testModeActive && (
        <div className="sticky top-14 z-30 border-b border-warning/40 bg-warning/15 px-4 py-2.5 text-center text-xs font-semibold text-warning-foreground shadow-sm">
          MODO TESTE ATIVO — alterações operacionais serão restauradas quando o modo for desativado. Sincronização SMB bloqueada.
          {!isTestMode && " Outro usuário iniciou o teste. As permissões temporárias não estão disponíveis para você."}
        </div>
      )}
      <main className="flex min-h-0 flex-1 flex-col pb-16 md:pb-0">{children}</main>

      <nav className="mobile-bottom-nav fixed inset-x-0 bottom-0 z-50 border-t bg-chrome/95 text-chrome-foreground backdrop-blur-md" aria-label="Navegação mobile">
        <div className="mx-auto grid max-w-lg grid-cols-4 safe-area-bottom">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="flex min-h-14 flex-col items-center justify-center gap-0.5 px-2 text-[11px] font-medium text-chrome-muted transition-colors"
              activeProps={{ className: "flex min-h-14 flex-col items-center justify-center gap-0.5 px-2 text-[11px] font-semibold text-chrome-foreground" }}
            >
              <n.icon className="size-5" />
              <span>{n.label}</span>
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: ReactNode }) {
  return (
    <div className="border-b bg-card">
      <div className="mx-auto flex w-full max-w-[1600px] flex-col gap-3 px-4 py-4 sm:px-5 md:flex-row md:items-end md:justify-between md:gap-6 md:px-6 md:py-5">
        <div className="min-w-0">
          <h1 className="truncate text-xl font-bold sm:text-2xl">{title}</h1>
          {description && <p className="mt-1 max-w-3xl text-sm leading-5 text-muted-foreground">{description}</p>}
        </div>
        {actions && <div className="flex w-full flex-wrap items-center gap-2 md:w-auto md:justify-end">{actions}</div>}
      </div>
    </div>
  );
}
