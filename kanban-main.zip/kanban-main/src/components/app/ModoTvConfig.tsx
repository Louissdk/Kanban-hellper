import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { CalendarDays, Check, Search, Star, Trash2, Truck, UsersRound } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { sectorsQuery, type Priority } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

const SHIPPING = ["Correio", "Transportadora", "Retirada", "Motoboy", "Não definido"] as const;
type ShippingMethod = (typeof SHIPPING)[number];

type TvOrder = {
  ficha_id: string;
  display_date: string;
  is_priority: boolean;
  shipping_method: string;
  sort_order: number;
  notes: string | null;
};

type Candidate = {
  ficha_id: string;
  sector_id: string;
  stage_id: string;
  updated_at: string;
  priority: Priority;
  stage_name: string;
  sector_name: string;
  order_number: string;
  pdd_id: string | null;
  external_order_id: string | null;
  customer: string;
  seller_name: string | null;
  delivery_date: string | null;
};

function today() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

function addDays(value: string, amount: number) {
  const parts = value.split("-").map(Number);
  const d = new Date(parts[0], parts[1] - 1, parts[2]);
  d.setDate(d.getDate() + amount);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

function dayLabel(value: string) {
  const parts = value.split("-").map(Number);
  return new Intl.DateTimeFormat("pt-BR", { weekday: "short", day: "2-digit", month: "2-digit" })
    .format(new Date(parts[0], parts[1] - 1, parts[2]))
    .replace(".", "");
}

function fullDate(value: string) {
  const parts = value.split("-").map(Number);
  return new Intl.DateTimeFormat("pt-BR", { weekday: "long", day: "2-digit", month: "long" })
    .format(new Date(parts[0], parts[1] - 1, parts[2]));
}

export function ModoTvConfigPage({ initialFichaId, initialDate }: { initialFichaId?: string; initialDate?: string }) {
  const { isAdmin, userId } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [selectedDate, setSelectedDate] = useState(() => initialDate || today());
  const [customDate, setCustomDate] = useState(today());
  const [search, setSearch] = useState("");
  const [selectedSectorIds, setSelectedSectorIds] = useState<string[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [priorityDraft, setPriorityDraft] = useState<Record<string, boolean>>({});
  const [shippingDraft, setShippingDraft] = useState<Record<string, ShippingMethod>>({});
  const [bulkShipping, setBulkShipping] = useState<"no-change" | ShippingMethod>("no-change");

  const dates = useMemo(() => [0, 1, 2, 3].map((n) => addDays(today(), n)), []);

  const sectors = useQuery(sectorsQuery);

  const tvQuery = useQuery({
    queryKey: ["modo-tv-config-orders"],
    queryFn: async () => {
      const { data, error } = await supabase.from("tv_orders").select("ficha_id,display_date,is_priority,shipping_method,sort_order,notes").order("display_date").order("is_priority", { ascending: false }).order("sort_order");
      if (error) throw new Error(error.message);
      return (data ?? []) as TvOrder[];
    },
    enabled: isAdmin,
    refetchInterval: 5000,
  });

  const candidatesQuery = useQuery({
    queryKey: ["modo-tv-config-candidates"],
    queryFn: async () => {
      const { data, error } = await supabase.from("kanban_assignments").select("ficha_id,sector_id,stage_id,updated_at,priority,fichas!inner(order_number,pdd_id,external_order_id,customer,seller_name,delivery_date),stages!inner(name,is_final),sectors!inner(name,active)");
      if (error) throw new Error(error.message);

      return ((data ?? []) as unknown as Array<{
        ficha_id: string;
        sector_id: string;
        stage_id: string;
        updated_at: string;
        priority: Priority;
        fichas: { order_number: string; pdd_id: string | null; external_order_id: string | null; customer: string; seller_name: string | null; delivery_date: string | null };
        stages: { name: string; is_final: boolean };
        sectors: { name: string; active: boolean };
      }>)
        .filter((r) => r.sectors.active)
        .filter((r) => r.stages.name.trim().toLowerCase() !== "expedição" && !r.stages.is_final)
        .map((r) => ({
          ficha_id: r.ficha_id,
          sector_id: r.sector_id,
          stage_id: r.stage_id,
          updated_at: r.updated_at,
          priority: r.priority,
          stage_name: r.stages.name,
          sector_name: r.sectors.name,
          order_number: r.fichas.order_number,
          pdd_id: r.fichas.pdd_id,
          external_order_id: r.fichas.external_order_id,
          customer: r.fichas.customer,
          seller_name: r.fichas.seller_name,
          delivery_date: r.fichas.delivery_date,
        })) as Candidate[];
    },
    enabled: isAdmin,
    refetchInterval: 5000,
  });

  useEffect(() => {
    if (!initialFichaId || !isAdmin || !candidatesQuery.data) return;
    if (initialDate) setSelectedDate(initialDate);
    setSelected((current) => current.includes(initialFichaId) ? current : [...current, initialFichaId]);
  }, [initialFichaId, initialDate, isAdmin, candidatesQuery.data]);

  const orders = tvQuery.data ?? [];
  const candidates = candidatesQuery.data ?? [];
  const sectorList = sectors.data ?? [];
  const orderMap = useMemo(() => new Map(orders.map((o) => [o.ficha_id, o])), [orders]);
  const selectedDateOrders = useMemo(
    () => orders.filter((o) => o.display_date === selectedDate).sort((a, b) => Number(b.is_priority) - Number(a.is_priority) || a.sort_order - b.sort_order),
    [orders, selectedDate],
  );

  const visible = useMemo(() => {
    const q = search.trim().toLocaleLowerCase("pt-BR");
    return candidates
      .filter((c) => selectedSectorIds.length === 0 || selectedSectorIds.includes(c.sector_id))
      .filter((c) => !q || [c.order_number, c.pdd_id ?? "", c.external_order_id ?? "", c.customer, c.seller_name ?? "", c.stage_name, c.sector_name].join(" ").toLocaleLowerCase("pt-BR").includes(q))
      .sort((a, b) => {
        const aScheduled = orderMap.get(a.ficha_id);
        const bScheduled = orderMap.get(b.ficha_id);
        return Number(!!bScheduled) - Number(!!aScheduled) || Number(!!bScheduled?.is_priority) - Number(!!aScheduled?.is_priority) || a.order_number.localeCompare(b.order_number, "pt-BR", { numeric: true });
      })
      .slice(0, 300);
  }, [candidates, selectedSectorIds, search, orderMap]);

  function draftPriority(id: string) {
    return priorityDraft[id] ?? orderMap.get(id)?.is_priority ?? false;
  }

  function draftShipping(id: string): ShippingMethod {
    const saved = orderMap.get(id)?.shipping_method;
    return shippingDraft[id] ?? (SHIPPING.includes(saved as ShippingMethod) ? (saved as ShippingMethod) : "Não definido");
  }

  function toggleSector(id: string) {
    setSelectedSectorIds((old) => old.includes(id) ? old.filter((item) => item !== id) : [...old, id]);
  }

  function toggleSelected(id: string, value: boolean) {
    setSelected((old) => value ? (old.includes(id) ? old : [...old, id]) : old.filter((item) => item !== id));
  }

  function togglePriority(id: string) {
    setPriorityDraft((old) => ({ ...old, [id]: !draftPriority(id) }));
  }

  function changeShipping(id: string, value: ShippingMethod) {
    setShippingDraft((old) => ({ ...old, [id]: value }));
  }

  function applyBulkShipping(value: "no-change" | ShippingMethod) {
    setBulkShipping(value);
    if (value === "no-change") return;
    setShippingDraft((old) => {
      const next = { ...old };
      for (const id of selected) next[id] = value;
      return next;
    });
  }

  async function scheduleSelected() {
    if (!isAdmin || !userId || selected.length === 0) return;
    const maxOrder = Math.max(-1, ...selectedDateOrders.map((o) => o.sort_order));

    const rows = selected.map((ficha_id, index) => ({
      ficha_id,
      display_date: selectedDate,
      is_priority: draftPriority(ficha_id),
      shipping_method: draftShipping(ficha_id),
      sort_order: maxOrder + index + 1,
      created_by: userId,
      notes: "Programado pela administração",
    }));

    const { error } = await supabase.from("tv_orders").upsert(rows, { onConflict: "ficha_id" });
    if (error) return toast.error(error.message);

    setSelected([]);
    setBulkShipping("no-change");
    await qc.invalidateQueries({ queryKey: ["modo-tv-config-orders"] });
    toast.success(rows.length + " ficha(s) programada(s) para " + fullDate(selectedDate) + ".");
  }

  async function updateScheduled(id: string, patch: Partial<TvOrder>) {
    if (!isAdmin) return;
    const { error } = await supabase.from("tv_orders").update(patch).eq("ficha_id", id);
    if (error) return toast.error(error.message);
    await qc.invalidateQueries({ queryKey: ["modo-tv-config-orders"] });
  }

  async function removeScheduled(id: string) {
    if (!isAdmin) return;
    const { error } = await supabase.from("tv_orders").delete().eq("ficha_id", id);
    if (error) return toast.error(error.message);
    await qc.invalidateQueries({ queryKey: ["modo-tv-config-orders"] });
    toast.success("Ficha removida da programação.");
  }

  if (!isAdmin) {
    return (
      <div className="grid min-h-[calc(100vh-7rem)] place-items-center p-6">
        <Card className="max-w-md">
          <CardHeader><h1 className="text-xl font-bold">Acesso restrito</h1></CardHeader>
          <CardContent><p className="text-sm text-muted-foreground">A programação do Modo TV pode ser alterada somente pela administração.</p></CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-full bg-background">
      <div className="border-b bg-card">
        <div className="mx-auto max-w-[1800px] px-4 py-4 sm:px-5 md:px-7">
          <div className="flex flex-wrap items-center gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">ADMINISTRAÇÃO</p>
              <h1 className="text-2xl font-bold">Programação do Modo TV</h1>
              <p className="mt-1 text-sm text-muted-foreground">Escolha setores, selecione várias fichas e defina a saída, prioridade e transporte.</p>
            </div>
            <Button className="ml-auto" variant="outline" onClick={() => navigate({ to: "/modo-tv" })}>Abrir tela da TV</Button>
          </div>

          <div className="mt-5 grid gap-4 xl:grid-cols-[minmax(0,1fr)_auto]">
            <div className="space-y-2">
              <Label className="flex items-center gap-2"><UsersRound className="size-4" /> Partes da fábrica</Label>
              <div className="flex flex-wrap gap-2">
                <Button type="button" size="sm" variant={selectedSectorIds.length === 0 ? "default" : "outline"} onClick={() => setSelectedSectorIds([])}>Todos os setores</Button>
                {sectorList.map((sector) => (
                  <label key={sector.id} className="flex cursor-pointer items-center gap-2 rounded-xl border bg-background px-3 py-2 text-sm">
                    <Checkbox checked={selectedSectorIds.includes(sector.id)} onCheckedChange={() => toggleSector(sector.id)} />
                    <span>{sector.name}</span>
                  </label>
                ))}
              </div>
              {sectorList.length <= 1 && <p className="text-xs text-muted-foreground">Os demais setores aparecerão automaticamente quando forem cadastrados e ativados em Configurações → Setores e Etapas.</p>}
            </div>

            <div className="flex flex-col gap-2 xl:min-w-72">
              <Label className="flex items-center gap-2"><CalendarDays className="size-4" /> Dia da saída</Label>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 xl:grid-cols-2">
                {dates.map((d, i) => (
                  <Button key={d} variant={selectedDate === d ? "default" : "outline"} className="h-12 flex-col" onClick={() => { setSelectedDate(d); setCustomDate(d); }}>
                    <span>{dayLabel(d)}</span>
                    <span className="text-[10px]">{i === 0 ? "Hoje" : i === 1 ? "Amanhã" : "+" + i + " dias"}</span>
                  </Button>
                ))}
              </div>
              <Input type="date" value={customDate} onChange={(e) => { setCustomDate(e.target.value); setSelectedDate(e.target.value); }} />
            </div>
          </div>
        </div>
      </div>

      <main className="mx-auto grid max-w-[1800px] gap-5 p-4 sm:p-5 md:p-7">
        <Card>
          <CardHeader className="gap-4">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">Fila programada</p>
                <h2 className="text-xl font-bold capitalize">{fullDate(selectedDate)}</h2>
              </div>
              <Badge variant="outline">{selectedDateOrders.length} programado(s)</Badge>
            </div>

            <div className="rounded-xl border bg-muted/20 p-3">
              {selectedDateOrders.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nenhuma ficha programada para este dia.</p>
              ) : (
                <div className="space-y-2">
                  {selectedDateOrders.map((order, index) => {
                    const candidate = candidates.find((c) => c.ficha_id === order.ficha_id);
                    return (
                      <div key={order.ficha_id} className="grid gap-3 rounded-xl border bg-card p-3 md:grid-cols-[auto_minmax(0,1fr)_170px_150px_auto_auto] md:items-center">
                        <span className="grid size-8 place-items-center rounded-full bg-muted text-xs font-bold">{index + 1}</span>
                        <button type="button" className="min-w-0 text-left" onClick={() => navigate({ to: "/fichas/$id", params: { id: order.ficha_id } })}>
                          <span className="block font-mono font-bold">FICHA #{candidate?.order_number ?? order.ficha_id.slice(0, 8)}</span>
                          {(candidate?.pdd_id || candidate?.external_order_id) && (
                            <span className="block font-mono text-[10px] font-bold uppercase tracking-wide text-primary">
                              SMB/PDD #{candidate.pdd_id || candidate.external_order_id}
                            </span>
                          )}
                          <span className="block truncate text-sm font-semibold">{candidate?.customer ?? "Ficha em atualização"}</span>
                          <span className="block truncate text-xs text-muted-foreground">{candidate?.sector_name ?? "Setor não disponível"} · {candidate?.stage_name ?? "Etapa não disponível"}</span>
                        </button>
                        <select value={order.display_date} onChange={(e) => void updateScheduled(order.ficha_id, { display_date: e.target.value })} className="h-9 rounded-md border bg-background px-2 text-sm">
                          {dates.map((d) => <option key={d} value={d}>{dayLabel(d)}</option>)}
                          <option value={order.display_date}>{fullDate(order.display_date)}</option>
                        </select>
                        <select value={SHIPPING.includes(order.shipping_method as ShippingMethod) ? order.shipping_method : "Não definido"} onChange={(e) => void updateScheduled(order.ficha_id, { shipping_method: e.target.value })} className="h-9 rounded-md border bg-background px-2 text-sm" aria-label="Transporte">
                          {SHIPPING.map((method) => <option key={method} value={method}>{method}</option>)}
                        </select>
                        <Button size="sm" variant={order.is_priority ? "default" : "outline"} onClick={() => void updateScheduled(order.ficha_id, { is_priority: !order.is_priority })}>
                          <Star className={order.is_priority ? "size-4 fill-current" : "size-4"} />
                          {order.is_priority ? "Prioridade" : "Priorizar"}
                        </Button>
                        <Button size="icon" variant="destructive" onClick={() => void removeScheduled(order.ficha_id)} aria-label="Remover da programação"><Trash2 className="size-4" /></Button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </CardHeader>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">Adicionar fichas</p>
                <h2 className="text-xl font-bold">Selecionar em lista</h2>
              </div>
              <div className="relative w-full sm:w-96">
                <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Pesquisar por ficha, SMB/PDD, código, cliente, setor ou etapa" className="pl-9" />
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            <div className="flex flex-wrap items-center gap-2 rounded-xl border bg-muted/20 p-3">
              <span className="text-sm font-semibold">{selected.length} selecionada(s)</span>
              <Button type="button" size="sm" variant="outline" disabled={!selected.length} onClick={() => setSelected([])}>Limpar seleção</Button>
              <div className="ml-auto flex flex-wrap items-center gap-2">
                <Label className="text-xs text-muted-foreground">Transporte em massa</Label>
                <select value={bulkShipping} onChange={(e) => applyBulkShipping(e.target.value as "no-change" | ShippingMethod)} disabled={!selected.length} className="h-9 rounded-md border bg-background px-2 text-sm">
                  <option value="no-change">Não alterar</option>
                  {SHIPPING.map((method) => <option key={method} value={method}>{method}</option>)}
                </select>
                <Button disabled={!selected.length} onClick={() => void scheduleSelected()}>
                  <Check className="size-4" />
                  Programar {selected.length ? selected.length + " selecionada(s)" : "selecionados"} em {dayLabel(selectedDate)}
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              {visible.map((candidate) => {
                const scheduled = orderMap.get(candidate.ficha_id);
                const checked = selected.includes(candidate.ficha_id);
                const isPriority = draftPriority(candidate.ficha_id);
                return (
                  <div key={candidate.ficha_id} className={checked ? "grid gap-3 rounded-xl border-2 border-primary bg-primary/5 p-3 lg:grid-cols-[auto_minmax(0,1fr)_120px_190px_auto]" : "grid gap-3 rounded-xl border bg-card p-3 lg:grid-cols-[auto_minmax(0,1fr)_120px_190px_auto]"}>
                    <Checkbox checked={checked} onCheckedChange={(v) => toggleSelected(candidate.ficha_id, !!v)} className="mt-1" />
                    <button type="button" className="min-w-0 text-left" onClick={() => navigate({ to: "/fichas/$id", params: { id: candidate.ficha_id } })}>
                      <span className="flex flex-wrap items-center gap-2">
                        <span className="font-mono font-bold">FICHA #{candidate.order_number}</span>
                        {(candidate.pdd_id || candidate.external_order_id) && (
                          <Badge variant="secondary" className="font-mono text-[10px]">SMB #{candidate.pdd_id || candidate.external_order_id}</Badge>
                        )}
                        {scheduled && <Badge variant="outline">Programado: {dayLabel(scheduled.display_date)}</Badge>}
                      </span>
                      <span className="mt-1 block truncate font-semibold">{candidate.customer}</span>
                      <span className="block truncate text-xs text-muted-foreground">{candidate.sector_name} · {candidate.stage_name} · {candidate.seller_name ?? "Sem vendedor"}</span>
                    </button>
                    <div className="rounded-lg bg-muted/40 p-2 text-xs">
                      <span className="block uppercase tracking-wide text-muted-foreground">Prazo</span>
                      <span className="font-semibold">{candidate.delivery_date ? new Date(candidate.delivery_date + "T12:00:00").toLocaleDateString("pt-BR") : "—"}</span>
                    </div>
                    <select value={draftShipping(candidate.ficha_id)} onChange={(e) => changeShipping(candidate.ficha_id, e.target.value as ShippingMethod)} className="h-10 rounded-md border bg-background px-2 text-sm" aria-label={"Transporte da ficha " + candidate.order_number}>
                      {SHIPPING.map((method) => <option key={method} value={method}>{method}</option>)}
                    </select>
                    <Button type="button" variant={isPriority ? "default" : "outline"} size="icon" className="h-10 w-10 justify-self-start" onClick={() => togglePriority(candidate.ficha_id)} aria-label={isPriority ? "Remover prioridade da ficha " + candidate.order_number : "Marcar ficha " + candidate.order_number + " como prioridade"}>
                      <Star className={isPriority ? "size-4 fill-current" : "size-4"} />
                    </Button>
                  </div>
                );
              })}

              {visible.length === 0 && (
                <div className="grid min-h-40 place-items-center rounded-xl border border-dashed bg-muted/20 p-6 text-center">
                  <div>
                    <Truck className="mx-auto size-8 text-muted-foreground" />
                    <p className="mt-2 font-semibold">Nenhuma ficha encontrada</p>
                    <p className="mt-1 text-sm text-muted-foreground">Ajuste o setor ou a pesquisa.</p>
                  </div>
                </div>
              )}

              {visible.length >= 300 && <p className="text-center text-xs text-muted-foreground">Mostrando as primeiras 300 fichas. Use os filtros para refinar a lista.</p>}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
