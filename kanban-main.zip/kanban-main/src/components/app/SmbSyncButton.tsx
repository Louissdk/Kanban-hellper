import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, CheckCircle2, Clock3, RefreshCw, WifiOff } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { fmtSyncDateTime } from "@/lib/data";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";

const STATUS = {
  requested: { label: "Sincronização solicitada", icon: Clock3 },
  running: { label: "Sincronizando com SMB...", icon: RefreshCw },
  success: { label: "Sincronizado", icon: CheckCircle2 },
  partial: { label: "Sincronizado com avisos", icon: AlertTriangle },
  failed: { label: "Erro na sincronização", icon: AlertTriangle },
} as const;

type SyncRun = {
  id: string;
  status: string;
  finished_at: string | null;
  started_at: string | null;
  created_at: string;
  trigger_type: string | null;
  trigger: string | null;
  robot_status: string | null;
  robot_message: string | null;
  error_message: string | null;
  orders_scanned: number | null;
  orders_created: number | null;
  orders_updated: number | null;
  orders_ignored: number | null;
  errors_count: number | null;
};

export function SmbSyncButton({ compact = false }: { compact?: boolean }) {
  const { isTestMode } = useAuth();
  const qc = useQueryClient();
  const [requesting, setRequesting] = useState(false);
  const [activeRunId, setActiveRunId] = useState<string | null>(null);
  const handledRunRef = useRef<string | null>(null);

  const { data: runs = [] } = useQuery({
    queryKey: ["sync", "button"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("sync_runs")
        .select(
          "id,status,finished_at,started_at,created_at,trigger_type,trigger,robot_status,robot_message,error_message,orders_scanned,orders_created,orders_updated,orders_ignored,errors_count",
        )
        .order("created_at", { ascending: false })
        .limit(12);

      if (error) throw new Error(error.message);
      return (data ?? []) as SyncRun[];
    },
    refetchInterval: 3000,
    staleTime: 1000,
  });

  const active = useMemo(
    () => runs.find((run) => run.status === "requested" || run.status === "running"),
    [runs],
  );

  const latestFinished = useMemo(
    () => runs.find((run) => !!run.finished_at),
    [runs],
  );

  const shown = activeRunId
    ? runs.find((run) => run.id === activeRunId) ?? active
    : active ?? latestFinished;

  const status = shown?.status;
  const unavailable = shown?.status === "failed" && shown.robot_status === "unavailable";
  const statusEntry = status ? STATUS[status as keyof typeof STATUS] : undefined;
  const StatusIcon = unavailable ? WifiOff : statusEntry?.icon ?? Clock3;
  const statusLabel = isTestMode
    ? "SMB bloqueado no teste"
    : unavailable
      ? "Robô indisponível"
      : statusEntry?.label ?? "Aguardando";
  const busy = requesting || !!active;
  const lastSync = latestFinished?.finished_at ?? latestFinished?.started_at;

  useEffect(() => {
    if (!activeRunId) return;
    const current = runs.find((run) => run.id === activeRunId);
    if (!current) return;
    if (current.status === "requested" || current.status === "running") return;
    if (handledRunRef.current === current.id) return;

    handledRunRef.current = current.id;

    if (current.status === "success" || current.status === "partial") {
      toast.success(
        current.status === "success"
          ? "Sincronização concluída."
          : "Sincronização concluída com avisos.",
      );
      void qc.invalidateQueries({ queryKey: ["board"] });
      void qc.invalidateQueries({ queryKey: ["dashboard"] });
    } else if (current.status === "failed") {
      toast.error(
        current.robot_status === "unavailable"
          ? "Não foi possível sincronizar com o SMB: robô indisponível."
          : "Não foi possível sincronizar com o SMB.",
      );
    }

    setActiveRunId(null);
  }, [activeRunId, qc, runs]);

  async function syncNow() {
    if (isTestMode) {
      toast.info("A sincronização SMB fica bloqueada durante o Modo Teste.");
      return;
    }

    setRequesting(true);
    try {
      const { data: userData, error: userError } = await supabase.auth.getUser();
      if (userError || !userData.user?.id) {
        throw new Error("Sua sessão expirou. Entre novamente no sistema.");
      }

      const { data, error } = await supabase
        .from("sync_runs")
        .insert({
          status: "requested",
          trigger: "manual",
          requested_by: userData.user.id,
          trigger_type: "manual_button",
          robot_status: "queued",
          robot_message: "Aguardando o robô SMB.",
        })
        .select(
          "id,status,finished_at,started_at,created_at,trigger_type,trigger,robot_status,robot_message,error_message,orders_scanned,orders_created,orders_updated,orders_ignored,errors_count",
        )
        .single();

      if (error) {
        if (error.code === "23505") {
          throw new Error("Já existe uma sincronização aguardando processamento ou em andamento.");
        }
        throw new Error(error.message);
      }

      handledRunRef.current = null;
      setActiveRunId((data as SyncRun).id);
      await qc.invalidateQueries({ queryKey: ["sync", "button"] });
      toast.info("Sincronização solicitada. O robô processará a fila pelo Supabase.");
    } catch (error) {
      void qc.invalidateQueries({ queryKey: ["sync", "button"] });
      toast.error(
        error instanceof Error
          ? error.message
          : "Não foi possível solicitar a sincronização.",
      );
    } finally {
      setRequesting(false);
    }
  }

  return (
    <div className="flex items-center gap-2">
      {!compact && (
        <div className="hidden min-w-0 text-right sm:block">
          <p className="flex items-center justify-end gap-1.5 text-xs font-semibold">
            <StatusIcon className={"size-3.5 " + (status === "running" ? "animate-spin" : "")} />
            {statusLabel}
          </p>
          <p className="text-[10px] text-muted-foreground">
            Última sincronização: {lastSync ? fmtSyncDateTime(lastSync) : "—"}
          </p>
          {shown && (
            <p className="max-w-[560px] truncate text-[10px] text-muted-foreground">
              Lidos {shown.orders_scanned ?? 0} · Novos {shown.orders_created ?? 0} · Atualizados {shown.orders_updated ?? 0} · Ignorados {shown.orders_ignored ?? 0} · Erros {shown.errors_count ?? 0}
            </p>
          )}
        </div>
      )}

      <Button
        onClick={() => void syncNow()}
        disabled={busy || isTestMode}
        size={compact ? "sm" : "default"}
        variant={compact ? "outline" : "default"}
        className={compact ? "h-10 gap-2 whitespace-nowrap" : "shadow-sm"}
        aria-label={isTestMode ? "Sincronização SMB bloqueada no Modo Teste" : "Sincronizar com SMB"}
      >
        <RefreshCw className={"size-4 " + (requesting || status === "running" ? "animate-spin" : "")} />
        {isTestMode
          ? "SMB bloqueado no teste"
          : compact
            ? "Sincronizar SMB"
            : "Sincronizar com SMB"}
      </Button>
    </div>
  );
}
