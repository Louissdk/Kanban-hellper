import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Area,
  Bar,
  CartesianGrid,
  ComposedChart,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { CalendarDays, Check, Maximize2, Minimize2, Star, TrendingDown, Truck } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { sectorsQuery } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

type TvOrder = {
  ficha_id: string;
  display_date: string;
  is_priority: boolean;
  shipping_method: string;
  sort_order: number;
};

type Candidate = {
  ficha_id: string;
  sector_id: string;
  stage_name: string;
  sector_name: string;
  order_number: string;
  customer: string;
  pdd_id: string | null;
  external_order_id: string | null;
  seller_name: string | null;
};

type LossRow = {
  occurrence_date: string;
  quantity: number;
  reason_category: string | null;
};

function today() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

function addDays(value: string, amount: number) {
  const parts = value.split("-").map(Number);
  const d = new Date(parts[0], parts[1] - 1, parts[2]);
  d.setDate(d.getDate() + amount);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

function dayLabel(value: string) {
  const parts = value.split("-").map(Number);
  return new Intl.DateTimeFormat("pt-BR", { weekday: "short", day: "2-digit", month: "2-digit" })
    .format(new Date(parts[0], parts[1] - 1, parts[2]))
    .replace(".", "");
}

function fullDate(value: string) {
  const parts = value.split("-").map(Number);
  return new Intl.DateTimeFormat("pt-BR", { weekday: "long", day: "2-digit", month: "long" })
    .format(new Date(parts[0], parts[1] - 1, parts[2]));
}

function shortDate(value: string) {
  const parts = value.split("-").map(Number);
  return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "2-digit" })
    .format(new Date(parts[0], parts[1] - 1, parts[2]));
}

function toggleDateValue(values: string[], value: string) {
  return values.includes(value) ? values.filter((item) => item !== value) : [...values, value].sort();
}

export function ModoTvPage() {
  const [selectedDates, setSelectedDates] = useState<string[]>([today()]);
  const [customDate, setCustomDate] = useState("");
  const [fullScreen, setFullScreen] = useState(false);
  const [sectorFilter, setSectorFilter] = useState("all");

  const dateOptions = useMemo(() => Array.from({ length: 14 }, (_, index) => addDays(today(), index)), []);
  const sectors = useQuery(sectorsQuery);

  const tvQuery = useQuery({
    queryKey: ["modo-tv-orders"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("tv_orders")
        .select("ficha_id,display_date,is_priority,shipping_method,sort_order")
        .order("display_date")
        .order("is_priority", { ascending: false })
        .order("sort_order");
      if (error) throw new Error(error.message);
      return (data ?? []) as TvOrder[];
    },
    refetchInterval: 5000,
  });

  const candidatesQuery = useQuery({
    queryKey: ["modo-tv-candidates"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("kanban_assignments")
        .select("ficha_id,sector_id,priority,stages!inner(name,is_final),sectors!inner(name,active),fichas!inner(order_number,pdd_id,external_order_id,customer,seller_name)");
      if (error) throw new Error(error.message);

      return ((data ?? []) as unknown as Array<{
        ficha_id: string;
        sector_id: string;
        priority: string;
        stages: { name: string; is_final: boolean };
        sectors: { name: string; active: boolean };
        fichas: { order_number: string; customer: string; pdd_id: string | null; external_order_id: string | null; seller_name: string | null };
      }>)
        .filter((row) => row.sectors.active)
        .filter((row) => row.stages.name.trim().toLowerCase() !== "expedição" && !row.stages.is_final)
        .map((row) => ({
          ficha_id: row.ficha_id,
          sector_id: row.sector_id,
          stage_name: row.stages.name,
          sector_name: row.sectors.name,
          order_number: row.fichas.order_number,
          pdd_id: row.fichas.pdd_id,
          external_order_id: row.fichas.external_order_id,
          customer: row.fichas.customer,
          seller_name: row.fichas.seller_name,
        })) as Candidate[];
    },
    refetchInterval: 5000,
  });

  const lossesQuery = useQuery({
    queryKey: ["modo-tv-losses", selectedDates],
    enabled: selectedDates.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("production_losses")
        .select("occurrence_date,quantity,reason_category")
        .in("occurrence_date", selectedDates);
      if (error) throw new Error(error.message);
      return (data ?? []) as LossRow[];
    },
    refetchInterval: 10000,
  });

  const orders = tvQuery.data ?? [];
  const candidates = candidatesQuery.data ?? [];
  const activeSectors = sectors.data ?? [];
  const candidateMap = useMemo(() => new Map(candidates.map((candidate) => [candidate.ficha_id, candidate])), [candidates]);
  const selectedSet = useMemo(() => new Set(selectedDates), [selectedDates]);

  const scheduled = useMemo(
    () => orders
      .filter((order) => selectedSet.has(order.display_date))
      .map((order) => ({ order, candidate: candidateMap.get(order.ficha_id) }))
      .filter((row): row is { order: TvOrder; candidate: Candidate } => !!row.candidate)
      .filter((row) => sectorFilter === "all" || row.candidate.sector_id === sectorFilter)
      .sort((a, b) => a.order.display_date.localeCompare(b.order.display_date) || Number(b.order.is_priority) - Number(a.order.is_priority) || a.order.sort_order - b.order.sort_order),
    [orders, selectedSet, candidateMap, sectorFilter],
  );

  const groupedDays = useMemo(
    () => selectedDates
      .map((date) => ({
        date,
        rows: scheduled.filter((row) => row.order.display_date === date),
      }))
      .filter((group) => group.rows.length > 0),
    [selectedDates, scheduled],
  );

  const lossChart = useMemo(() => {
    const byDate = new Map<string, { quantity: number; reasons: Map<string, number> }>();
    for (const row of lossesQuery.data ?? []) {
      const current = byDate.get(row.occurrence_date) ?? { quantity: 0, reasons: new Map<string, number>() };
      current.quantity += Number(row.quantity ?? 0);
      const reason = row.reason_category?.trim() || "Sem motivo informado";
      current.reasons.set(reason, (current.reasons.get(reason) ?? 0) + Number(row.quantity ?? 0));
      byDate.set(row.occurrence_date, current);
    }
    return selectedDates.map((date, index) => ({
      date,
      label: shortDate(date),
      quantidade: byDate.get(date)?.quantity ?? 0,
      ordem: index + 1,
    }));
  }, [lossesQuery.data, selectedDates]);

  const lossesTotal = lossChart.reduce((sum, row) => sum + row.quantidade, 0);
  const lossesAverage = lossChart.length ? lossesTotal / lossChart.length : 0;
  const peakLoss = lossChart.reduce<{ label: string; date: string; quantidade: number } | null>((peak, row) => (!peak || row.quantidade > peak.quantidade ? row : peak), null);
  const reasonRanking = useMemo(() => {
    const map = new Map<string, number>();
    for (const row of lossesQuery.data ?? []) {
      const reason = row.reason_category?.trim() || "Sem motivo informado";
      map.set(reason, (map.get(reason) ?? 0) + Number(row.quantity ?? 0));
    }
    return [...map.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3);
  }, [lossesQuery.data]);
  const totalOrders = scheduled.length;
  const totalPriority = scheduled.filter((row) => row.order.is_priority).length;

  function selectToday() {
    const value = today();
    if (!selectedDates.includes(value)) setSelectedDates((old) => [value, ...old]);
  }

  function clearDates() {
    setSelectedDates([today()]);
    setCustomDate("");
  }

  function addCustomDate() {
    if (!customDate) return;
    setSelectedDates((old) => toggleDateValue(old, customDate));
    setCustomDate("");
  }

  async function toggleFullscreen() {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        setFullScreen(true);
      } else {
        await document.exitFullscreen();
        setFullScreen(false);
      }
    } catch {
      toast.error("Não foi possível alterar a tela cheia.");
    }
  }

  return (
    <div className="min-h-screen overflow-hidden bg-background">
      <header className="border-b bg-card/95 px-4 py-3 shadow-sm backdrop-blur sm:px-6 lg:px-9">
        <div className="flex flex-wrap items-start gap-3">
          <div className="min-w-0">
            <p className="text-[10px] font-bold uppercase tracking-[0.28em] text-primary">PEDIFLOW · PAINEL OPERACIONAL</p>
            <h1 className="truncate text-2xl font-black tracking-tight sm:text-3xl">Programação da produção</h1>
            <p className="mt-1 text-xs text-muted-foreground">Selecione um ou vários dias para acompanhar somente os números das fichas programadas.</p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <div className="hidden rounded-2xl border bg-background/70 px-4 py-2 text-right sm:block">
              <p className="text-[9px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Fichas</p>
              <p className="text-2xl font-black tabular-nums">{totalOrders}</p>
            </div>
            <div className="hidden rounded-2xl border bg-background/70 px-4 py-2 text-right sm:block">
              <p className="text-[9px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Prioridades</p>
              <p className="text-2xl font-black tabular-nums">{totalPriority}</p>
            </div>
            <Button variant="outline" size="icon" onClick={() => void toggleFullscreen()} aria-label={fullScreen ? "Sair da tela cheia" : "Entrar em tela cheia"}>
              {fullScreen ? <Minimize2 className="size-4" /> : <Maximize2 className="size-4" />}
            </Button>
          </div>
        </div>

        <div className="mt-4 rounded-2xl border bg-background/60 p-2">
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <div className="flex shrink-0 items-center gap-1.5 px-2 text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">
              <CalendarDays className="size-4" /> Dias
            </div>
            {dateOptions.map((date) => {
              const selected = selectedDates.includes(date);
              const count = orders.filter((order) => order.display_date === date).length;
              return (
                <button
                  key={date}
                  type="button"
                  onClick={() => setSelectedDates((old) => toggleDateValue(old, date))}
                  className={selected
                    ? "flex min-w-[92px] shrink-0 items-center justify-between gap-3 rounded-xl border-2 border-primary bg-primary px-3 py-2 text-left text-primary-foreground shadow-sm"
                    : "flex min-w-[92px] shrink-0 items-center justify-between gap-3 rounded-xl border bg-card px-3 py-2 text-left text-foreground transition hover:border-primary/40 hover:bg-primary/5"}
                  aria-pressed={selected}
                >
                  <span>
                    <span className="block text-[10px] font-bold uppercase tracking-wide opacity-80">{date === today() ? "Hoje" : dayLabel(date).split(" ")[0]}</span>
                    <span className="block font-mono text-sm font-bold">{shortDate(date)}</span>
                  </span>
                  <span className="grid min-w-6 place-items-center rounded-lg bg-black/10 px-1.5 py-1 text-[11px] font-black tabular-nums">{count}</span>
                  {selected && <Check className="absolute sr-only" />}
                </button>
              );
            })}
            <div className="ml-auto flex shrink-0 items-center gap-2 pl-2">
              <Input type="date" value={customDate} onChange={(event) => setCustomDate(event.target.value)} className="h-9 w-36 bg-card" aria-label="Adicionar outro dia" />
              <Button size="sm" variant="outline" disabled={!customDate} onClick={addCustomDate}>Adicionar</Button>
              <Button size="sm" variant="ghost" onClick={selectToday}>Hoje</Button>
              <Button size="sm" variant="ghost" onClick={clearDates}>Limpar</Button>
            </div>
          </div>
        </div>

        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          <Button size="sm" variant={sectorFilter === "all" ? "default" : "outline"} className="shrink-0" onClick={() => setSectorFilter("all")}>Todos os setores</Button>
          {activeSectors.map((sector) => (
            <Button key={sector.id} size="sm" variant={sectorFilter === sector.id ? "default" : "outline"} className="shrink-0" onClick={() => setSectorFilter(sector.id)}>
              {sector.name}
            </Button>
          ))}
        </div>
      </header>

      <main className="mx-auto grid min-h-[calc(100vh-10.5rem)] max-w-[2300px] gap-5 p-4 sm:p-6 lg:grid-cols-[minmax(0,1fr)_460px] lg:p-8 xl:grid-cols-[minmax(0,1fr)_500px]">
        <section className="min-w-0">
          <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">FICHAS PROGRAMADAS</p>
              <h2 className="mt-1 text-xl font-black sm:text-2xl">{selectedDates.length} {selectedDates.length === 1 ? "dia selecionado" : "dias selecionados"}</h2>
            </div>
            <Badge variant="outline" className="rounded-full px-3 py-1.5 text-xs font-bold">{totalOrders} fichas · {totalPriority} prioridades</Badge>
          </div>

          {groupedDays.length === 0 ? (
            <div className="grid min-h-[58vh] place-items-center rounded-3xl border border-dashed bg-card/60 p-8 text-center">
              <div>
                <Truck className="mx-auto size-12 text-muted-foreground" />
                <p className="mt-4 text-xl font-black">Nenhuma ficha programada</p>
                <p className="mt-2 max-w-md text-sm text-muted-foreground">Selecione outro dia ou aguarde a programação administrativa. A tela exibe apenas os números das fichas.</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {groupedDays.map((group) => (
                <section key={group.date} className="overflow-hidden rounded-3xl border bg-card shadow-card">
                  <header className="flex items-center justify-between gap-3 border-b bg-muted/25 px-4 py-3 sm:px-5">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-primary">PROGRAMAÇÃO</p>
                      <h3 className="mt-0.5 text-lg font-black capitalize">{fullDate(group.date)}</h3>
                    </div>
                    <Badge className="rounded-full px-3">{group.rows.length}</Badge>
                  </header>
                  <div className="grid grid-cols-2 gap-3 p-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 sm:p-4">
                    {group.rows.map(({ order, candidate }) => (
                      <article
                        key={order.ficha_id}
                        className={order.is_priority
                          ? "relative flex min-h-28 items-center justify-center rounded-2xl border-2 border-primary bg-primary/10 px-3 py-5 shadow-sm"
                          : "relative flex min-h-28 items-center justify-center rounded-2xl border bg-background px-3 py-5 transition hover:border-primary/40"}
                      >
                        {order.is_priority && <Star className="absolute right-3 top-3 size-4 fill-current text-primary" aria-label="Prioridade" />}
                        <div className="text-center">
                          <p className="font-mono text-3xl font-black tracking-tight sm:text-4xl">#{candidate.order_number || "—"}</p>
                          {(candidate.pdd_id || candidate.external_order_id) && (
                            <p className="mt-1 font-mono text-[10px] font-bold uppercase tracking-[0.14em] text-primary">
                              SMB/PDD #{candidate.pdd_id || candidate.external_order_id}
                            </p>
                          )}
                        </div>
                      </article>
                    ))}
                  </div>
                </section>
              ))}
            </div>
          )}
        </section>

        <aside className="overflow-hidden rounded-3xl border bg-card shadow-card">
          <div className="border-b bg-muted/20 px-5 py-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-destructive">QUALIDADE / PRODUÇÃO</p>
                <h2 className="mt-1 text-2xl font-black">Perdas de produção</h2>
                <p className="mt-1 text-xs text-muted-foreground">Somente os dias selecionados no painel acima.</p>
              </div>
              <TrendingDown className="size-6 text-destructive" />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 p-4">
            <div className="rounded-2xl border bg-background p-3">
              <p className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">Total</p>
              <p className="mt-1 text-2xl font-black tabular-nums text-destructive">{lossesTotal}</p>
              <p className="text-[10px] text-muted-foreground">peças</p>
            </div>
            <div className="rounded-2xl border bg-background p-3">
              <p className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">Média / dia</p>
              <p className="mt-1 text-2xl font-black tabular-nums">{lossesAverage.toFixed(1).replace(".", ",")}</p>
              <p className="text-[10px] text-muted-foreground">{selectedDates.length} dias</p>
            </div>
            <div className="rounded-2xl border bg-background p-3">
              <p className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">Pico</p>
              <p className="mt-1 text-2xl font-black tabular-nums">{peakLoss?.quantidade ?? 0}</p>
              <p className="truncate text-[10px] text-muted-foreground">{peakLoss?.label ?? "—"}</p>
            </div>
          </div>

          <div className="px-4 pb-4">
            <div className="h-72 rounded-2xl border bg-background/70 p-2 sm:h-80">
              {lossChart.length === 0 ? (
                <div className="grid h-full place-items-center text-center text-sm text-muted-foreground">Nenhum dado de perda para os dias selecionados.</div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={lossChart} margin={{ top: 12, right: 8, left: -20, bottom: 2 }}>
                    <defs>
                      <linearGradient id="lossAreaTv" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="var(--color-destructive)" stopOpacity={0.22} />
                        <stop offset="100%" stopColor="var(--color-destructive)" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="4 4" stroke="var(--color-border)" vertical={false} />
                    <XAxis dataKey="label" tick={{ fontSize: 10, fill: "var(--color-muted-foreground)" }} axisLine={false} tickLine={false} />
                    <YAxis allowDecimals tick={{ fontSize: 10, fill: "var(--color-muted-foreground)" }} axisLine={false} tickLine={false} width={32} />
                    <Tooltip
                      cursor={{ fill: "var(--color-muted)", opacity: 0.25 }}
                      contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 14, boxShadow: "var(--shadow-lift)" }}
                      labelStyle={{ fontWeight: 800, color: "var(--color-foreground)" }}
                      formatter={(value) => [value, "Peças perdidas"]}
                    />
                    {peakLoss && <ReferenceLine y={peakLoss.quantidade} stroke="var(--color-destructive)" strokeDasharray="6 6" opacity={0.5} />}
                    <Area type="monotone" dataKey="quantidade" stroke="none" fill="url(#lossAreaTv)" />
                    <Bar dataKey="quantidade" name="Peças perdidas" fill="var(--color-destructive)" radius={[8, 8, 2, 2]} maxBarSize={42} />
                    <Line type="monotone" dataKey="quantidade" stroke="var(--color-primary)" strokeWidth={3} dot={{ r: 4, fill: "var(--color-primary)" }} activeDot={{ r: 6 }} />
                  </ComposedChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          <div className="border-t px-4 py-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Principais motivos</p>
                <p className="mt-0.5 text-xs text-muted-foreground">Participação pelas peças perdidas.</p>
              </div>
              <Badge variant="outline">{reasonRanking.length} motivo{reasonRanking.length === 1 ? "" : "s"}</Badge>
            </div>
            <div className="mt-3 space-y-2.5">
              {reasonRanking.length === 0 ? (
                <p className="rounded-xl border border-dashed p-4 text-center text-xs text-muted-foreground">Sem perdas registradas.</p>
              ) : reasonRanking.map(([reason, value], index) => (
                <div key={reason} className="rounded-xl border bg-background/60 p-3">
                  <div className="flex items-center justify-between gap-3 text-xs">
                    <span className="min-w-0 truncate font-semibold">{index + 1}. {reason}</span>
                    <span className="font-black tabular-nums text-destructive">{value}</span>
                  </div>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-destructive" style={{ width: lossesTotal ? (value / lossesTotal) * 100 + "%" : "0%" }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </main>
    </div>
  );
}
