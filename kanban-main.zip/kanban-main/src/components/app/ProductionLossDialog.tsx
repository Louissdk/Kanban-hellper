import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { CalendarDays, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { profilesQuery, sectorsQuery, stagesQuery, errMsg } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const LOSS_REASONS = [
  "Peça morreu / queimou",
  "Perda de material",
  "Erro de montagem",
  "Erro de soldagem",
  "Retífica incorreta",
  "Produção interrompida",
  "Problema de qualidade",
  "Retrabalho sem recuperação",
  "Dano durante manuseio",
  "Outro",
] as const;

export function ProductionLossDialog({
  open,
  onOpenChange,
  fichaId = null,
  defaultSectorId = null,
  defaultStageId = null,
  defaultDescription = "",
  defaultResponsibleId = null,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  fichaId?: string | null;
  defaultSectorId?: string | null;
  defaultStageId?: string | null;
  defaultDescription?: string;
  defaultResponsibleId?: string | null;
}) {
  const qc = useQueryClient();
  const { data: sectors = [] } = useQuery(sectorsQuery);
  const { data: profiles = [] } = useQuery(profilesQuery);
  const [sectorId, setSectorId] = useState<string | null>(defaultSectorId);
  const { data: stages = [] } = useQuery(stagesQuery(sectorId ?? undefined));
  const [stageId, setStageId] = useState<string | null>(defaultStageId);
  const [responsibleId, setResponsibleId] = useState<string | null>(defaultResponsibleId);
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [description, setDescription] = useState(defaultDescription);
  const [quantity, setQuantity] = useState("1");
  const [unit, setUnit] = useState("UND");
  const [reason, setReason] = useState<string>("Perda de material");
  const [details, setDetails] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setSectorId(defaultSectorId);
    setStageId(defaultStageId);
    setResponsibleId(defaultResponsibleId);
    setDate(new Date().toISOString().slice(0, 10));
    setDescription(defaultDescription);
    setQuantity("1");
    setUnit("UND");
    setReason("Perda de material");
    setDetails("");
  }, [open, defaultSectorId, defaultStageId, defaultResponsibleId, defaultDescription]);

  useEffect(() => {
    if (stageId && !stages.some((s) => s.id === stageId && s.active)) setStageId(null);
  }, [stages, stageId]);

  async function save() {
    if (!sectorId) return toast.error("Selecione o setor da perda.");
    if (!responsibleId) return toast.error("Selecione o responsável pela perda.");
    if (!description.trim()) return toast.error("Informe a descrição da peça.");
    if (!Number(quantity) || Number(quantity) <= 0) return toast.error("Informe uma quantidade válida.");
    if (!reason) return toast.error("Selecione o motivo da perda.");

    setSaving(true);
    try {
      const { error } = await supabase.rpc("record_production_loss", {
        _ficha_id: fichaId,
        _occurrence_date: date,
        _sector_id: sectorId,
        _stage_id: stageId,
        _responsible_id: responsibleId,
        _description: description.trim(),
        _quantity: Number(quantity),
        _unit: unit.trim() || "UND",
        _reason_category: reason,
        _details: details.trim() || null,
      });
      if (error) throw new Error(error.message);
      toast.success("Perda registrada no histórico de produção.");
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["dashboard-losses"] }),
        qc.invalidateQueries({ queryKey: ["ficha", fichaId] }),
        qc.invalidateQueries({ queryKey: ["board"] }),
      ]);
      onOpenChange(false);
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !saving && onOpenChange(v)}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Registrar perda de peça</DialogTitle>
          <DialogDescription>O registro fica salvo no banco para o relatório de perdas por período, setor e responsável.</DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 sm:gap-4 sm:grid-cols-2">
          {fichaId && <div className="rounded-md border bg-muted p-3 text-sm md:col-span-2">Ficha vinculada: <strong>#{fichaId}</strong></div>}

          <div className="space-y-1.5">
            <Label>Data da perda *</Label>
            <div className="relative">
              <CalendarDays className="pointer-events-none absolute left-3 top-2.5 size-4 text-muted-foreground" />
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="pl-9" disabled={saving} />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Setor *</Label>
            <Select value={sectorId ?? ""} onValueChange={(v) => { setSectorId(v); setStageId(null); }} disabled={saving}>
              <SelectTrigger><SelectValue placeholder="Selecione o setor" /></SelectTrigger>
              <SelectContent>{sectors.filter((s) => s.active).map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label>Etapa da perda</Label>
            <Select value={stageId ?? ""} onValueChange={setStageId} disabled={saving || !sectorId}>
              <SelectTrigger><SelectValue placeholder="Selecione a etapa" /></SelectTrigger>
              <SelectContent>{stages.filter((s) => s.active).map((s) => <SelectItem key={s.id} value={s.id}>{s.position}. {s.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label>Responsável *</Label>
            <Select value={responsibleId ?? ""} onValueChange={setResponsibleId} disabled={saving}>
              <SelectTrigger><SelectValue placeholder="Selecione o responsável" /></SelectTrigger>
              <SelectContent>{profiles.filter((p) => p.active).map((p) => <SelectItem key={p.id} value={p.id}>{p.full_name || p.email}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5 md:col-span-2">
            <Label>Descrição da peça *</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Ex.: Resistência cartucho 220V — 300 mm" disabled={saving} maxLength={200} />
          </div>

          <div className="space-y-1.5">
            <Label>Quantidade perdida *</Label>
            <Input type="number" min="0.01" step="0.01" value={quantity} onChange={(e) => setQuantity(e.target.value)} disabled={saving} />
          </div>

          <div className="space-y-1.5">
            <Label>Unidade</Label>
            <Input value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="UND" disabled={saving} maxLength={20} />
          </div>

          <div className="space-y-1.5 md:col-span-2">
            <Label>Motivo da perda *</Label>
            <Select value={reason} onValueChange={setReason} disabled={saving}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{LOSS_REASONS.map((x) => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5 md:col-span-2">
            <Label>Detalhes</Label>
            <Textarea value={details} onChange={(e) => setDetails(e.target.value)} rows={3} maxLength={1000} placeholder="Descreva o que aconteceu, defeito encontrado, material perdido, retrabalho etc." disabled={saving} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>Cancelar</Button>
          <Button onClick={() => void save()} disabled={saving}>{saving && <Loader2 className="size-4 animate-spin" />} Registrar perda</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
