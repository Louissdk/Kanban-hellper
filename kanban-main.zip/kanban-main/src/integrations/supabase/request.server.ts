import { createClient } from "@supabase/supabase-js";
import type { Database } from "./types";

/**
 * User-scoped Supabase client for server handlers.
 *
 * It intentionally uses only the same public Vite configuration as the
 * browser client and the authenticated user's access token. It does not use
 * SUPABASE_SERVICE_ROLE_KEY and cannot bypass RLS.
 */
function getPublicSupabaseConfig() {
  const url = import.meta.env.VITE_SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const key =
    import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
    process.env.VITE_SUPABASE_PUBLISHABLE_KEY;

  if (!url || !key) {
    throw new Error(
      "Configuração pública do Supabase ausente no servidor: VITE_SUPABASE_URL e VITE_SUPABASE_PUBLISHABLE_KEY.",
    );
  }

  return { url, key };
}

export function createSupabaseRequestClient(accessToken: string) {
  const { url, key } = getPublicSupabaseConfig();

  if (!accessToken?.trim()) {
    throw new Error("Sessão inválida.");
  }

  return createClient<Database>(url, key, {
    global: {
      headers: {
        Authorization: "Bearer " + accessToken.trim(),
      },
    },
    auth: {
      storage: undefined,
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}
