export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      clientes: {
        Row: {
          ativo: boolean
          codigo_cliente: string | null
          created_at: string
          id: number
          nome: string
        }
        Insert: {
          ativo?: boolean
          codigo_cliente?: string | null
          created_at?: string
          id?: number
          nome: string
        }
        Update: {
          ativo?: boolean
          codigo_cliente?: string | null
          created_at?: string
          id?: number
          nome?: string
        }
        Relationships: []
      }
      documents: {
        Row: {
          content: string | null
          embedding: string | null
          id: number
          metadata: Json | null
        }
        Insert: {
          content?: string | null
          embedding?: string | null
          id?: number
          metadata?: Json | null
        }
        Update: {
          content?: string | null
          embedding?: string | null
          id?: number
          metadata?: Json | null
        }
        Relationships: []
      }
      ficha_deletion_history: {
        Row: {
          authorized_profile_id: string | null
          deleted_at: string
          deleted_by_user_id: string | null
          ficha_id: string
          id: string
          order_number: string | null
          record_snapshot: Json
        }
        Insert: {
          authorized_profile_id?: string | null
          deleted_at?: string
          deleted_by_user_id?: string | null
          ficha_id: string
          id?: string
          order_number?: string | null
          record_snapshot?: Json
        }
        Update: {
          authorized_profile_id?: string | null
          deleted_at?: string
          deleted_by_user_id?: string | null
          ficha_id?: string
          id?: string
          order_number?: string | null
          record_snapshot?: Json
        }
        Relationships: [
          {
            foreignKeyName: "ficha_deletion_history_authorized_profile_id_fkey"
            columns: ["authorized_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ficha_deletion_history_deleted_by_user_id_fkey"
            columns: ["deleted_by_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      ficha_items: {
        Row: {
          code: string | null
          created_at: string
          description: string | null
          ficha_id: string
          id: string
          line_no: number
          pdd_id: string | null
          product: string | null
          quantity: number | null
          unit: string | null
          updated_at: string
        }
        Insert: {
          code?: string | null
          created_at?: string
          description?: string | null
          ficha_id: string
          id?: string
          line_no?: number
          pdd_id?: string | null
          product?: string | null
          quantity?: number | null
          unit?: string | null
          updated_at?: string
        }
        Update: {
          code?: string | null
          created_at?: string
          description?: string | null
          ficha_id?: string
          id?: string
          line_no?: number
          pdd_id?: string | null
          product?: string | null
          quantity?: number | null
          unit?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ficha_items_ficha_id_fkey"
            columns: ["ficha_id"]
            isOneToOne: false
            referencedRelation: "fichas"
            referencedColumns: ["id"]
          },
        ]
      }
      fichas: {
        Row: {
          codigo_cliente: string | null
          created_at: string
          customer: string
          customer_code: string | null
          data_entrega: string | null
          delivery_date: string | null
          duplicate_group_id: string | null
          envio: string | null
          external_order_id: string | null
          id: string
          opened_at: string | null
          order_date: string | null
          order_number: string
          pdd_id: string | null
          pedido_cliente: string | null
          product_summary: string | null
          quantity: number | null
          seller_name: string | null
          smb_cliente_id: string | null
          smb_ranking: number | null
          smb_status: string | null
          source_hash: string | null
          source_observations: string | null
          source_synced_at: string | null
          source_system: string
          status_smb: string | null
          status_smb_descricao: string | null
          sync_state: string
          sync_warning: string | null
          unit: string | null
          updated_at: string
        }
        Insert: {
          codigo_cliente?: string | null
          created_at?: string
          customer?: string
          customer_code?: string | null
          data_entrega?: string | null
          delivery_date?: string | null
          duplicate_group_id?: string | null
          envio?: string | null
          external_order_id?: string | null
          id?: string
          opened_at?: string | null
          order_date?: string | null
          order_number: string
          pdd_id?: string | null
          pedido_cliente?: string | null
          product_summary?: string | null
          quantity?: number | null
          seller_name?: string | null
          smb_cliente_id?: string | null
          smb_ranking?: number | null
          smb_status?: string | null
          source_hash?: string | null
          source_observations?: string | null
          source_synced_at?: string | null
          source_system?: string
          status_smb?: string | null
          status_smb_descricao?: string | null
          sync_state?: string
          sync_warning?: string | null
          unit?: string | null
          updated_at?: string
        }
        Update: {
          codigo_cliente?: string | null
          created_at?: string
          customer?: string
          customer_code?: string | null
          data_entrega?: string | null
          delivery_date?: string | null
          duplicate_group_id?: string | null
          envio?: string | null
          external_order_id?: string | null
          id?: string
          opened_at?: string | null
          order_date?: string | null
          order_number?: string
          pdd_id?: string | null
          pedido_cliente?: string | null
          product_summary?: string | null
          quantity?: number | null
          seller_name?: string | null
          smb_cliente_id?: string | null
          smb_ranking?: number | null
          smb_status?: string | null
          source_hash?: string | null
          source_observations?: string | null
          source_synced_at?: string | null
          source_system?: string
          status_smb?: string | null
          status_smb_descricao?: string | null
          sync_state?: string
          sync_warning?: string | null
          unit?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      kanban_assignments: {
        Row: {
          completed_at: string | null
          created_at: string
          entered_stage_at: string
          ficha_id: string
          internal_notes: string | null
          last_changed_by: string | null
          last_return_reason: string | null
          last_return_reason_category: string | null
          last_returned_at: string | null
          last_returned_by: string | null
          priority: string
          production_returned: boolean
          production_started_at: string | null
          responsible_id: string | null
          return_count: number
          sector_id: string
          sort_order: number | null
          stage_id: string
          updated_at: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          entered_stage_at?: string
          ficha_id: string
          internal_notes?: string | null
          last_changed_by?: string | null
          last_return_reason?: string | null
          last_return_reason_category?: string | null
          last_returned_at?: string | null
          last_returned_by?: string | null
          priority?: string
          production_returned?: boolean
          production_started_at?: string | null
          responsible_id?: string | null
          return_count?: number
          sector_id: string
          sort_order?: number | null
          stage_id: string
          updated_at?: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          entered_stage_at?: string
          ficha_id?: string
          internal_notes?: string | null
          last_changed_by?: string | null
          last_return_reason?: string | null
          last_return_reason_category?: string | null
          last_returned_at?: string | null
          last_returned_by?: string | null
          priority?: string
          production_returned?: boolean
          production_started_at?: string | null
          responsible_id?: string | null
          return_count?: number
          sector_id?: string
          sort_order?: number | null
          stage_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "kanban_assignments_ficha_id_fkey"
            columns: ["ficha_id"]
            isOneToOne: true
            referencedRelation: "fichas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kanban_assignments_last_changed_by_fkey"
            columns: ["last_changed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kanban_assignments_last_returned_by_fkey"
            columns: ["last_returned_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kanban_assignments_responsible_id_fkey"
            columns: ["responsible_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kanban_assignments_sector_id_fkey"
            columns: ["sector_id"]
            isOneToOne: false
            referencedRelation: "sectors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kanban_assignments_stage_id_fkey"
            columns: ["stage_id"]
            isOneToOne: false
            referencedRelation: "stages"
            referencedColumns: ["id"]
          },
        ]
      }
      production_losses: {
        Row: {
          created_at: string
          created_by: string
          description: string
          details: string | null
          ficha_id: string | null
          id: string
          occurrence_date: string
          quantity: number
          reason_category: string
          responsible_id: string
          sector_id: string
          stage_id: string | null
          unit: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          description: string
          details?: string | null
          ficha_id?: string | null
          id?: string
          occurrence_date?: string
          quantity?: number
          reason_category: string
          responsible_id: string
          sector_id: string
          stage_id?: string | null
          unit?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          description?: string
          details?: string | null
          ficha_id?: string | null
          id?: string
          occurrence_date?: string
          quantity?: number
          reason_category?: string
          responsible_id?: string
          sector_id?: string
          stage_id?: string | null
          unit?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "production_losses_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "production_losses_ficha_id_fkey"
            columns: ["ficha_id"]
            isOneToOne: false
            referencedRelation: "fichas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "production_losses_responsible_id_fkey"
            columns: ["responsible_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "production_losses_sector_id_fkey"
            columns: ["sector_id"]
            isOneToOne: false
            referencedRelation: "sectors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "production_losses_stage_id_fkey"
            columns: ["stage_id"]
            isOneToOne: false
            referencedRelation: "stages"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          active: boolean
          created_at: string
          email: string | null
          full_name: string
          id: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          email?: string | null
          full_name?: string
          id: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          email?: string | null
          full_name?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      sector_transfer_history: {
        Row: {
          changed_at: string
          changed_by_user_id: string | null
          ficha_id: string
          id: string
          new_sector_id: string
          new_stage_id: string
          observation: string | null
          performed_by_user_id: string | null
          previous_sector_id: string | null
          previous_stage_id: string | null
        }
        Insert: {
          changed_at?: string
          changed_by_user_id?: string | null
          ficha_id: string
          id?: string
          new_sector_id: string
          new_stage_id: string
          observation?: string | null
          performed_by_user_id?: string | null
          previous_sector_id?: string | null
          previous_stage_id?: string | null
        }
        Update: {
          changed_at?: string
          changed_by_user_id?: string | null
          ficha_id?: string
          id?: string
          new_sector_id?: string
          new_stage_id?: string
          observation?: string | null
          performed_by_user_id?: string | null
          previous_sector_id?: string | null
          previous_stage_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sector_transfer_history_changed_by_user_id_fkey"
            columns: ["changed_by_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sector_transfer_history_ficha_id_fkey"
            columns: ["ficha_id"]
            isOneToOne: false
            referencedRelation: "fichas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sector_transfer_history_new_sector_id_fkey"
            columns: ["new_sector_id"]
            isOneToOne: false
            referencedRelation: "sectors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sector_transfer_history_new_stage_id_fkey"
            columns: ["new_stage_id"]
            isOneToOne: false
            referencedRelation: "stages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sector_transfer_history_performed_by_user_id_fkey"
            columns: ["performed_by_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sector_transfer_history_previous_sector_id_fkey"
            columns: ["previous_sector_id"]
            isOneToOne: false
            referencedRelation: "sectors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sector_transfer_history_previous_stage_id_fkey"
            columns: ["previous_stage_id"]
            isOneToOne: false
            referencedRelation: "stages"
            referencedColumns: ["id"]
          },
        ]
      }
      sectors: {
        Row: {
          active: boolean
          created_at: string
          description: string | null
          id: string
          is_default_import: boolean
          name: string
          position: number
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          description?: string | null
          id?: string
          is_default_import?: boolean
          name: string
          position?: number
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          description?: string | null
          id?: string
          is_default_import?: boolean
          name?: string
          position?: number
          updated_at?: string
        }
        Relationships: []
      }
      smb_admin_changes: {
        Row: {
          actor_label: string
          actor_type: string
          change_key: string
          change_type: string
          changed_at: string
          external_order_id: string | null
          ficha_id: string | null
          field_label: string
          field_name: string
          id: string
          item_line_no: number | null
          metadata: Json
          new_value: Json | null
          old_value: Json | null
          source: string
          sync_run_id: string | null
        }
        Insert: {
          actor_label?: string
          actor_type?: string
          change_key: string
          change_type?: string
          changed_at?: string
          external_order_id?: string | null
          ficha_id?: string | null
          field_label: string
          field_name: string
          id?: string
          item_line_no?: number | null
          metadata?: Json
          new_value?: Json | null
          old_value?: Json | null
          source?: string
          sync_run_id?: string | null
        }
        Update: {
          actor_label?: string
          actor_type?: string
          change_key?: string
          change_type?: string
          changed_at?: string
          external_order_id?: string | null
          ficha_id?: string | null
          field_label?: string
          field_name?: string
          id?: string
          item_line_no?: number | null
          metadata?: Json
          new_value?: Json | null
          old_value?: Json | null
          source?: string
          sync_run_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "smb_admin_changes_ficha_id_fkey"
            columns: ["ficha_id"]
            isOneToOne: false
            referencedRelation: "fichas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "smb_admin_changes_sync_run_id_fkey"
            columns: ["sync_run_id"]
            isOneToOne: false
            referencedRelation: "sync_runs"
            referencedColumns: ["id"]
          },
        ]
      }
      stages: {
        Row: {
          active: boolean
          color: string | null
          created_at: string
          id: string
          is_final: boolean
          name: string
          position: number
          sector_id: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          color?: string | null
          created_at?: string
          id?: string
          is_final?: boolean
          name: string
          position?: number
          sector_id: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          color?: string | null
          created_at?: string
          id?: string
          is_final?: boolean
          name?: string
          position?: number
          sector_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "stages_sector_id_fkey"
            columns: ["sector_id"]
            isOneToOne: false
            referencedRelation: "sectors"
            referencedColumns: ["id"]
          },
        ]
      }
      status_history: {
        Row: {
          changed_at: string
          changed_by_user_id: string | null
          ficha_id: string
          id: string
          movement_type: string
          new_stage_id: string
          observation: string | null
          performed_by_user_id: string | null
          previous_stage_id: string | null
          return_reason: string | null
          return_reason_category: string | null
          sector_id: string
          source: string
        }
        Insert: {
          changed_at?: string
          changed_by_user_id?: string | null
          ficha_id: string
          id?: string
          movement_type?: string
          new_stage_id: string
          observation?: string | null
          performed_by_user_id?: string | null
          previous_stage_id?: string | null
          return_reason?: string | null
          return_reason_category?: string | null
          sector_id: string
          source?: string
        }
        Update: {
          changed_at?: string
          changed_by_user_id?: string | null
          ficha_id?: string
          id?: string
          movement_type?: string
          new_stage_id?: string
          observation?: string | null
          performed_by_user_id?: string | null
          previous_stage_id?: string | null
          return_reason?: string | null
          return_reason_category?: string | null
          sector_id?: string
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "status_history_changed_by_user_id_fkey"
            columns: ["changed_by_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "status_history_ficha_id_fkey"
            columns: ["ficha_id"]
            isOneToOne: false
            referencedRelation: "fichas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "status_history_new_stage_id_fkey"
            columns: ["new_stage_id"]
            isOneToOne: false
            referencedRelation: "stages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "status_history_performed_by_user_id_fkey"
            columns: ["performed_by_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "status_history_previous_stage_id_fkey"
            columns: ["previous_stage_id"]
            isOneToOne: false
            referencedRelation: "stages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "status_history_sector_id_fkey"
            columns: ["sector_id"]
            isOneToOne: false
            referencedRelation: "sectors"
            referencedColumns: ["id"]
          },
        ]
      }
      sync_errors: {
        Row: {
          created_at: string
          error_message: string | null
          error_type: string | null
          external_order_id: string | null
          id: string
          level: string
          message: string
          occurred_at: string | null
          sync_run_id: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          error_type?: string | null
          external_order_id?: string | null
          id?: string
          level?: string
          message: string
          occurred_at?: string | null
          sync_run_id: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          error_type?: string | null
          external_order_id?: string | null
          id?: string
          level?: string
          message?: string
          occurred_at?: string | null
          sync_run_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "sync_errors_sync_run_id_fkey"
            columns: ["sync_run_id"]
            isOneToOne: false
            referencedRelation: "sync_runs"
            referencedColumns: ["id"]
          },
        ]
      }
      sync_runs: {
        Row: {
          created_at: string
          error_details: string | null
          error_message: string | null
          errors: number
          errors_count: number
          finished_at: string | null
          id: string
          inserted: number
          orders_created: number
          orders_eligible: number
          orders_ignored: number
          orders_scanned: number
          orders_updated: number
          requested_by: string | null
          robot_message: string | null
          robot_status: string
          skipped: number
          started_at: string | null
          status: string
          total_read: number
          trigger: string
          trigger_type: string | null
          updated: number
          warnings: number
        }
        Insert: {
          created_at?: string
          error_details?: string | null
          error_message?: string | null
          errors?: number
          errors_count?: number
          finished_at?: string | null
          id?: string
          inserted?: number
          orders_created?: number
          orders_eligible?: number
          orders_ignored?: number
          orders_scanned?: number
          orders_updated?: number
          requested_by?: string | null
          robot_message?: string | null
          robot_status?: string
          skipped?: number
          started_at?: string | null
          status?: string
          total_read?: number
          trigger?: string
          trigger_type?: string | null
          updated?: number
          warnings?: number
        }
        Update: {
          created_at?: string
          error_details?: string | null
          error_message?: string | null
          errors?: number
          errors_count?: number
          finished_at?: string | null
          id?: string
          inserted?: number
          orders_created?: number
          orders_eligible?: number
          orders_ignored?: number
          orders_scanned?: number
          orders_updated?: number
          requested_by?: string | null
          robot_message?: string | null
          robot_status?: string
          skipped?: number
          started_at?: string | null
          status?: string
          total_read?: number
          trigger?: string
          trigger_type?: string | null
          updated?: number
          warnings?: number
        }
        Relationships: [
          {
            foreignKeyName: "sync_runs_requested_by_fkey"
            columns: ["requested_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      system_settings: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      tv_orders: {
        Row: {
          created_at: string
          created_by: string | null
          display_date: string
          ficha_id: string
          is_priority: boolean
          notes: string | null
          shipping_method: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          display_date: string
          ficha_id: string
          is_priority?: boolean
          notes?: string | null
          shipping_method?: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          display_date?: string
          ficha_id?: string
          is_priority?: boolean
          notes?: string | null
          shipping_method?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tv_orders_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tv_orders_ficha_id_fkey"
            columns: ["ficha_id"]
            isOneToOne: true
            referencedRelation: "fichas"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      reorder_kanban_stage: {
        Args: {
          _ordered_ficha_ids: string[]
          _sector_id: string
          _stage_id: string
        }
        Returns: undefined
      }
      activate_test_mode: { Args: never; Returns: Json }
      can_manage: { Args: { _user_id: string }; Returns: boolean }
      can_operate: { Args: { _user_id: string }; Returns: boolean }
      create_manual_ficha:
        | {
            Args: {
              _customer: string
              _delivery_date?: string
              _order_number: string
              _priority?: string
              _product?: string
              _quantity?: number
              _sector_id?: string
              _unit?: string
            }
            Returns: string
          }
        | {
            Args: {
              _customer: string
              _delivery_date?: string
              _order_number: string
              _priority?: string
              _product?: string
              _quantity?: number
              _sector_id?: string
              _seller_name?: string
              _unit?: string
            }
            Returns: string
          }
      create_manual_ficha_with_items:
        | {
            Args: {
              _customer: string
              _delivery_date?: string
              _items?: Json
              _order_number: string
              _priority?: string
              _sector_id?: string
              _seller_name?: string
            }
            Returns: string
          }
        | {
            Args: {
              _allow_duplicate?: boolean
              _customer: string
              _delivery_date?: string
              _items?: Json
              _order_number: string
              _priority?: string
              _sector_id?: string
              _seller_name?: string
            }
            Returns: string
          }
      create_smb_ficha_from_lookup: {
        Args: { _order: Json; _priority?: string; _sector_id: string }
        Returns: Json
      }
      deactivate_test_mode: { Args: never; Returns: Json }
      delete_ficha: {
        Args: {
          _authorized_profile_id: string
          _ficha_id: string
          _pin: string
        }
        Returns: string
      }
      delete_stage_safe: { Args: { _stage_id: string }; Returns: undefined }
      finalize_smb_order: {
        Args: { _ficha_id: string; _observation?: string; _source?: string }
        Returns: boolean
      }
      first_active_stage: { Args: { _sector_id: string }; Returns: string }
      get_delete_authorizers: {
        Args: never
        Returns: {
          active: boolean
          email: string
          full_name: string
          profile_id: string
        }[]
      }
      get_delete_security_state: { Args: never; Returns: Json }
      get_test_mode_state: { Args: never; Returns: Json }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      ingest_smb_order: { Args: { _order: Json }; Returns: string }
      is_test_mode: { Args: never; Returns: boolean }
      list_production_losses: {
        Args: { _end_date: string; _sector_id?: string; _start_date: string }
        Returns: {
          created_at: string
          created_by: string
          description: string
          details: string
          ficha_id: string
          id: string
          occurrence_date: string
          order_number: string
          quantity: number
          reason_category: string
          responsible_id: string
          responsible_name: string
          sector_id: string
          sector_name: string
          stage_id: string
          stage_name: string
          unit: string
        }[]
      }
      manager_delete_control: { Args: never; Returns: boolean }
      mark_unseen_orders: { Args: { _seen_ids: string[] }; Returns: number }
      match_documents: {
        Args: { filter?: Json; match_count?: number; query_embedding: string }
        Returns: {
          content: string
          id: number
          metadata: Json
          similarity: number
        }[]
      }
      parse_smb_date: { Args: { _value: string }; Returns: string }
      parse_smb_datetime: { Args: { _value: string }; Returns: string }
      process_smb_sync_result: {
        Args: { _result: Json; _sync_run_id: string }
        Returns: Json
      }
      record_production_loss: {
        Args: {
          _description?: string
          _details?: string
          _ficha_id?: string
          _occurrence_date?: string
          _quantity?: number
          _reason_category?: string
          _responsible_id?: string
          _sector_id?: string
          _stage_id?: string
          _unit?: string
        }
        Returns: string
      }
      reorder_stages: {
        Args: { _sector_id: string; _stage_ids: string[] }
        Returns: undefined
      }
      search_finalized_fichas: {
        Args: {
          _limit?: number
          _query?: string
          _sector_id: string
          _stage_id: string
        }
        Returns: {
          codigo_cliente: string
          completed_at: string
          customer: string
          customer_code: string
          data_entrega: string
          delivery_date: string
          entered_stage_at: string
          envio: string
          ficha_id: string
          last_return_reason: string
          last_return_reason_category: string
          order_number: string
          pdd_id: string
          pedido_cliente: string
          priority: string
          product_summary: string
          production_returned: boolean
          quantity: number
          responsible_id: string
          return_count: number
          sector_id: string
          seller_name: string
          smb_cliente_id: string
          source_system: string
          stage_id: string
          status_smb: string
          status_smb_descricao: string
          sync_state: string
          source_observations: string
          unit: string
          updated_at: string
        }[]
      }
      set_delete_authorizers: {
        Args: { _profile_ids: string[] }
        Returns: number
      }
      set_delete_pin: { Args: { _pin: string }; Returns: boolean }
      stage_avg_durations: {
        Args: { _sector_id: string }
        Returns: {
          avg_hours: number
          stage_id: string
        }[]
      }
      transfer_ficha_sector: {
        Args: {
          _changed_by: string
          _ficha_id: string
          _new_sector_id: string
          _observation?: string
        }
        Returns: string
      }
      transition_ficha: {
        Args: {
          _changed_by: string
          _ficha_id: string
          _new_stage_id: string
          _observation?: string
          _return_reason_category?: string
          _source?: string
        }
        Returns: string
      }
      update_customer_code: {
        Args: { _customer_code: string; _ficha_id: string }
        Returns: string
      }
      update_ficha_priority: {
        Args: { _ficha_id: string; _priority: string }
        Returns: string
      }
    }
    Enums: {
      app_role: "admin" | "supervisor" | "operator" | "viewer"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "supervisor", "operator", "viewer"],
    },
  },
} as const
