import { createFileRoute } from "@tanstack/react-router";

type Body = {
  ficha_id?: unknown;
  customer_code?: unknown;
};

export const Route = createFileRoute("/api/admin/customer-code")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const authorization = request.headers.get("Authorization");
          const token = authorization?.startsWith("Bearer ")
            ? authorization.slice("Bearer ".length).trim()
            : "";
          if (!token) return Response.json({ message: "Sessão não encontrada." }, { status: 401 });

          const body = (await request.json().catch(() => ({}))) as Body;
          const fichaId = typeof body.ficha_id === "string" ? body.ficha_id : "";
          const code = typeof body.customer_code === "string" ? body.customer_code.trim() : "";

          if (!fichaId) return Response.json({ message: "Ficha inválida." }, { status: 400 });
          if (code.length > 100) return Response.json({ message: "Código do cliente muito longo." }, { status: 400 });

          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

          const {
            data: { user: requester },
            error: authError,
          } = await supabaseAdmin.auth.getUser(token);

          if (authError || !requester) {
            return Response.json({ message: "Sessão inválida ou expirada." }, { status: 401 });
          }

          const { data: roleRow, error: roleError } = await supabaseAdmin
            .from("user_roles")
            .select("user_id")
            .eq("user_id", requester.id)
            .eq("role", "admin")
            .maybeSingle();

          if (roleError) throw roleError;
          if (!roleRow) {
            return Response.json({ message: "Apenas administradores podem alterar o código do cliente." }, { status: 403 });
          }

          const { data: ficha, error: fichaError } = await supabaseAdmin
            .from("fichas")
            .select("id, customer")
            .eq("id", fichaId)
            .maybeSingle();

          if (fichaError) throw fichaError;
          if (!ficha) return Response.json({ message: "Ficha não encontrada." }, { status: 404 });

          const customerName = ficha.customer.trim();
          if (!customerName) return Response.json({ message: "A ficha não possui cliente identificado." }, { status: 400 });

          const normalizedCode = code || null;

          const { data: affectedFichas, error: affectedReadError } = await supabaseAdmin
            .from("fichas")
            .select("id, external_order_id, pdd_id, customer_code, codigo_cliente")
            .ilike("customer", customerName);

          if (affectedReadError) throw affectedReadError;

          const oldCodes = new Map(
            (affectedFichas ?? []).map((row) => [
              row.id,
              row.customer_code?.trim() || row.codigo_cliente?.trim() || null,
            ]),
          );

          const { data: masters, error: masterReadError } = await supabaseAdmin
            .from("clientes")
            .select("id")
            .ilike("nome", customerName);

          if (masterReadError) throw masterReadError;

          if ((masters ?? []).length === 0) {
            const { error: insertError } = await supabaseAdmin
              .from("clientes")
              .insert({
                nome: customerName,
                codigo_cliente: normalizedCode,
                ativo: true,
              });

            if (insertError) throw insertError;
          } else {
            const { error: masterUpdateError } = await supabaseAdmin
              .from("clientes")
              .update({ codigo_cliente: normalizedCode })
              .ilike("nome", customerName);

            if (masterUpdateError) throw masterUpdateError;
          }

          const { error: fichasError } = await supabaseAdmin
            .from("fichas")
            .update({
              customer_code: normalizedCode,
              codigo_cliente: normalizedCode,
            })
            .ilike("customer", customerName);

          if (fichasError) throw fichasError;

          const actorLabel = requester.user_metadata?.full_name?.trim()
            || requester.email
            || "Usuário administrativo";

          const auditRows = (affectedFichas ?? [])
            .filter((row) => oldCodes.get(row.id) !== normalizedCode)
            .map((row) => ({
              ficha_id: row.id,
              external_order_id: row.external_order_id ?? row.pdd_id ?? null,
              sync_run_id: null,
              field_name: "customer_code",
              field_label: "Código do cliente",
              old_value: oldCodes.get(row.id),
              new_value: normalizedCode,
              change_type: "ADMIN_UPDATE",
              source: "KANBAN_ADMIN",
              actor_type: "USER",
              actor_label: actorLabel,
              item_line_no: null,
              change_key: crypto.randomUUID(),
              metadata: {
                audit: "ficha",
                manual_action: "customer_code",
                actor_user_id: requester.id,
              },
            }));

          if (auditRows.length) {
            const { error: auditError } = await supabaseAdmin
              .from("smb_admin_changes")
              .insert(auditRows);

            if (auditError) throw auditError;
          }

          return Response.json({
            saved: true,
            customer: customerName,
            customer_code: normalizedCode,
            propagated: true,
          });
        } catch (error) {
          console.error("[admin/customer-code] update failed", error);
          return Response.json(
            { message: error instanceof Error ? error.message : "Erro inesperado ao atualizar o código do cliente." },
            { status: 500 },
          );
        }
      },
    },
  },
});
