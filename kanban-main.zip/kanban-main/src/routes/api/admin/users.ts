import { createFileRoute } from "@tanstack/react-router";

const ALLOWED_ROLES = ["admin", "supervisor", "operator", "viewer"] as const;
type AppRole = (typeof ALLOWED_ROLES)[number];

type CreateUserBody = {
  full_name?: unknown;
  email?: unknown;
  password?: unknown;
  role?: unknown;
};

function isRole(value: unknown): value is AppRole {
  return typeof value === "string" && (ALLOWED_ROLES as readonly string[]).includes(value);
}

export const Route = createFileRoute("/api/admin/users")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const authorization = request.headers.get("Authorization");
          const token = authorization?.startsWith("Bearer ")
            ? authorization.slice("Bearer ".length).trim()
            : "";

          if (!token) {
            return Response.json({ message: "Sessão não encontrada." }, { status: 401 });
          }

          const body = (await request.json().catch(() => ({}))) as CreateUserBody;
          const fullName = typeof body.full_name === "string" ? body.full_name.trim() : "";
          const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
          const password = typeof body.password === "string" ? body.password : "";
          const role = body.role;

          if (!fullName || fullName.length < 2) {
            return Response.json({ message: "Informe o nome completo do usuário." }, { status: 400 });
          }

          if (!email || !email.includes("@")) {
            return Response.json({ message: "Informe um e-mail válido." }, { status: 400 });
          }

          if (password.length < 8) {
            return Response.json({ message: "A senha deve ter pelo menos 8 caracteres." }, { status: 400 });
          }

          if (!isRole(role)) {
            return Response.json({ message: "Perfil de usuário inválido." }, { status: 400 });
          }

          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

          const {
            data: { user: requester },
            error: requesterError,
          } = await supabaseAdmin.auth.getUser(token);

          if (requesterError || !requester) {
            return Response.json({ message: "Sessão inválida ou expirada." }, { status: 401 });
          }

          const { data: adminRole, error: adminRoleError } = await supabaseAdmin
            .from("user_roles")
            .select("user_id")
            .eq("user_id", requester.id)
            .eq("role", "admin")
            .maybeSingle();

          if (adminRoleError) throw adminRoleError;
          if (!adminRole) {
            return Response.json(
              { message: "Apenas administradores podem criar usuários." },
              { status: 403 },
            );
          }

          const {
            data: created,
            error: createError,
          } = await supabaseAdmin.auth.admin.createUser({
            email,
            password,
            email_confirm: true,
            user_metadata: { full_name: fullName },
          });

          if (createError || !created.user) {
            const message = createError?.message ?? "Não foi possível criar o usuário.";
            const normalized = message.toLowerCase();
            if (normalized.includes("already") || normalized.includes("registered") || normalized.includes("duplicate")) {
              return Response.json({ message: "Já existe um usuário com este e-mail." }, { status: 409 });
            }
            return Response.json({ message }, { status: 400 });
          }

          const userId = created.user.id;

          try {
            const { error: profileError } = await supabaseAdmin
              .from("profiles")
              .upsert(
                {
                  id: userId,
                  full_name: fullName,
                  email,
                  active: true,
                },
                { onConflict: "id" },
              );

            if (profileError) throw profileError;

            const { error: rolesDeleteError } = await supabaseAdmin
              .from("user_roles")
              .delete()
              .eq("user_id", userId);

            if (rolesDeleteError) throw rolesDeleteError;

            const { error: roleInsertError } = await supabaseAdmin
              .from("user_roles")
              .insert({ user_id: userId, role });

            if (roleInsertError) throw roleInsertError;
          } catch (error) {
            await supabaseAdmin.auth.admin.deleteUser(userId);
            throw error;
          }

          return Response.json({
            created: true,
            user_id: userId,
            role,
          });
        } catch (error) {
          console.error("[admin/users] create failed", error);
          return Response.json(
            { message: error instanceof Error ? error.message : "Erro inesperado ao criar usuário." },
            { status: 500 },
          );
        }
      },
    },
  },
});
