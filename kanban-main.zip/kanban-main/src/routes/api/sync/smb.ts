import { createFileRoute } from "@tanstack/react-router";

type Body = { trigger?: "manual" | "automatic" };

export const Route = createFileRoute("/api/sync/smb")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const { authenticateUser, createSyncRun, isTestModeActive } = await import("@/lib/smb-sync.server");
          const body = (await request.json().catch(() => ({}))) as Body;
          const trigger = body.trigger ?? "manual";

          if (trigger !== "manual" && trigger !== "automatic") {
            return Response.json({ message: "Trigger de sincronização inválido." }, { status: 400 });
          }

          const userId = await authenticateUser(request);

          if (await isTestModeActive()) {
            return Response.json(
              { message: "A sincronização SMB fica bloqueada durante o Modo Teste." },
              { status: 409 },
            );
          }

          let run: { id: string; status: string; trigger_type?: string | null };
          try {
            run = await createSyncRun(trigger, userId);
          } catch (error) {
            if (
              error &&
              typeof error === "object" &&
              "code" in error &&
              (error as { code?: string }).code === "SYNC_BUSY"
            ) {
              return Response.json(
                {
                  message: "Já existe uma sincronização aguardando processamento ou em andamento.",
                  sync_run_id: (error as { runId?: string }).runId ?? null,
                },
                { status: 409 },
              );
            }
            throw error;
          }

          return Response.json(
            {
              accepted: true,
              sync_run_id: run.id,
              status: run.status,
              transport: "supabase-queue",
              message: "Solicitação registrada no Supabase. Aguardando o robô SMB.",
            },
            { status: 202 },
          );
        } catch (error) {
          return Response.json(
            {
              message:
                error instanceof Error
                  ? error.message
                  : "Erro inesperado ao solicitar sincronização.",
            },
            { status: 500 },
          );
        }
      },
    },
  },
});
