import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/sync/smb/result")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const apiKey = process.env.SMB_ROBOT_API_KEY?.trim();
          if (!apiKey) return Response.json({ message: "SMB_ROBOT_API_KEY não configurada no servidor." }, { status: 503 });

          if (request.headers.get("authorization") !== "Bearer " + apiKey) {
            return Response.json({ message: "Não autorizado." }, { status: 401 });
          }

          const body = (await request.json()) as { sync_run_id?: string };
          const runId = body.sync_run_id?.trim();
          if (!runId) return Response.json({ message: "sync_run_id é obrigatório." }, { status: 400 });

          if (request.headers.get("x-sync-run-id") && request.headers.get("x-sync-run-id") !== runId) {
            return Response.json({ message: "X-Sync-Run-Id incompatível." }, { status: 400 });
          }

          const { processRobotResult } = await import("@/lib/smb-sync.server");
          const result = await processRobotResult(runId, body as never);
          return Response.json(result, { status: 200 });
        } catch (error) {
          return Response.json({ message: error instanceof Error ? error.message : "Erro ao processar resultado do robô." }, { status: 500 });
        }
      },
    },
  },
});
