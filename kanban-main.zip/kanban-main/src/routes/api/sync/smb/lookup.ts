import { createFileRoute } from "@tanstack/react-router";

type Body = { pdd_id?: string };

export const Route = createFileRoute("/api/sync/smb/lookup")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const { authenticateUser, lookupSmbOrder } = await import("@/lib/smb-sync.server");
          const body = (await request.json().catch(() => ({}))) as Body;
          const pddId = body.pdd_id?.trim();

          if (!pddId || !/^\d{1,30}$/.test(pddId)) {
            return Response.json({ message: "Informe um pdd_id SMB válido." }, { status: 400 });
          }

          const authorization = request.headers.get("authorization");
          const accessToken = authorization?.startsWith("Bearer ")
            ? authorization.slice(7).trim()
            : "";
          const userId = await authenticateUser(request);
          try {
            return Response.json(
              await lookupSmbOrder(pddId, userId, accessToken),
              { status: 200 },
            );
          } catch (error) {
            const code = error && typeof error === "object" && "code" in error
              ? (error as { code?: string }).code
              : undefined;
            const status = code === "ORDER_NOT_FOUND" ? 404
              : code === "ROBOT_UNAVAILABLE" ? 503
              : code === "ROBOT_ERROR" ? 502
              : 400;
            return Response.json({
              message: error instanceof Error ? error.message : "Não foi possível consultar o SMB.",
              code,
            }, { status });
          }
        } catch (error) {
          return Response.json({
            message: error instanceof Error ? error.message : "Erro inesperado ao consultar o SMB.",
          }, { status: 500 });
        }
      },
    },
  },
});
