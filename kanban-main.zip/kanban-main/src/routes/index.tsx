import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Factory, ShieldCheck, History, Radio } from "lucide-react";
import { Brand } from "@/components/app/Brand";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PEDIFLOW — Sistema de Kanban de Pedidos · v1.0.1" },
      { name: "description", content: "Quadro de produção com etapas configuráveis, histórico auditado e sincronização somente leitura com o SMB." },
      { property: "og:title", content: "PEDIFLOW — Sistema de Kanban de Pedidos · v1.0.1" },
      { property: "og:description", content: "Quadro de produção com histórico auditado e etapas configuráveis." },
    ],
  }),
  component: Index,
});

function Index() {
  const { session, loading } = useAuth();
  const navigate = useNavigate();
  useEffect(() => {
    if (!loading && session) navigate({ to: "/quadro", replace: true });
  }, [loading, session, navigate]);

  const features = [
    { icon: Factory, t: "Setores e etapas configuráveis", d: "Cada setor com seu próprio fluxo." },
    { icon: History, t: "Histórico imutável", d: "Toda mudança registra quem, quando e de onde para onde." },
    { icon: Radio, t: "Tempo real", d: "O quadro se atualiza para toda a equipe." },
    { icon: ShieldCheck, t: "SMB somente leitura", d: "O sistema original nunca é alterado." },
  ];

  return (
    <div className="min-h-screen bg-chrome text-chrome-foreground">
      <div className="hazard-stripe h-2" />
      <main className="mx-auto flex max-w-5xl flex-col gap-12 px-5 py-12 sm:px-6 sm:py-20">
        <div className="flex items-center">
          <Link to="/" aria-label="Ir para a homepage">
            <Brand variant="full" className="w-fit rounded-xl bg-white p-3" priority />
          </Link>
        </div>
        <div className="max-w-2xl">
          <h1 className="text-4xl font-extrabold leading-tight md:text-6xl">
            Cada ficha, cada etapa, <span className="text-primary">rastreada.</span>
          </h1>
          <p className="mt-5 text-lg text-chrome-muted">
            A camada operacional da fábrica: acompanhe pedidos do SMB pelas etapas de produção com
            auditoria completa de cada movimentação.
          </p>
          <Button asChild size="lg" className="mt-8">
            <Link to="/auth">Entrar no sistema</Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div key={f.t} className="rounded-lg border border-sidebar-border bg-sidebar-accent p-5">
              <f.icon className="size-5 text-primary" />
              <h3 className="mt-3 font-semibold">{f.t}</h3>
              <p className="mt-1 text-sm text-chrome-muted">{f.d}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
