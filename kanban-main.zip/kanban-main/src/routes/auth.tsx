import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { Loader2, ShieldCheck, History, Radio, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brand } from "@/components/app/Brand";
import { z } from "zod";
import { recoveryRedirectUrl } from "@/lib/auth-redirects";

const searchSchema = z.object({ mode: z.enum(["recovery"]).optional() });

function translateAuthError(error: { code?: string; status?: number; message?: string } | null): string {
  if (!error) return "";
  switch (error.code) {
    case "invalid_credentials":
      return "E-mail ou senha incorretos.";
    case "email_not_confirmed":
      return "Seu e-mail ainda não foi confirmado. Confira sua caixa de entrada ou solicite um novo e-mail de confirmação.";
    case "email_address_invalid":
      return "O endereço de e-mail informado é inválido.";
    case "email_address_not_authorized":
      return "O envio de e-mail não está autorizado para este endereço.";
    case "too_many_requests":
    case "over_request_rate_limit":
    case "over_email_send_rate_limit":
      return "O envio de e-mails de autenticação atingiu o limite temporário do Supabase. Aguarde alguns minutos e tente novamente.";
    case "user_banned":
      return "Este usuário está bloqueado. Procure a administração.";
    case "weak_password":
      return "A senha informada é muito fraca. Escolha uma senha mais segura.";
    case "email_exists":
      return "Este e-mail já está cadastrado.";
    default:
      if (error.status === 429) return "O serviço de recuperação bloqueou novas solicitações temporariamente. Aguarde alguns minutos e tente novamente.";
      return error.message || "Não foi possível concluir a operação. Tente novamente.";
  }
}

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Entrar — PEDIFLOW" },
      { name: "description", content: "Acesse o quadro de produção da fábrica." },
      { property: "og:title", content: "Entrar — PEDIFLOW" },
      { property: "og:description", content: "Acesse o quadro de produção da fábrica." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { mode } = Route.useSearch();
  const { session } = useAuth();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [recoveryMode, setRecoveryMode] = useState(mode === "recovery");
  const [recoveryReady, setRecoveryReady] = useState(false);
  const [recoveryRequested, setRecoveryRequested] = useState(false);
  const [recoveryEmail, setRecoveryEmail] = useState("");
  const showRecovery = mode === "recovery" || recoveryMode;
  const loginFormRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((event, currentSession) => {
      if (event === "PASSWORD_RECOVERY") {
        setRecoveryMode(true);
        setRecoveryReady(!!currentSession);
        return;
      }
      if (currentSession && !showRecovery) navigate({ to: "/quadro", replace: true });
    });

    if (mode === "recovery") {
      supabase.auth.getSession().then(({ data }) => {
        setRecoveryMode(true);
        setRecoveryReady(!!data.session);
      });
    }

    return () => sub.subscription.unsubscribe();
  }, [mode, navigate, showRecovery]);

  useEffect(() => {
    if (session && !showRecovery) navigate({ to: "/quadro", replace: true });
  }, [session, showRecovery, navigate]);

  async function signIn(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({
      email: String(f.get("email")).trim(),
      password: String(f.get("password")),
    });
    setBusy(false);
    if (error) toast.error(translateAuthError(error));
  }

  async function requestRecovery(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const email = String(f.get("recovery_email") ?? "").trim().toLowerCase();
    if (!email) return toast.error("Informe o e-mail para recuperação.");
    setBusy(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: recoveryRedirectUrl(window.location.origin),
    });
    setBusy(false);
    if (error) return toast.error(translateAuthError(error));
    setRecoveryEmail(email);
    setRecoveryRequested(true);
    toast.success("Solicitação registrada. Verifique o e-mail informado para continuar.");
  }

  async function updatePassword(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const password = String(f.get("password"));
    const confirmation = String(f.get("password_confirmation"));
    if (password.length < 8) return toast.error("A senha deve ter pelo menos 8 caracteres.");
    if (password !== confirmation) return toast.error("As senhas não conferem.");

    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) return toast.error(translateAuthError(error));

    await supabase.auth.signOut();
    setRecoveryMode(false);
    setRecoveryReady(false);
    setRecoveryRequested(false);
    setRecoveryEmail("");
    toast.success("Senha redefinida. Entre com sua nova senha.");
    navigate({ to: "/auth", search: {}, replace: true });
  }

  return (
    <div className="grid min-h-screen bg-background lg:grid-cols-2">
      <div className="relative hidden flex-col justify-between bg-chrome p-10 text-chrome-foreground lg:flex">
        <div className="hazard-stripe absolute inset-x-0 top-0 h-2" />
        <Link to="/" aria-label="Ir para a homepage" className="w-fit">
          <Brand variant="full" className="w-fit rounded-xl bg-white p-2" priority />
        </Link>
        <div className="max-w-md space-y-6">
          <div className="flex items-center gap-3 text-sm text-chrome-muted"><ShieldCheck className="size-4 text-primary" /> Fluxo operacional com rastreabilidade</div>
          <div className="grid grid-cols-2 gap-3 text-xs text-chrome-muted">
            <div className="rounded-xl border border-sidebar-border bg-sidebar-accent p-3"><History className="size-4 text-primary" /><p className="mt-2 font-semibold text-chrome-foreground">Histórico auditado</p></div>
            <div className="rounded-xl border border-sidebar-border bg-sidebar-accent p-3"><Radio className="size-4 text-primary" /><p className="mt-2 font-semibold text-chrome-foreground">Atualização em tempo real</p></div>
          </div>
          <p className="text-sm leading-6 text-chrome-muted">Toda mudança de etapa exige ficha, responsável e destino, mantendo o fluxo da produção organizado.</p>
        </div>
      </div>

      <div className="flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-lg">
          <div className="mb-5 overflow-hidden rounded-2xl border bg-gradient-to-br from-primary via-primary/90 to-accent shadow-card">
            <div className="flex min-h-28 flex-col justify-between gap-4 p-5 text-primary-foreground sm:min-h-32 sm:p-6">
              <div className="flex items-center gap-3">
                <Link to="/" aria-label="Ir para a homepage" className="shrink-0">
                  <Brand variant="icon" className="h-11 w-11 shrink-0 rounded-xl bg-white p-1.5" priority />
                </Link>
                <div className="min-w-0">
                  <p className="font-display text-lg font-extrabold tracking-tight">PEDIFLOW</p>
                  <p className="text-xs text-primary-foreground/80">Controle e acompanhamento da produção</p>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-2 text-[11px] sm:grid-cols-3">
                <span className="rounded-lg bg-white/10 px-3 py-2">Kanban em tempo real</span>
                <span className="rounded-lg bg-white/10 px-3 py-2">Histórico e rastreabilidade</span>
                <span className="rounded-lg bg-white/10 px-3 py-2">Funciona em celular, tablet e computador</span>
              </div>
            </div>
          </div>

          <div className="mb-6 flex justify-center lg:hidden">
            <Link to="/" aria-label="Ir para a homepage" className="w-full max-w-[260px]">
              <Brand variant="full" className="w-full max-w-[260px]" />
            </Link>
          </div>

          {showRecovery ? (
            <div>
              <Button
                type="button"
                variant="ghost"
                className="-ml-3 mb-3"
                onClick={() => {
                  setRecoveryMode(false);
                  setRecoveryReady(false);
                  setRecoveryRequested(false);
                  setRecoveryEmail("");
                  navigate({ to: "/auth", search: {}, replace: true });
                }}
              >
                Voltar para entrar
              </Button>
              <h1 className="text-2xl font-bold sm:text-3xl">
                {recoveryReady ? "Definir nova senha" : "Recuperar senha"}
              </h1>
              <p className="mt-1 text-sm text-muted-foreground">
                {recoveryReady
                  ? "Escolha uma nova senha para acessar o PEDIFLOW."
                  : "Informe o e-mail da pessoa que precisa recuperar o acesso."}
              </p>
              {recoveryReady ? (
                <form onSubmit={updatePassword} className="mt-6 space-y-4">
                  <Field id="password" label="Nova senha (mín. 8 caracteres)" type="password" />
                  <Field id="password_confirmation" label="Confirmar nova senha" type="password" />
                  <Button type="submit" className="w-full" disabled={busy}>
                    {busy && <Loader2 className="size-4 animate-spin" />} Salvar nova senha
                  </Button>
                </form>
              ) : (
                <div className="mt-6 space-y-4">
                  <form onSubmit={requestRecovery} className="space-y-4">
                    <Field id="recovery_email" label="E-mail para recuperação" type="email" />
                    <Button type="submit" className="w-full" disabled={busy}>
                      {busy && <Loader2 className="size-4 animate-spin" />} Enviar e-mail de recuperação
                    </Button>
                  </form>
                  {recoveryRequested && (
                    <div className="rounded-xl border bg-accent p-4 text-sm text-accent-foreground">
                      <p className="font-semibold">Solicitação enviada</p>
                      <p className="mt-1">
                        Enviamos as instruções para <strong>{recoveryEmail}</strong>, caso esse endereço esteja cadastrado.
                        Verifique também spam/lixo eletrônico.
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <>
              <h1 className="text-2xl font-bold sm:text-3xl">Acesso ao sistema</h1>
              <p className="mt-1 text-sm text-muted-foreground">Entre para acessar o PEDIFLOW.</p>
              <Tabs defaultValue="login" className="mt-6">
                <TabsList className="grid w-full grid-cols-1">
                  <TabsTrigger value="login">Entrar</TabsTrigger>
                </TabsList>

                <TabsContent value="login">
                  <form ref={loginFormRef} onSubmit={signIn} className="mt-4 space-y-4">
                    <Field id="email" label="E-mail" type="email" />
                    <Field id="password" label="Senha" type="password" />
                    <div className="flex justify-end">
                      <button
                        type="button"
                        className="text-sm font-medium text-primary underline-offset-4 hover:underline"
                        onClick={() => {
                          setRecoveryMode(true);
                          navigate({ to: "/auth", search: { mode: "recovery" } });
                        }}
                      >
                        Esqueci minha senha
                      </button>
                    </div>
                    <Button type="submit" className="w-full" disabled={busy}>
                      {busy && <Loader2 className="size-4 animate-spin" />} Entrar
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({ id, label, type }: { id: string; label: string; type: string }) {
  const [visible, setVisible] = useState(false);
  const password = type === "password";
  const inputType = password && visible ? "text" : type;

  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <Input id={id} name={id} type={inputType} required className={password ? "pr-11" : undefined} />
        {password && (
          <button
            type="button"
            onClick={() => setVisible((current) => !current)}
            aria-label={visible ? "Ocultar senha" : "Mostrar senha"}
            title={visible ? "Ocultar senha" : "Mostrar senha"}
            className="absolute inset-y-0 right-0 grid w-11 place-items-center text-muted-foreground hover:text-foreground"
          >
            {visible ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
          </button>
        )}
      </div>
    </div>
  );
}
