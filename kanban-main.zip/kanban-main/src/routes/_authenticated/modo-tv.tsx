import { createFileRoute } from "@tanstack/react-router";
import { ModoTvPage } from "@/components/app/ModoTv";

export const Route = createFileRoute("/_authenticated/modo-tv")({
  head: () => ({
    meta: [
      { title: "Modo TV — PEDIFLOW" },
      { name: "description", content: "Programação visual das saídas e indicadores de produção." },
    ],
  }),
  component: ModoTvPage,
});
