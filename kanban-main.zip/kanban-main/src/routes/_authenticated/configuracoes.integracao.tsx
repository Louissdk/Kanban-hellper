import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Fragment, useEffect, useState, type ReactNode } from "react";
import { Clock3, Link2, Lock, RefreshCw, ShieldCheck, Wifi, WifiOff } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { settingsQuery, fmtSyncDateTime, errMsg } from "@/lib/data";
import { PageHeader } from "@/components/app/AppShell";
import { SmbSyncButton } from "@/components/app/SmbSyncButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";

export const Route = createFileRoute("/_authenticated/configuracoes/integracao")({
  head: () => ({
    meta: [
      { title: "Integração SMB — PEDIFLOW" },
      { name: "description", content: "Monitoramento da integração somente leitura entre PEDIFLOW e SMB." },
    ],
  }),
  component: IntegracaoPage,
});

const STATUS: Record<string, { label: string; cls: string }> = {
  requested: { label: "Sincronização solicitada", cls: "bg-info text-info-foreground" },
  running: { label: "Sincronizando...", cls: "bg-warning text-warning-foreground" },
  success: { label: "Sincronizado", cls: "bg-success text-success-foreground" },
  partial: { label: "Sincronizado com avisos", cls: "bg-warning text-warning-foreground" },
  failed: { label: "Erro na sincronização", cls: "bg-destructive text-destructive-foreground" },
};

type SyncSettings = { enabled: boolean; interval_minutes: number };

function IntegracaoPage() {
  const { isAdmin } = useAuth();
  const qc = useQueryClient();
  const { data: settings } = useQuery(settingsQuery);

  const { data: runs = [] } = useQuery({
    queryKey: ["sync", "runs"],
    queryFn: async () => {
      const { data, error } = await supabase.from("sync_runs").select("*").order("created_at", { ascending: false }).limit(30);
      if (error) throw new Error(error.message);
      return data ?? [];
    },
    refetchInterval: 5000,
  });

  const sync = (settings?.sync ?? { enabled: true, interval_minutes: 30 }) as SyncSettings;
  const [enabled, setEnabled] = useState(sync.enabled);
  const [interval, setIntervalValue] = useState(sync.interval_minutes);
  const [robotUrl, setRobotUrl] = useState(typeof settings?.smb_robot_url === "string" ? settings.smb_robot_url : "");
  const [openRun, setOpenRun] = useState<string | null>(null);

  useEffect(() => setEnabled(sync.enabled), [sync.enabled]);
  useEffect(() => setIntervalValue(sync.interval_minutes), [sync.interval_minutes]);
  useEffect(() => setRobotUrl(typeof settings?.smb_robot_url === "string" ? settings.smb_robot_url : ""), [settings?.smb_robot_url]);

  const { data: errors = [] } = useQuery({
    queryKey: ["sync", "errors", openRun],
    enabled: !!openRun,
    queryFn: async () => {
      const { data, error } = await supabase.from("sync_errors").select("*").eq("sync_run_id", openRun!).order("created_at");
      if (error) throw new Error(error.message);
      return data ?? [];
    },
  });

  useEffect(() => {
    const channel = supabase
      .channel("sync-runs-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "sync_runs" }, () => {
        void qc.invalidateQueries({ queryKey: ["sync"] });
      })
      .subscribe();

    return () => { void supabase.removeChannel(channel); };
  }, [qc]);

  const last = runs[0];
  const lastSuccess = runs.find((run) => run.status === "success" || run.status === "partial");
  const pending = runs.some((run) => run.status === "requested" || run.status === "running");
  const nextAt = lastSuccess?.finished_at
    ? new Date(new Date(lastSuccess.finished_at).getTime() + sync.interval_minutes * 60000).toISOString()
    : null;
  const robotUnavailable = last?.robot_status === "unavailable";

  async function saveSettings() {
    if (!Number.isInteger(interval) || interval < 5) {
      toast.error("O intervalo mínimo é de 5 minutos.");
      return;
    }
    if (robotUrl.trim() && !/^https?:\/\//i.test(robotUrl.trim())) {
      toast.error("A URL do robô deve começar com http:// ou https://.");
      return;
    }

    const [syncResult, urlResult] = await Promise.all([
      supabase.from("system_settings").upsert({
        key: "sync",
        value: { enabled, interval_minutes: interval },
      }),
      supabase.from("system_settings").upsert({
        key: "smb_robot_url",
        value: robotUrl.trim(),
      }),
    ]);

    const failure = syncResult.error ?? urlResult.error;
    if (failure) {
      toast.error(errMsg(failure));
      return;
    }

    toast.success("Configurações de sincronização salvas.");
    void qc.invalidateQueries({ queryKey: ["settings"] });
  }

  return (
    <div>
      <PageHeader
        title="Integração SMB"
        description="Leitura controlada do SMB sem nenhuma escrita no sistema original."
        actions={<SmbSyncButton />}
      />

      <div className="mx-auto w-full max-w-[1500px] space-y-5 p-3 sm:p-4 md:p-6">
        <section className="flex items-start gap-3 rounded-2xl border border-info/40 bg-info/10 p-4 shadow-card">
          {robotUnavailable
            ? <WifiOff className="mt-0.5 size-5 shrink-0 text-destructive" />
            : <ShieldCheck className="mt-0.5 size-5 shrink-0 text-info" />}
          <div>
            <p className="font-semibold">{robotUnavailable ? "Robô indisponível" : "SMB em modo somente leitura"}</p>
            <p className="mt-1 text-sm text-muted-foreground">
              O navegador nunca acessa o SMB. O serviço de integração é responsável pela autenticação e leitura, e o PEDIFLOW recebe apenas os dados processados.
            </p>
          </div>
        </section>

        <section className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-5">
          <Stat icon={robotUnavailable ? <WifiOff className="size-4" /> : <Wifi className="size-4" />}
            label="Robô"
            value={robotUnavailable ? "Indisponível" : last?.robot_status === "available" ? "Disponível" : robotUrl ? "Configurado" : "Aguardando serviço"} />
          <Stat icon={<Clock3 className="size-4" />} label="Última sincronização" value={fmtSyncDateTime(last?.finished_at ?? last?.started_at)} />
          <Stat icon={<Clock3 className="size-4" />} label="Próxima automática" value={sync.enabled ? fmtSyncDateTime(nextAt) : "Desativada"} />
          <Stat icon={<RefreshCw className="size-4" />} label="Status atual" value={pending ? "Em andamento" : STATUS[last?.status]?.label ?? "Aguardando"} />
          <Stat label="Pedidos analisados" value={String(last?.orders_scanned ?? last?.total_read ?? 0)} />
          <Stat label="Elegíveis" value={String(last?.orders_eligible ?? 0)} />
          <Stat label="Novos" value={String(last?.orders_created ?? last?.inserted ?? 0)} />
          <Stat label="Atualizados" value={String(last?.orders_updated ?? last?.updated ?? 0)} />
          <Stat label="Ignorados" value={String(last?.orders_ignored ?? last?.skipped ?? 0)} />
          <Stat label="Erros" value={String(last?.errors_count ?? last?.errors ?? 0)} tone="danger" />
        </section>

        {isAdmin && (
          <section className="rounded-2xl border bg-card p-4 shadow-card sm:p-5">
            <div className="flex items-center gap-2"><Link2 className="size-4 text-primary" /><h2 className="font-semibold">Serviço do robô</h2></div>
            <p className="mt-1 text-xs text-muted-foreground">
              A URL identifica o serviço HTTP que pode receber uma solicitação manual. A chave do robô não é armazenada nesta tela e permanece somente em variável de ambiente do servidor.
            </p>
            <div className="mt-4 grid gap-4 lg:grid-cols-[minmax(0,1fr)_auto_auto] lg:items-end">
              <div className="min-w-0">
                <Label htmlFor="robot-url">URL do robô</Label>
                <Input id="robot-url" value={robotUrl} onChange={(e) => setRobotUrl(e.target.value)} placeholder="Deixe vazio para usar a fila Supabase/worker" className="mt-1.5" />
              </div>
              <div>
                <Label htmlFor="interval">Intervalo (minutos)</Label>
                <Input id="interval" type="number" min={5} value={interval} onChange={(e) => setIntervalValue(Number(e.target.value))} className="mt-1.5 w-full lg:w-36" />
              </div>
              <label className="flex min-h-10 items-center justify-between gap-4 rounded-lg border px-3 text-sm">
                <span>Sincronização automática</span>
                <Switch checked={enabled} onCheckedChange={setEnabled} />
              </label>
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-3">
              <Button onClick={saveSettings}>Salvar configuração</Button>
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground"><Lock className="size-3.5" /> SMB_USERNAME e SMB_PASSWORD ficam somente no worker.</span>
            </div>
          </section>
        )}

        <section className="overflow-hidden rounded-2xl border bg-card shadow-card">
          <div className="border-b px-4 py-4 sm:px-5">
            <h2 className="font-semibold">Histórico de sincronizações</h2>
            <p className="mt-0.5 text-xs text-muted-foreground">As execuções não são apagadas. Abra uma linha para consultar os erros registrados.</p>
          </div>

          {runs.length === 0 ? (
            <p className="p-8 text-center text-sm text-muted-foreground">Nenhuma execução registrada ainda.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="data-table min-w-[1040px] text-sm">
                <thead className="bg-muted text-left text-xs uppercase text-muted-foreground">
                  <tr>
                    <th>Início</th>
                    <th>Fim</th>
                    <th>Status</th>
                    <th>Origem</th>
                    <th className="text-right">Analisados</th>
                    <th className="text-right">Elegíveis</th>
                    <th className="text-right">Novos</th>
                    <th className="text-right">Atualizados</th>
                    <th className="text-right">Ignorados</th>
                    <th className="pr-3 text-right">Erros</th>
                  </tr>
                </thead>
                <tbody>
                  {runs.map((run) => {
                    const status = STATUS[run.status];
                    const expanded = openRun === run.id;
                    return (
                      <Fragment key={run.id}>
                        <tr className="cursor-pointer border-t hover:bg-muted/50" onClick={() => setOpenRun(expanded ? null : run.id)}>
                          <td className="p-3">{fmtSyncDateTime(run.started_at ?? run.created_at)}</td>
                          <td>{fmtSyncDateTime(run.finished_at)}</td>
                          <td><Badge className={status?.cls}>{status?.label ?? run.status}</Badge></td>
                          <td>{(run.trigger_type ?? run.trigger) === "manual" || run.trigger_type === "manual_button" ? "Manual" : "Automática"}</td>
                          <td className="text-right">{run.orders_scanned ?? run.total_read}</td>
                          <td className="text-right">{run.orders_eligible ?? 0}</td>
                          <td className="text-right">{run.orders_created ?? run.inserted}</td>
                          <td className="text-right">{run.orders_updated ?? run.updated}</td>
                          <td className="text-right">{run.orders_ignored ?? run.skipped}</td>
                          <td className="pr-3 text-right">{run.errors_count ?? run.errors}</td>
                        </tr>
                        {expanded && (
                          <tr className="bg-muted/30">
                            <td colSpan={10} className="p-4 text-xs">
                              {run.error_message || run.error_details
                                ? <p className="mb-3 whitespace-pre-wrap text-destructive">{run.error_message ?? run.error_details}</p>
                                : null}
                              {errors.length === 0 ? (
                                <p className="text-muted-foreground">Sem erros detalhados nesta execução.</p>
                              ) : (
                                <div className="space-y-2">
                                  {errors.map((error) => (
                                    <div key={error.id} className="rounded-lg border bg-background p-2.5">
                                      <div className="flex flex-wrap items-center gap-2">
                                        <Badge variant={error.level === "error" ? "destructive" : "secondary"}>{error.level === "error" ? "Erro" : "Aviso"}</Badge>
                                        {error.external_order_id && <span className="font-mono">pdd_id {error.external_order_id}</span>}
                                        <span className="text-muted-foreground">{fmtSyncDateTime(error.occurred_at ?? error.created_at)}</span>
                                      </div>
                                      <p className="mt-1">{error.error_message ?? error.message}</p>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </td>
                          </tr>
                        )}
                      </Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

function Stat({ label, value, tone, icon }: { label: string; value: string; tone?: "danger"; icon?: ReactNode }) {
  return (
    <div className="rounded-2xl border bg-card p-3.5 shadow-card sm:p-4">
      <div className="flex items-center gap-2 text-xs uppercase tracking-wide text-muted-foreground">{icon}{label}</div>
      <p className={"mt-1.5 truncate text-lg font-bold " + (tone === "danger" ? "text-destructive" : "")}>{value}</p>
    </div>
  );
}
