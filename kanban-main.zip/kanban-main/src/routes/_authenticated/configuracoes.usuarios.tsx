import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { AdminRecordSecuritySection } from "@/components/app/AdminRecordSecuritySection";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, ROLE_LABEL, type AppRole } from "@/lib/auth";
import { profilesQuery, errMsg } from "@/lib/data";
import { PageHeader } from "@/components/app/AppShell";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Loader2, Plus } from "lucide-react";

export const Route = createFileRoute("/_authenticated/configuracoes/usuarios")({
  head: () => ({ meta: [{ title: "Usuários — Configurações" }, { name: "description", content: "Gerencie usuários e permissões." }] }),
  component: UsuariosPage,
});

const ROLES: AppRole[] = ["admin", "supervisor", "operator", "viewer"];

function firstName(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .split(/\s+/)[0]
    .toLowerCase();
}

function UsuariosPage() {
  const { isAdmin, userId } = useAuth();
  const [createOpen, setCreateOpen] = useState(false);
  const qc = useQueryClient();
  const { data: profiles = [] } = useQuery(profilesQuery);
  const { data: roles = [] } = useQuery({
    queryKey: ["all-roles"],
    queryFn: async () => (await supabase.from("user_roles").select("user_id, role")).data ?? [],
  });

  if (!isAdmin) return <div className="p-10 text-center text-muted-foreground">Apenas administradores podem gerenciar usuários.</div>;

  async function toggleRole(uid: string, role: AppRole, on: boolean) {
    if (uid === userId && role === "admin" && !on) return toast.error("Você não pode remover seu próprio acesso de administrador.");
    const { error } = on
      ? await supabase.from("user_roles").insert({ user_id: uid, role })
      : await supabase.from("user_roles").delete().eq("user_id", uid).eq("role", role);
    if (error) return toast.error(errMsg(error));
    qc.invalidateQueries({ queryKey: ["all-roles"] });
    qc.invalidateQueries({ queryKey: ["me"] });
  }
  async function toggleActive(uid: string, active: boolean) {
    const { error } = await supabase.from("profiles").update({ active }).eq("id", uid);
    if (error) return toast.error(errMsg(error));
    qc.invalidateQueries({ queryKey: ["profiles"] });
  }

  return (
    <div>
      <PageHeader
        title="Usuários"
        description="Crie contas, escolha o perfil e gerencie permissões dos usuários do sistema."
        actions={
          <Button onClick={() => setCreateOpen(true)}>
            <Plus className="size-4" />
            Novo usuário
          </Button>
        }
      />
      <div className="p-3 sm:p-4 md:p-6">
        <div className="space-y-3 md:hidden">
          {profiles.map((p) => (
            <article key={p.id} className="rounded-2xl border bg-card p-4 shadow-card">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0"><p className="truncate font-semibold">{p.full_name}</p><p className="truncate text-xs text-muted-foreground">{p.email}</p></div>
                <span className={`rounded-full px-2 py-1 text-[10px] font-bold uppercase ${p.active ? "bg-success/10 text-success" : "bg-muted text-muted-foreground"}`}>{p.active ? "Ativo" : "Inativo"}</span>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2">
                {ROLES.map((r) => {
                  const has = roles.some((x) => x.user_id === p.id && x.role === r);
                  return <label key={r} className="flex min-h-10 items-center justify-between gap-2 rounded-lg border bg-background px-3 text-xs font-medium"><span>{ROLE_LABEL[r]}</span><Checkbox checked={has} onCheckedChange={(v) => toggleRole(p.id, r, !!v)} aria-label={`${ROLE_LABEL[r]} para ${p.full_name}`} /></label>;
                })}
              </div>
              <label className="mt-3 flex min-h-10 items-center justify-between rounded-lg border bg-background px-3 text-sm"><span>Usuário ativo</span><Switch checked={p.active} disabled={p.id === userId} onCheckedChange={(v) => toggleActive(p.id, v)} /></label>
            </article>
          ))}
        </div>
        <div className="hidden overflow-x-auto md:block">
          <table className="data-table min-w-[760px] rounded-2xl border bg-card text-sm">
            <thead className="bg-muted text-left text-xs uppercase text-muted-foreground">
              <tr><th>Usuário</th>{ROLES.map((r) => <th key={r} className="text-center">{ROLE_LABEL[r]}</th>)}<th className="text-center">Ativo</th></tr>
            </thead>
            <tbody>
              {profiles.map((p) => (
                <tr key={p.id} className="border-t">
                  <td><p className="font-medium">{p.full_name}</p><p className="text-xs text-muted-foreground">{p.email}</p></td>
                  {ROLES.map((r) => {
                    const has = roles.some((x) => x.user_id === p.id && x.role === r);
                    return <td key={r} className="text-center"><Checkbox checked={has} onCheckedChange={(v) => toggleRole(p.id, r, !!v)} aria-label={`${ROLE_LABEL[r]} para ${p.full_name}`} /></td>;
                  })}
                  <td className="text-center"><Switch checked={p.active} disabled={p.id === userId} onCheckedChange={(v) => toggleActive(p.id, v)} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <CreateUserDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onCreated={() => {
          void qc.invalidateQueries({ queryKey: ["profiles"] });
          void qc.invalidateQueries({ queryKey: ["all-roles"] });
        }}
      />
      <AdminRecordSecuritySection isAdmin={isAdmin} />
    </div>
  );
}


type CreateUserDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreated: () => void;
};

function CreateUserDialog({ open, onOpenChange, onCreated }: CreateUserDialogProps) {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState<AppRole>("operator");
  const [busy, setBusy] = useState(false);

  function handleNameChange(value: string) {
    setFullName(value);
    const name = firstName(value);
    if (name === "matheu" || name === "gabrielly") setRole("admin");
  }

  function reset() {
    setFullName("");
    setEmail("");
    setPassword("");
    setConfirmPassword("");
    setRole("operator");
    setBusy(false);
  }

  function close(nextOpen: boolean) {
    if (!nextOpen && !busy) reset();
    onOpenChange(nextOpen);
  }

  async function submit() {
    const name = fullName.trim();
    const normalizedEmail = email.trim().toLowerCase();

    if (name.length < 2) return toast.error("Informe o nome completo.");
    if (!normalizedEmail.includes("@")) return toast.error("Informe um e-mail válido.");
    if (password.length < 8) return toast.error("A senha deve ter pelo menos 8 caracteres.");
    if (password !== confirmPassword) return toast.error("As senhas não conferem.");

    setBusy(true);
    try {
      const session = await supabase.auth.getSession();
      const token = session.data.session?.access_token;
      if (!token) throw new Error("Sua sessão expirou. Entre novamente no sistema.");

      const response = await fetch("/api/admin/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token,
        },
        body: JSON.stringify({
          full_name: name,
          email: normalizedEmail,
          password,
          role,
        }),
      });

      const body = (await response.json().catch(() => ({}))) as { message?: string };
      if (!response.ok) throw new Error(body.message || "Não foi possível criar o usuário.");

      const label = role === "operator" ? "Fábrica" : ROLE_LABEL[role];
      toast.success(`Usuário ${label.toLowerCase()} criado com sucesso.`);
      onCreated();
      close(false);
    } catch (error) {
      toast.error(errMsg(error));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={close}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Novo usuário</DialogTitle>
          <DialogDescription>
            Crie uma conta que poderá entrar imediatamente no sistema. O perfil define as permissões iniciais.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="new-user-name">Nome completo</Label>
            <Input
              id="new-user-name"
              value={fullName}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="Ex.: João da Silva"
              autoComplete="name"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="new-user-email">E-mail</Label>
            <Input
              id="new-user-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="usuario@empresa.com.br"
              autoComplete="email"
            />
          </div>

          <div className="space-y-1.5">
            <Label>Perfil inicial</Label>
            <Select value={role} onValueChange={(value) => setRole(value as AppRole)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="operator">Fábrica — Operador</SelectItem>
                <SelectItem value="admin">Administrativo — Administrador</SelectItem>
                <SelectItem value="supervisor">Administrativo — Supervisor</SelectItem>
                <SelectItem value="viewer">Visualizador</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Usuários de fábrica operam o quadro. Administradores gerenciam usuários e configurações.
              Para Matheu e Gabrielly, o perfil inicial é selecionado automaticamente como Administrador.
            </p>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="new-user-password">Senha</Label>
              <Input
                id="new-user-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Mínimo de 8 caracteres"
                autoComplete="new-password"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="new-user-password-confirm">Confirmar senha</Label>
              <Input
                id="new-user-password-confirm"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Repita a senha"
                autoComplete="new-password"
              />
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => close(false)} disabled={busy}>
            Cancelar
          </Button>
          <Button type="button" onClick={() => void submit()} disabled={busy}>
            {busy && <Loader2 className="size-4 animate-spin" />}
            Criar usuário
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
