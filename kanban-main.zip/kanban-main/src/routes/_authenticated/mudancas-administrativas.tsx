import { createFileRoute } from "@tanstack/react-router";
import { MudancasAdministrativasPage } from "@/components/app/MudancasAdministrativas";

export const Route = createFileRoute("/_authenticated/mudancas-administrativas")({
  head: () => ({
    meta: [
      { title: "Mudanças Administrativas — PEDIFLOW" },
      { name: "description", content: "Auditoria das alterações administrativas das fichas." },
    ],
  }),
  component: MudancasAdministrativasPage,
});
