import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { CARD_FIELDS, settingsQuery, errMsg } from "@/lib/data";
import { PageHeader } from "@/components/app/AppShell";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_authenticated/configuracoes/sistema")({
  head: () => ({ meta: [{ title: "Sistema e Cartões — Configurações" }, { name: "description", content: "Comportamento do sistema e campos dos cartões." }] }),
  component: SistemaPage,
});

function SistemaPage() {
  const { isAdmin } = useAuth();
  const qc = useQueryClient();
  const { data: settings } = useQuery(settingsQuery);
  const [fields, setFields] = useState<string[]>([]);
  const [stale, setStale] = useState(48);

  useEffect(() => {
    if (!settings) return;
    if (Array.isArray(settings.card_fields)) setFields(settings.card_fields as string[]);
    if (typeof settings.stale_hours === "number") setStale(settings.stale_hours);
  }, [settings]);

  if (!isAdmin) return <div className="p-10 text-center text-muted-foreground">Apenas administradores.</div>;

  async function save() {
    if (!Number.isFinite(stale) || stale < 1) return toast.error("Informe um número de horas válido.");
    const { error } = await supabase.from("system_settings").upsert([
      { key: "card_fields", value: fields },
      { key: "stale_hours", value: stale },
    ]);
    if (error) return toast.error(errMsg(error));
    toast.success("Configurações salvas.");
    qc.invalidateQueries({ queryKey: ["settings"] });
  }

  return (
    <div>
      <PageHeader title="Sistema e Cartões" description="Defina o que aparece nos cartões do quadro e os alertas de produção." actions={<Button onClick={save}>Salvar</Button>} />
      <div className="grid max-w-3xl gap-6 p-4 md:p-6">
        <section className="rounded-xl border bg-card p-5">
          <h2 className="mb-3 font-semibold">Campos visíveis nos cartões</h2>
          <div className="grid grid-cols-2 gap-3">
            {CARD_FIELDS.map((f) => (
              <label key={f.key} className="flex items-center gap-2 text-sm">
                <Checkbox checked={fields.includes(f.key)} onCheckedChange={(v) => setFields((cur) => (v ? [...cur, f.key] : cur.filter((x) => x !== f.key)))} />
                {f.label}
              </label>
            ))}
          </div>
          <p className="mt-3 text-xs text-muted-foreground">O número da ficha é sempre exibido.</p>
        </section>
        <section className="rounded-xl border bg-card p-5">
          <h2 className="mb-3 font-semibold">Alerta de ficha parada</h2>
          <Label htmlFor="stale">Horas na mesma etapa para sinalizar</Label>
          <Input id="stale" type="number" min={1} value={stale} onChange={(e) => setStale(Number(e.target.value))} className="mt-1.5 w-32" />
        </section>
      </div>
    </div>
  );
}
