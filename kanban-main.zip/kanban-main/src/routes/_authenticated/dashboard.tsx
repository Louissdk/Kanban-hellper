import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState, type ReactNode } from "react";
import { Activity, ArrowRight, BarChart3, CalendarRange, Download, Printer, Plus, RefreshCw, TrendingDown } from "lucide-react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { allStagesQuery, profilesQuery, sectorsQuery, fmtDate, fmtDateTime, isOverdue } from "@/lib/data";
import { PageHeader } from "@/components/app/AppShell";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ProductionLossDialog } from "@/components/app/ProductionLossDialog";
import { cn } from "@/lib/utils";

type LossRow = {
  id: string;
  ficha_id: string | null;
  order_number: string | null;
  occurrence_date: string;
  sector_id: string;
  sector_name: string;
  stage_id: string | null;
  stage_name: string | null;
  responsible_id: string;
  responsible_name: string;
  description: string;
  quantity: number;
  unit: string;
  reason_category: string;
  details: string | null;
  created_at: string;
};

function localIsoDate(date: Date) {
  const d = new Date(date);
  d.setHours(12, 0, 0, 0);
  return d.toISOString().slice(0, 10);
}

function minusDays(days: number) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return localIsoDate(d);
}

function csvCell(value: unknown) {
  return "\"" + String(value ?? "").replace(/"/g, "\"\"") + "\"";
}

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — Kanban de Produção" },
      { name: "description", content: "Indicadores de produção e perdas." },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const { data: sectors = [] } = useQuery(sectorsQuery);
  const { data: stages = [] } = useQuery(allStagesQuery);
  const { data: profiles = [] } = useQuery(profilesQuery);
  const [sectorSel, setSectorSel] = useState<string | null>(null);
  const [lossSectorId, setLossSectorId] = useState<string | null>(null);
  const [lossStart, setLossStart] = useState(() => minusDays(14));
  const [lossEnd, setLossEnd] = useState(() => localIsoDate(new Date()));
  const [lossDialog, setLossDialog] = useState(false);

  const sectorId = sectorSel ?? sectors.find((s) => s.active)?.id;
  const validLossRange = lossStart <= lossEnd;

  const { data, isLoading, isFetching, refetch } = useQuery({
    queryKey: ["dashboard", sectorId],
    refetchInterval: 60_000,
    staleTime: 20_000,
    queryFn: async () => {
      const [ka, hist, sync] = await Promise.all([
        supabase.from("kanban_assignments")
          .select("ficha_id, sector_id, stage_id, responsible_id, completed_at, fichas!inner(delivery_date, sync_state)")
          .neq("fichas.sync_state", "archived")
          .limit(5000),
        supabase.from("status_history")
          .select("id, ficha_id, previous_stage_id, new_stage_id, changed_by_user_id, changed_at, movement_type, return_reason_category")
          .order("changed_at", { ascending: false })
          .limit(12),
        supabase.from("sync_runs")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle(),
      ]);
      if (ka.error) throw new Error(ka.error.message);
      if (hist.error) throw new Error(hist.error.message);
      if (sync.error) throw new Error(sync.error.message);
      return {
        ka: (ka.data ?? []) as unknown as { ficha_id: string; sector_id: string; stage_id: string; responsible_id: string | null; completed_at: string | null; fichas: { delivery_date: string | null } }[],
        hist: hist.data ?? [],
        sync: sync.data,
      };
    },
  });

  const { data: losses = [], isLoading: lossesLoading } = useQuery({
    queryKey: ["dashboard-losses", lossStart, lossEnd, lossSectorId],
    enabled: validLossRange,
    staleTime: 15_000,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("list_production_losses", {
        _start_date: lossStart,
        _end_date: lossEnd,
        _sector_id: lossSectorId ?? null,
      });
      if (error) throw new Error(error.message);
      return (data ?? []) as unknown as LossRow[];
    },
  });

  const { data: durations = [] } = useQuery({
    queryKey: ["durations", sectorId],
    enabled: !!sectorId,
    staleTime: 5_000,
    refetchInterval: 15_000,
    queryFn: async () => (await supabase.rpc("stage_avg_durations", { _sector_id: sectorId! })).data ?? [],
  });

  const finalIds = useMemo(() => new Set(stages.filter((s) => s.is_final).map((s) => s.id)), [stages]);
  const active = data?.ka.filter((k) => !finalIds.has(k.stage_id)) ?? [];
  const overdue = data?.ka.filter((k) => isOverdue(k.fichas.delivery_date, k.completed_at)) ?? [];
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const weekStart = new Date(today); weekStart.setDate(today.getDate() - ((today.getDay() + 6) % 7));
  const doneToday = data?.ka.filter((k) => k.completed_at && new Date(k.completed_at) >= today).length ?? 0;
  const doneWeek = data?.ka.filter((k) => k.completed_at && new Date(k.completed_at) >= weekStart).length ?? 0;

  const sectorStages = stages.filter((s) => s.sector_id === sectorId && s.active);
  const byStage = sectorStages.map((s) => ({
    name: s.name,
    fichas: data?.ka.filter((k) => k.stage_id === s.id).length ?? 0,
    minutos: Math.max(0, Math.round(Number(durations.find((d) => d.stage_id === s.id)?.avg_hours ?? 0) * 60)),
  }));
  const bySector = sectors.filter((s) => s.active).map((s) => ({ name: s.name, fichas: active.filter((k) => k.sector_id === s.id).length }));
  const byUser = profiles.map((p) => ({ name: p.full_name, fichas: active.filter((k) => k.responsible_id === p.id).length })).filter((x) => x.fichas > 0);
  const stageName = (id: string | null) => stages.find((s) => s.id === id)?.name ?? "Entrada";
  const userName = (id: string | null) => profiles.find((p) => p.id === id)?.full_name ?? "Sistema";

  const lossChart = useMemo(() => {
    if (!validLossRange) return [];
    const start = new Date(lossStart + "T12:00:00");
    const end = new Date(lossEnd + "T12:00:00");
    const result: { label: string; date: string; pecas: number }[] = [];
    for (const cursor = new Date(start); cursor <= end; cursor.setDate(cursor.getDate() + 1)) {
      const date = localIsoDate(cursor);
      result.push({
        date,
        label: cursor.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }),
        pecas: losses.filter((loss) => loss.occurrence_date === date).reduce((sum, loss) => sum + Number(loss.quantity), 0),
      });
    }
    return result;
  }, [losses, lossStart, lossEnd, validLossRange]);

  const totalLost = losses.reduce((sum, loss) => sum + Number(loss.quantity), 0);
  const lossDays = new Set(losses.map((loss) => loss.occurrence_date)).size;
  const distinctLossItems = new Set(losses.map((loss) => loss.description.trim()).filter(Boolean)).size;
  const avgLostPerOccurrence = losses.length ? totalLost / losses.length : 0;

  function setPreset(days: number) {
    setLossStart(minusDays(days - 1));
    setLossEnd(localIsoDate(new Date()));
  }

  function exportLosses() {
    const header = ["Data da perda", "Ficha", "Setor", "Etapa", "Descrição da peça", "Quantidade", "Unidade", "Motivo", "Detalhes", "Responsável", "Criado em"];
    const rows = losses.map((loss) => [
      loss.occurrence_date,
      loss.order_number ? "#" + loss.order_number : "",
      loss.sector_name,
      loss.stage_name ?? "",
      loss.description,
      loss.quantity,
      loss.unit,
      loss.reason_category,
      loss.details ?? "",
      loss.responsible_name,
      new Date(loss.created_at).toLocaleString("pt-BR"),
    ]);
    const csv = "\uFEFF" + [header, ...rows].map((row) => row.map(csvCell).join(";")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "relatorio-perdas-" + lossStart + "-a-" + lossEnd + ".csv";
    anchor.click();
    URL.revokeObjectURL(url);
  }

  if (isLoading || !data) {
    return (
      <div className="mx-auto w-full max-w-[1600px] space-y-6 p-4 sm:p-5 md:p-6">
        <Skeleton className="h-16 rounded-2xl" />
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-5">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}</div>
        <div className="grid gap-4 lg:grid-cols-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-72 rounded-2xl" />)}</div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Dashboard"
        description="Visão operacional da fábrica, carga das etapas e perdas de produção."
        actions={
          <div className="flex w-full flex-wrap gap-2 md:w-auto">
            <Select value={sectorId ?? ""} onValueChange={setSectorSel}>
              <SelectTrigger className="h-10 min-w-44 flex-1 sm:flex-none" aria-label="Setor do dashboard"><SelectValue placeholder="Setor" /></SelectTrigger>
              <SelectContent>{sectors.filter((s) => s.active).map((s) => <SelectItem key={s.id} value={s.id}>Setor {s.name}</SelectItem>)}</SelectContent>
            </Select>
            <Button variant="outline" size="icon" onClick={() => refetch()} disabled={isFetching} aria-label="Atualizar dashboard" title="Atualizar dashboard"><RefreshCw className={isFetching ? "size-4 animate-spin" : "size-4"} /></Button>
          </div>
        }
      />

      <div className="mx-auto w-full max-w-[1600px] space-y-5 p-3 sm:p-4 md:p-6">
        <section className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-5">
          <Kpi label="Fichas ativas" value={active.length} />
          <Kpi label="Atrasadas" value={overdue.length} tone="danger" />
          <Kpi label="Concluídas hoje" value={doneToday} tone="success" />
          <Kpi label="Concluídas na semana" value={doneWeek} tone="success" />
          <Kpi label="Última sincronização" value={data.sync ? fmtDateTime(data.sync.finished_at ?? data.sync.created_at) : "Nunca"} small />
        </section>

        <section className="rounded-2xl border bg-card p-4 shadow-card sm:p-5 print-loss-report">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-destructive/10 text-destructive"><CalendarRange className="size-4" /></span>
                <div><h2 className="font-display text-lg font-bold">Perdas de peças</h2><p className="text-xs text-muted-foreground">Acompanhe quantidade, peça e data das perdas com os registros históricos preservados.</p></div>
              </div>
              <div className="mt-3 flex flex-wrap gap-1.5 no-print">
                {[7, 15, 30].map((days) => (
                  <Button key={days} variant={lossStart === minusDays(days - 1) ? "secondary" : "outline"} size="sm" onClick={() => setPreset(days)}>{days === 15 ? "Quinzena" : days + " dias"}</Button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 no-print">
              <div><label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Início</label><Input type="date" value={lossStart} onChange={(e) => setLossStart(e.target.value)} className="h-10" /></div>
              <div><label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Fim</label><Input type="date" value={lossEnd} onChange={(e) => setLossEnd(e.target.value)} className="h-10" /></div>
              <div><label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Setor</label><Select value={lossSectorId ?? "todos"} onValueChange={(v) => setLossSectorId(v === "todos" ? null : v)}><SelectTrigger className="h-10"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="todos">Todos</SelectItem>{sectors.filter((s) => s.active).map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent></Select></div>
              <div className="flex items-end gap-2"><Button className="h-10 flex-1" onClick={exportLosses} disabled={!validLossRange || lossesLoading}><Download className="size-4" /> Planilha</Button><Button variant="outline" className="h-10" onClick={() => window.print()} aria-label="Imprimir relatório de perdas" title="Imprimir / salvar como PDF"><Printer className="size-4" /></Button></div>
            </div>
          </div>

          {!validLossRange ? (
            <p className="mt-5 rounded-2xl border border-destructive/30 bg-destructive/5 p-4 text-sm font-medium text-destructive">O início do período não pode ser posterior ao fim.</p>
          ) : lossesLoading ? (
            <Skeleton className="mt-5 h-80 rounded-2xl" />
          ) : (
            <div className="mt-5 rounded-3xl border bg-background/45 p-3 sm:p-4">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-3 px-1">
                <div className="flex items-center gap-2">
                  <span className="grid size-9 place-items-center rounded-xl bg-destructive/10 text-destructive"><TrendingDown className="size-4" /></span>
                  <div>
                    <p className="text-sm font-bold">Mapa diário de perdas</p>
                    <p className="text-xs text-muted-foreground">{lossDays} dia{lossDays === 1 ? "" : "s"} com ocorrência no período selecionado</p>
                  </div>
                </div>
                <span className="rounded-full border bg-card px-3 py-1.5 text-xs font-bold text-muted-foreground">{totalLost.toLocaleString("pt-BR")} peças</span>
              </div>
              <div className="h-72 sm:h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={lossChart} margin={{ top: 16, right: 18, left: -6, bottom: 4 }}>
                    <CartesianGrid strokeDasharray="4 4" stroke="var(--color-border)" vertical={false} />
                    <XAxis dataKey="label" tick={{ fontSize: 10, fill: "var(--color-muted-foreground)" }} interval={lossChart.length > 20 ? Math.ceil(lossChart.length / 12) : 0} tickMargin={10} axisLine={false} tickLine={false} />
                    <YAxis allowDecimals tick={{ fontSize: 10, fill: "var(--color-muted-foreground)" }} width={34} axisLine={false} tickLine={false} />
                    <Tooltip content={<LossTooltip />} />
                    <Bar dataKey="pecas" fill="var(--color-destructive)" radius={[8, 8, 3, 3]} maxBarSize={38} background={{ fill: "var(--color-muted)" }} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
            <Kpi label="Peças perdidas" value={totalLost.toLocaleString("pt-BR")} tone="danger" />
            <Kpi label="Ocorrências" value={losses.length} />
            <Kpi label="Dias com perda" value={lossDays} />
            <Kpi label="Itens afetados" value={distinctLossItems} />
             <Kpi label="Média por ocorrência" value={avgLostPerOccurrence.toFixed(1).replace(".", ",")} small />
          </div>

          <div className="mt-5 border-t pt-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div><h3 className="font-semibold">Detalhamento das perdas</h3><p className="text-xs text-muted-foreground">{losses.length} ocorrência{losses.length === 1 ? "" : "s"} no período selecionado.</p></div>
              <Button variant="ghost" size="sm" className="no-print" onClick={() => setLossDialog(true)}><Plus className="size-4" /> Registrar perda</Button>
            </div>

            {losses.length === 0 ? (
              <Empty text="Nenhuma perda registrada neste período." />
            ) : (
              <>
                <div className="mt-3 space-y-2 md:hidden">
                  {losses.map((loss) => (
                    <article key={loss.id} className="rounded-xl border bg-background/60 p-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0"><p className="font-semibold">{loss.description}</p><p className="mt-0.5 text-xs font-medium text-muted-foreground">{fmtDate(loss.occurrence_date)}</p></div>
                        <span className="shrink-0 rounded-lg bg-destructive/10 px-2 py-1 text-sm font-bold text-destructive">{loss.quantity} {loss.unit}</span>
                      </div>
                      <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                        <Data label="Responsável" value={loss.responsible_name} />
                        <Data label="Motivo" value={loss.reason_category} />
                        {loss.order_number && <Data label="Ficha" value={loss.order_number ? "#" + loss.order_number : "—"} />}
                        {loss.details && <Data label="Detalhes" value={loss.details} wide />}
                      </div>
                    </article>
                  ))}
                </div>

                <div className="mt-3 hidden overflow-x-auto md:block">
                  <table className="data-table">
                    <thead className="bg-muted/70"><tr><th>Data</th><th>Peça / descrição</th><th>Qtd.</th><th>Ficha</th><th>Setor</th><th>Etapa</th><th>Responsável</th></tr></thead>
                    <tbody>{losses.map((loss) => (
                      <tr key={loss.id} className="border-t">
                        <td className="whitespace-nowrap">{loss.occurrence_date}</td>
                        <td>{loss.order_number && loss.ficha_id ? <Link to="/fichas/$id" params={{ id: loss.ficha_id }} className="font-mono text-primary hover:underline">#{loss.order_number}</Link> : "—"}</td>
                        <td><p className="font-medium">{loss.description}</p>{loss.details && <p className="mt-1 text-xs text-muted-foreground">{loss.details}</p>}</td>
                        <td className="whitespace-nowrap font-bold text-destructive">{loss.quantity} {loss.unit}</td>
                        <td>{loss.reason_category}</td>
                        <td>{loss.responsible_name}</td>
                        <td>{loss.sector_name}</td>
                        <td>{loss.stage_name ?? "—"}</td>
                      </tr>
                    ))}</tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        </section>

        <div className="grid gap-4 lg:grid-cols-2">
          <ChartCard title="Fichas por etapa" subtitle={sectorId ? "Distribuição atual no setor selecionado." : undefined}><StageBar data={byStage} dataKey="fichas" unit="fichas" /></ChartCard>
          <ChartCard title="Tempo médio por etapa" subtitle="Tempo médio real do histórico, atualizado em minutos."><StageBar data={byStage} dataKey="minutos" unit="min" /></ChartCard>
          <ChartCard title="Fichas ativas por setor" subtitle="Carga atual entre os setores ativos."><StageBar data={bySector} dataKey="fichas" unit="fichas" /></ChartCard>
          <ChartCard title="Carga por responsável" subtitle="Fichas ativas com responsável definido.">{byUser.length ? <StageBar data={byUser} dataKey="fichas" unit="fichas" /> : <Empty text="Nenhuma ficha está atribuída a um responsável." />}</ChartCard>
        </div>

        <section className="rounded-2xl border bg-card p-4 shadow-card sm:p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div><h2 className="font-semibold">Últimas movimentações</h2><p className="text-xs text-muted-foreground">As 12 alterações mais recentes.</p></div>
            <span className="text-xs text-muted-foreground">{fmtDateTime(new Date().toISOString())}</span>
          </div>
          {data.hist.length === 0 ? <Empty text="Nenhuma movimentação registrada ainda." /> : (
            <div className="mt-3 divide-y">
              {data.hist.map((h) => (
                <div key={h.id} className={cn("flex flex-wrap items-center gap-2 py-3 text-sm", h.movement_type === "retorno" && "bg-destructive/5")}>
                  <span className="w-full text-[11px] text-muted-foreground sm:w-32">{fmtDateTime(h.changed_at)}</span>
                  <span className="min-w-32 max-w-48 truncate font-medium">{userName(h.changed_by_user_id)}</span>
                  <span className="text-muted-foreground">{stageName(h.previous_stage_id)}</span><ArrowRight className="size-3.5 shrink-0" /><strong>{stageName(h.new_stage_id)}</strong>
                  {h.movement_type === "retorno" && <span className="rounded-md bg-destructive/10 px-2 py-1 text-xs font-semibold text-destructive">Retorno · {h.return_reason_category}</span>}
                  <Link to="/fichas/$id" params={{ id: h.ficha_id }} className="ml-auto rounded-md px-2 py-1 text-xs font-semibold text-primary hover:bg-accent">Ver ficha</Link>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      <ProductionLossDialog open={lossDialog} onOpenChange={setLossDialog} defaultSectorId={lossSectorId ?? sectorId ?? null} />
    </div>
  );
}

function Kpi({ label, value, tone, small }: { label: string; value: number | string; tone?: "danger" | "success"; small?: boolean }) {
  const color = tone === "danger" ? "text-destructive" : tone === "success" ? "text-success" : "text-foreground";
  return (
    <div className="group relative min-w-0 overflow-hidden rounded-2xl border bg-card p-4 shadow-card transition hover:-translate-y-px hover:shadow-md sm:p-5">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-0.5 bg-primary/35 opacity-0 transition group-hover:opacity-100" />
      <p className="truncate text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground">{label}</p>
      <p className={cn("mt-1.5 truncate font-display font-bold tabular-nums", small ? "text-sm leading-5" : "text-2xl sm:text-3xl", color)}>{value}</p>
    </div>
  );
}

function ChartCard({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  return (
    <section className="group overflow-hidden rounded-3xl border bg-card shadow-card transition hover:-translate-y-px hover:shadow-md">
      <div className="flex items-start gap-3 border-b bg-muted/20 px-4 py-4 sm:px-5">
        <span className="grid size-9 shrink-0 place-items-center rounded-xl border bg-background text-primary shadow-sm">
          <BarChart3 className="size-4" />
        </span>
        <div className="min-w-0 flex-1">
          <h2 className="truncate font-display font-bold">{title}</h2>
          {subtitle && <p className="mt-0.5 text-xs leading-5 text-muted-foreground">{subtitle}</p>}
        </div>
        <span className="hidden shrink-0 items-center gap-1 rounded-full border bg-background px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-muted-foreground sm:inline-flex">
          <Activity className="size-3" /> ao vivo
        </span>
      </div>
      <div className="bg-[radial-gradient(circle_at_top_right,color-mix(in_oklch,var(--color-primary)_7%,transparent),transparent_42%)] p-3 sm:p-4">
        <div className="h-72 sm:h-80">{children}</div>
      </div>
    </section>
  );
}

function LossTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value?: number | string; name?: string }>; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="min-w-44 rounded-2xl border border-border/80 bg-card/95 px-3.5 py-3 shadow-lift backdrop-blur-xl">
      <p className="text-[10px] font-black uppercase tracking-[0.14em] text-muted-foreground">Perdas · {label}</p>
      <p className="mt-1 text-xl font-black tabular-nums text-destructive">{Number(payload[0]?.value ?? 0).toLocaleString("pt-BR")} peças</p>
      <p className="mt-0.5 text-[10px] font-semibold text-muted-foreground">Quantidade perdida no dia</p>
    </div>
  );
}

function StageBar({ data, dataKey, unit }: { data: Record<string, unknown>[]; dataKey: string; unit?: string }) {
  const max = Math.max(1, ...data.map((item) => Number(item[dataKey] ?? 0)));
  return (
    <div className="flex h-full flex-col justify-center gap-3 overflow-y-auto py-1">
      {data.length === 0 ? (
        <Empty text="Nenhum dado disponível para este recorte." />
      ) : data.map((item) => {
        const value = Number(item[dataKey] ?? 0);
        const label = String(item.name ?? "—");
        const width = Math.max(value > 0 ? 4 : 0, (value / max) * 100);
        return (
          <div key={label} className="space-y-1.5">
            <div className="flex items-center justify-between gap-3 text-xs">
              <span className="min-w-0 truncate font-semibold" title={label}>{label}</span>
              <span className="shrink-0 rounded-full bg-muted px-2.5 py-1 font-mono font-bold tabular-nums">{Number.isInteger(value) ? value.toLocaleString("pt-BR") : value.toFixed(1).replace(".", ",")} {unit ?? ""}</span>
            </div>
            <div className="h-3 overflow-hidden rounded-full bg-muted/80">
              <div
                className="h-full rounded-full bg-gradient-to-r from-primary via-chart-2 to-chart-3 shadow-sm transition-[width] duration-700"
                style={{ width: width + "%" }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

function Data({ label, value, wide = false }: { label: string; value: string; wide?: boolean }) {
  return <div className={wide ? "col-span-2" : undefined}><p className="text-muted-foreground">{label}</p><p className="font-medium">{value}</p></div>;
}

function Empty({ text = "Sem dados ainda." }: { text?: string }) {
  return <p className="grid min-h-28 place-items-center text-center text-sm text-muted-foreground">{text}</p>;
}
