import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { ModoTvConfigPage } from "@/components/app/ModoTvConfig";

const searchSchema = z.object({
  ficha: z.string().optional(),
  data: z.string().optional(),
});

export const Route = createFileRoute("/_authenticated/modo-tv/configuracao")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Programação do Modo TV — PEDIFLOW" },
      { name: "description", content: "Configuração administrativa da programação da tela de produção." },
    ],
  }),
  component: ModoTvConfigRoute,
});

function ModoTvConfigRoute() {
  const { ficha, data } = Route.useSearch();
  return <ModoTvConfigPage initialFichaId={ficha} initialDate={data} />;
}
