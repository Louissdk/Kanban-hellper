import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { ArrowLeft, ArrowLeftRight, ArrowRight, Copy, Database, Factory, Save, Shuffle, Trash2, Tv } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { allStagesQuery, profilesQuery, sectorsQuery, fmtDate, fmtDateTime, isOverdue, errMsg, maskCustomerName, PRIORITY_LABEL, type Priority } from "@/lib/data";
import { transferFichaSector } from "@/lib/transitions";
import { TransitionModal } from "@/components/app/TransitionModal";
import { ConfirmRecordRemovalDialog } from "@/components/app/RecordRemovalDialog";
import { DuplicateResolutionDialog } from "@/components/app/DuplicateResolutionDialog";
import { DuplicateFichaDialog } from "@/components/app/DuplicateFichaDialog";
import { SearchSelect } from "@/components/app/SearchSelect";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export const Route = createFileRoute("/_authenticated/fichas/$id")({
  head: () => ({ meta: [{ title: "Ficha — Kanban de Produção" }, { name: "description", content: "Detalhes, produção e histórico da ficha." }] }),
  component: FichaPage,
});

function useFicha(id: string) {
  return useQuery({
    queryKey: ["ficha", id],
    queryFn: async () => {
      const responses = await Promise.all([
        supabase.from("fichas").select("*").eq("id", id).maybeSingle(),
        supabase.from("ficha_items").select("*").eq("ficha_id", id).order("line_no"),
        supabase.from("kanban_assignments").select("*").eq("ficha_id", id).maybeSingle(),
        supabase.from("status_history").select("*").eq("ficha_id", id).order("changed_at", { ascending: false }),
        supabase.from("sector_transfer_history").select("*").eq("ficha_id", id).order("changed_at", { ascending: false }),
      ]);

      const [f, items, ka, hist, tr] = responses;
      const failures = [
        { label: "dados do pedido", error: f.error },
        { label: "itens do pedido", error: items.error },
        { label: "atribuição do Kanban", error: ka.error },
        { label: "histórico de produção", error: hist.error },
        { label: "histórico de transferências", error: tr.error },
      ];
      const failed = failures.find((item) => !!item.error);

      if (failed?.error) {
        throw new Error(`Não foi possível carregar ${failed.label}: ${failed.error.message}`);
      }
      if (!f.data) {
        return {
          ficha: null,
          items: [],
          ka: null,
          history: [],
          transfers: [],
        };
      }
      if (!ka.data) {
        throw new Error("A ficha existe, mas não possui uma atribuição válida no Kanban.");
      }

      return {
        ficha: f.data,
        items: Array.isArray(items.data) ? items.data : [],
        ka: ka.data,
        history: Array.isArray(hist.data) ? hist.data : [],
        transfers: Array.isArray(tr.data) ? tr.data : [],
      };
    },
  });
}

function useFichaAdminChanges(id: string, enabled: boolean) {
  return useQuery({
    queryKey: ["ficha-admin-changes", id],
    enabled,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("smb_admin_changes")
        .select("*")
        .eq("ficha_id", id)
        .order("changed_at", { ascending: false });

      if (error) throw new Error(`Não foi possível carregar as mudanças administrativas: ${error.message}`);
      return Array.isArray(data) ? data : [];
    },
  });
}
function auditValue(value: unknown): string {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value);
  try { return JSON.stringify(value); } catch { return String(value); }
}

function auditSourceLabel(source: string, actorLabel: string): string {
  return source === "SMB_SYNC" ? "SMB / " + actorLabel : "Kanban / " + actorLabel;
}

function FichaPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { canManage, canOperate, isAdmin } = useAuth();
  const { data, isLoading, error, refetch } = useFicha(id);
  const {
    data: adminChanges = [],
    error: adminChangesError,
  } = useFichaAdminChanges(id, !!data?.ficha?.id);
  const { data: stages = [], isLoading: stagesLoading } = useQuery(allStagesQuery);
  const { data: sectors = [] } = useQuery(sectorsQuery);
  const { data: profiles = [] } = useQuery(profilesQuery);
  const [modal, setModal] = useState(false);
  const [transfer, setTransfer] = useState(false);
  const [removeTarget, setRemoveTarget] = useState<{ id: string; orderNumber: string } | null>(null);
  const [duplicateOpen, setDuplicateOpen] = useState(false);
  const [copyOpen, setCopyOpen] = useState(false);

  useEffect(() => {
    const ch = supabase.channel(`ficha-${id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "kanban_assignments", filter: `ficha_id=eq.${id}` }, () => qc.invalidateQueries({ queryKey: ["ficha", id] }))
      .subscribe();
    return () => { void supabase.removeChannel(ch); };
  }, [id, qc]);

  if (isLoading) return <div className="space-y-4 p-6"><Skeleton className="h-10 w-64" /><Skeleton className="h-64" /></div>;
  if (error) {
    return (
      <div className="mx-auto grid min-h-[60vh] w-full max-w-2xl place-items-center px-4 py-10">
        <div className="w-full rounded-2xl border border-destructive/30 bg-card p-5 text-center shadow-sm">
          <h1 className="text-lg font-semibold">Não foi possível carregar esta ficha</h1>
          <p className="mt-2 break-words text-sm text-muted-foreground">{errMsg(error)}</p>
          <Button className="mt-4" onClick={() => void refetch()}>Tentar novamente</Button>
        </div>
      </div>
    );
  }
  if (!data?.ficha || !data.ka) return <div className="p-10 text-center text-muted-foreground">Ficha não encontrada.</div>;

  const { ficha, items, ka, history, transfers } = data;
  const stageName = (sid: string | null) => stages.find((s) => s.id === sid)?.name ?? "—";
  const sectorName = (sid: string | null) => sectors.find((s) => s.id === sid)?.name ?? "—";
  const userName = (uid: string | null) => profiles.find((p) => p.id === uid)?.full_name ?? "Sistema";
  const overdue = isOverdue(ficha.delivery_date, ka.completed_at);
  const returned = ka.production_returned;
  const sourceSystem = typeof ficha.source_system === "string" ? ficha.source_system.toLowerCase() : "";

  type Ev = { at: string; key: string; who: string; from: string; to: string; obs: string | null; kind: string; movement: string; reason: string | null; };
  const timeline: Ev[] = [
    ...history.map((h) => ({ at: h.changed_at, key: h.id, who: userName(h.changed_by_user_id), from: h.previous_stage_id ? stageName(h.previous_stage_id) : "Entrada", to: stageName(h.new_stage_id), obs: h.observation, kind: h.source, movement: h.movement_type, reason: h.return_reason_category })),
    ...transfers.map((t) => ({ at: t.changed_at, key: t.id, who: userName(t.changed_by_user_id), from: `Setor ${sectorName(t.previous_sector_id)} · ${stageName(t.previous_stage_id)}`, to: `Setor ${sectorName(t.new_sector_id)} · ${stageName(t.new_stage_id)}`, obs: t.observation, kind: "transferência", movement: "transferência", reason: null })),
  ].sort((a, b) => b.at.localeCompare(a.at));

  return (
    <div className="mx-auto w-full max-w-6xl space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-center gap-3">
        <Button variant="ghost" size="sm" asChild><Link to="/quadro" search={{ setor: ka.sector_id }}><ArrowLeft className="size-4" /> Quadro</Link></Button>
        <h1 className="font-mono text-2xl font-bold">FICHA #{ficha.order_number}</h1>
        <Badge variant="secondary">Setor {sectorName(ka.sector_id)}</Badge>
        <Badge>{stageName(ka.stage_id)}</Badge>
        {(ficha.pdd_id || ficha.external_order_id) && (
          <Badge variant="outline" className="font-mono text-[10px] text-primary">
            SMB/PDD #{ficha.pdd_id || ficha.external_order_id}
          </Badge>
        )}
        {returned && <Badge variant="destructive">Retorno — erro de produção</Badge>}
        {overdue && <Badge className="bg-warning text-warning-foreground">Atrasada</Badge>}
        <div className="ml-auto flex gap-2">
          {ficha.duplicated_from_ficha_id && <Badge className="border-primary/30 bg-primary/10 text-primary"><Copy className="size-3.5" /> CÓPIA</Badge>}
          {canManage && <Button variant="outline" size="sm" onClick={() => setTransfer(true)}><Shuffle className="size-4" /> Transferir setor</Button>}
          {isAdmin && <Button variant="outline" size="sm" onClick={() => setCopyOpen(true)}><Copy className="size-4" /> Duplicar ficha</Button>}
          {ficha.duplicate_group_id && (
            <Button variant="outline" size="sm" onClick={() => setDuplicateOpen(true)}>
              Duplicidade
            </Button>
          )}
          {isAdmin && <Button variant="outline" size="sm" onClick={() => navigate({ to: "/modo-tv/configuracao", search: { ficha: id } })}><Tv className="size-4" /> Programar no Modo TV</Button>}
          {isAdmin && <Button variant="destructive" size="sm" onClick={() => setRemoveTarget({ id, orderNumber: ficha.order_number })}><Trash2 className="size-4" /> Excluir pedido</Button>}
          {canOperate && <Button size="sm" onClick={() => setModal(true)}><ArrowLeftRight className="size-4" /> Alterar etapa</Button>}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <section className="rounded-xl border border-dashed bg-card p-5">
          <header className="mb-4 flex items-center gap-2">
            <Database className="size-4 text-info" />
            <h2 className="font-semibold">A. Dados do pedido</h2>
            <Badge variant="outline" className="ml-auto text-info">{sourceSystem === "smb" ? "Origem: SMB (somente leitura)" : "Origem: manual"}</Badge>
          </header>
          <dl className="grid grid-cols-1 gap-x-4 gap-y-3 text-sm sm:grid-cols-2">
            <Info k="Pedido do cliente" v={ficha.pedido_cliente ?? ficha.order_number} />
            <Info k="PDD / pedido SMB" v={ficha.external_order_id ?? "—"} />
            <Info k="SMB cliente ID" v={ficha.smb_cliente_id ?? "—"} />
            <Info k="Cliente" v={maskCustomerName(ficha.customer, isAdmin)} wide />
            <Info k="Vendedor" v={ficha.seller_name ?? "—"} />
            <Info k="Etapa atual no Kanban" v={stageName(ka.stage_id)} />
            <Info k="Abertura" v={fmtDateTime(ficha.opened_at)} />
            <Info k="Status SMB" v={ficha.status_smb ?? "—"} />
            <Info k="Descrição status SMB" v={ficha.status_smb_descricao ?? ficha.smb_status ?? "—"} />
            <CustomerCodeEditor fichaId={id} value={ficha.codigo_cliente ?? ficha.customer_code ?? ""} editable={isAdmin} />
            <Info k="Quantidade" v={`${ficha.quantity ?? "—"} ${ficha.unit ?? ""}`} />
            <Info k="Data do pedido" v={fmtDate(ficha.order_date)} />
            <Info k="Prazo de entrega" v={fmtDate(ficha.data_entrega ?? ficha.delivery_date)} />
            <Info k="Envio" v={ficha.envio ?? "—"} />
            <Info k="Última sincronização" v={fmtDateTime(ficha.source_synced_at)} />
            {ficha.source_observations && <Info k="Observações (origem)" v={ficha.source_observations} wide />}
          </dl>
          {ficha.pdd_id || ficha.external_order_id ? (
            <div className="mt-4 rounded-xl border bg-muted/30 p-3">
              <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">Identificador SMB</p>
              <p className="mt-1 font-mono text-sm font-bold text-primary">PDD #{ficha.pdd_id || ficha.external_order_id}</p>
              <p className="mt-1 text-[11px] text-muted-foreground">Dado sincronizado pelo robô SMB. O navegador não acessa o sistema original.</p>
            </div>
          ) : null}
          <h3 className="mt-5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Itens</h3>
          {items.length === 0 ? <p className="mt-2 text-sm text-muted-foreground">Nenhum item.</p> : (
            <div className="mt-2 overflow-x-auto rounded-2xl border bg-background/45">
            <table className="data-table compact-data-table text-sm">
              <thead className="text-left text-xs text-muted-foreground"><tr><th className="py-1">Código</th><th>Produto</th><th className="text-right">Qtd.</th></tr></thead>
              <tbody>{items.map((it) => (
                <tr key={it.id} className="border-t"><td className="py-1.5 font-mono text-xs">{it.code ?? "—"}</td><td>{it.product}{it.description && <span className="block text-xs text-muted-foreground">{it.description}</span>}</td><td className="text-right">{it.quantity ?? "—"} {it.unit}</td></tr>
              ))}</tbody>
            </table>
          </div>
          )}
        </section>

        <ProductionSection
          fichaId={id}
          ka={ka}
          sectorLabel={sectorName(ka.sector_id)}
          stageLabel={stageName(ka.stage_id)}
          editable={canManage}
          priorityEditable={isAdmin}
        />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <section className="rounded-xl border bg-card p-5 lg:col-span-2">
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <h2 className="font-semibold">C. Histórico de Produção</h2>
            <Badge variant="outline">Chão de fábrica</Badge>
          </div>
          <div className="relative space-y-3 border-l pl-6">
            {timeline.map((e) => (
              <div key={e.key} className={cn("relative rounded-xl p-3", e.movement === "retorno" && "border border-destructive/30 bg-destructive/5")}>
                <span className="absolute -left-[7px] top-4 size-3 rounded-full border-2 border-card bg-primary" />
                <p className="text-xs text-muted-foreground">
                  {fmtDateTime(e.at)} · <span className={e.movement === "retorno" ? "font-semibold uppercase text-destructive" : "uppercase"}>
                    {e.movement === "retorno" ? "RETORNO — ERRO DE PRODUÇÃO" : e.movement === "avanco" ? "AVANÇO" : e.kind}
                  </span>
                </p>
                <p className="font-medium">{e.who}</p>
                <p className="flex flex-wrap items-center gap-1.5 text-sm">
                  {e.from} <ArrowRight className="size-3.5" /> <strong>{e.to}</strong>
                </p>
                {e.reason && <p className="mt-1 text-sm font-semibold text-destructive">Motivo: {e.reason}</p>}
                {e.obs && <p className={cn("mt-1 rounded-lg px-2 py-1.5 text-sm", e.movement === "retorno" ? "bg-destructive/10" : "bg-muted")}>{e.obs}</p>}
              </div>
            ))}
          </div>
        </section>
        <section className="rounded-xl border bg-card p-5 lg:col-span-2">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <h2 className="font-semibold">D. Mudanças Administrativas</h2>
              <Badge variant="outline">SMB / Administração</Badge>
            </div>
            <Link to="/mudancas-administrativas">
              <Button variant="outline" size="sm">Ver todas</Button>
            </Link>
          </div>
          {adminChangesError ? (
            <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">
              {errMsg(adminChangesError)}
            </div>
          ) : adminChanges.length === 0 ? (
            <div className="rounded-xl border border-dashed bg-muted/20 p-5 text-sm text-muted-foreground">
              Nenhuma mudança administrativa registrada para esta ficha.
            </div>
          ) : (
            <div className="space-y-3">
              {adminChanges.map((change) => (
                <div key={change.id} className="rounded-xl border bg-muted/10 p-4">
                  <div className="flex flex-wrap items-start gap-2">
                    <div className="min-w-0">
                      <p className="font-semibold">{change.field_label}{change.item_line_no ? " · Linha " + change.item_line_no : ""}</p>
                      <p className="mt-1 text-xs text-muted-foreground">{fmtDateTime(change.changed_at)} · {auditSourceLabel(change.source, change.actor_label)}</p>
                    </div>
                    <Badge variant={change.source === "SMB_SYNC" ? "default" : "secondary"} className="ml-auto">
                      {change.source === "SMB_SYNC" ? "Robô SMB" : "Kanban Admin"}
                    </Badge>
                  </div>
                  <div className="mt-3 grid gap-2 sm:grid-cols-2">
                    <div className="rounded-lg border bg-background p-3">
                      <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Valor anterior</p>
                      <p className="mt-1 break-words font-mono text-sm">{auditValue(change.old_value)}</p>
                    </div>
                    <div className="rounded-lg border bg-primary/5 p-3">
                      <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Novo valor</p>
                      <p className="mt-1 break-words font-mono text-sm">{auditValue(change.new_value)}</p>
                    </div>
                  </div>
                  {change.sync_run_id && <p className="mt-2 text-[11px] text-muted-foreground">Sincronização: <span className="font-mono">{change.sync_run_id}</span></p>}
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="rounded-xl border bg-card p-5">
          <h2 className="mb-4 font-semibold">E. Sincronização</h2>
          <dl className="space-y-3 text-sm">
            <Info k="Última sincronização SMB" v={fmtDateTime(ficha.source_synced_at)} />
            <Info k="Situação na origem" v={{ active: "Ativa", not_seen_in_last_sync: "Não vista na última sincronização", archived: "Arquivada" }[ficha.sync_state] ?? ficha.sync_state} />
            {ficha.sync_warning && <p className="rounded bg-warning/20 p-2 text-sm">{ficha.sync_warning}</p>}
          </dl>
        </section>
      </div>

      <TransitionModal open={modal} onOpenChange={setModal} sectorId={ka.sector_id} fichas={[{ ficha_id: id, order_number: ficha.order_number, customer: ficha.customer, stage_id: ka.stage_id }]} initialFichaId={id} source="manual" />
      <TransferDialog open={transfer} onOpenChange={setTransfer} fichaId={id} currentSector={ka.sector_id} />
      {ficha.duplicate_group_id && (
        <DuplicateResolutionDialog
          open={duplicateOpen}
          onOpenChange={setDuplicateOpen}
          duplicateGroupId={ficha.duplicate_group_id}
          currentFichaId={id}
          onRequestDelete={(targetId, orderNumber) => {
            setDuplicateOpen(false);
            setRemoveTarget({ id: targetId, orderNumber });
          }}
        />
      )}
      {isAdmin && (
        <DuplicateFichaDialog
          open={copyOpen}
          onOpenChange={setCopyOpen}
          fichaId={id}
          orderNumber={ficha.order_number}
          currentSectorId={ka.sector_id}
          onCreated={(newId) => navigate({ to: "/fichas/$id", params: { id: newId } })}
        />
      )}
      {isAdmin && removeTarget && (
        <ConfirmRecordRemovalDialog
          open={!!removeTarget}
          onOpenChange={(next) => {
            if (!next) setRemoveTarget(null);
          }}
          fichaId={removeTarget.id}
          orderNumber={removeTarget.orderNumber}
          onRemoved={() => {
            const removedCurrent = removeTarget.id === id;
            setRemoveTarget(null);
            void qc.invalidateQueries({ queryKey: ["board"] });
            if (removedCurrent) {
              navigate({ to: "/quadro", search: { setor: ka.sector_id }, replace: true });
            } else {
              void qc.invalidateQueries({ queryKey: ["ficha", id] });
            }
          }}
        />
      )}
    </div>
  );
}

function CustomerCodeEditor({ fichaId, value, editable }: { fichaId: string; value: string; editable: boolean }) {
  const qc = useQueryClient();
  const [code, setCode] = useState(value);
  const [saving, setSaving] = useState(false);

  useEffect(() => setCode(value), [value]);

  async function save() {
    setSaving(true);
    try {
      const session = await supabase.auth.getSession();
      const token = session.data.session?.access_token;
      if (!token) throw new Error("Sua sessão expirou. Entre novamente no sistema.");

      const response = await fetch("/api/admin/customer-code", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token,
        },
        body: JSON.stringify({
          ficha_id: fichaId,
          customer_code: code.trim(),
        }),
      });

      const body = (await response.json().catch(() => ({}))) as { message?: string };
      if (!response.ok) throw new Error(body.message || "Não foi possível atualizar o código do cliente.");
    } catch (error) {
      setSaving(false);
      return toast.error(errMsg(error));
    }
    setSaving(false);
    toast.success("Código do cliente salvo.");
    await Promise.all([
      qc.invalidateQueries({ queryKey: ["ficha", fichaId] }),
      qc.invalidateQueries({ queryKey: ["board"] }),
    ]);
  }

  return (
    <div className="col-span-full space-y-1.5 sm:col-span-2">
      <Label htmlFor="customer-code">Código do cliente</Label>
      <div className="flex gap-2">
        <Input id="customer-code" value={code} onChange={(e) => setCode(e.target.value)} disabled={!editable || saving} maxLength={100} placeholder="Informe o código do cliente" className="font-mono" />
        {editable && <Button type="button" size="icon" variant="outline" onClick={() => void save()} disabled={saving} title="Salvar código do cliente"><Save className="size-4" /></Button>}
      </div>
      {!editable && <p className="text-xs text-muted-foreground">Somente a administração pode alterar o código do cliente.</p>}
    </div>
  );
}

function Info({ k, v, wide }: { k: string; v: string; wide?: boolean }) {
  return <div className={wide ? "col-span-full sm:col-span-2" : undefined}><dt className="text-xs text-muted-foreground">{k}</dt><dd className="font-medium">{v}</dd></div>;
}

interface KA { priority: string; responsible_id: string | null; internal_notes: string | null; production_started_at: string | null; completed_at: string | null; entered_stage_at: string; production_returned: boolean; return_count: number; last_return_reason_category: string | null; last_return_reason: string | null }

function ProductionSection({
  fichaId,
  ka,
  sectorLabel,
  stageLabel,
  editable,
  priorityEditable,
}: {
  fichaId: string;
  ka: KA;
  sectorLabel: string;
  stageLabel: string;
  editable: boolean;
  priorityEditable: boolean;
}) {
  const qc = useQueryClient();
  const { data: profiles = [] } = useQuery(profilesQuery);
  const [priority, setPriority] = useState(ka.priority);
  const [resp, setResp] = useState<string | null>(ka.responsible_id);
  const [notes, setNotes] = useState(ka.internal_notes ?? "");
  const [saving, setSaving] = useState(false);
  useEffect(() => { setPriority(ka.priority); setResp(ka.responsible_id); setNotes(ka.internal_notes ?? ""); }, [ka]);

  async function save() {
    setSaving(true);
    try {
      const { error: productionError } = await supabase
        .from("kanban_assignments")
        .update({ responsible_id: resp, internal_notes: notes || null })
        .eq("ficha_id", fichaId);

      if (productionError) throw productionError;

      if (priorityEditable && priority !== ka.priority) {
        const { error: priorityError } = await supabase.rpc("update_ficha_priority", {
          _ficha_id: fichaId,
          _priority: priority,
        });
        if (priorityError) throw priorityError;
      }

      toast.success("Dados de produção salvos.");
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["ficha", fichaId] }),
        qc.invalidateQueries({ queryKey: ["board"] }),
      ]);
    } catch (error) {
      toast.error(errMsg(error));
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="rounded-xl border bg-card p-5">
      <header className="mb-4 flex items-center gap-2"><Factory className="size-4 text-primary" /><h2 className="font-semibold">B. Produção</h2><Badge variant="outline" className="ml-auto">Dados da fábrica</Badge></header>
      <dl className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
        <Info k="Setor" v={sectorLabel} />
        <Info k="Etapa atual" v={stageLabel} />
        <Info k="Na etapa desde" v={fmtDateTime(ka.entered_stage_at)} />
        <Info k="Início da produção" v={fmtDateTime(ka.production_started_at)} />
        <Info k="Conclusão" v={fmtDateTime(ka.completed_at)} />
      </dl>
      <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="space-y-1.5">
          <div className="flex items-center justify-between gap-2">
            <Label>Prioridade</Label>
            {!priorityEditable && <span className="text-[11px] text-muted-foreground">Somente Admin</span>}
          </div>
          <Select value={priority} onValueChange={setPriority} disabled={!priorityEditable || saving}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{(Object.keys(PRIORITY_LABEL) as Priority[]).map((k) => <SelectItem key={k} value={k}>{PRIORITY_LABEL[k]}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Responsável</Label>
          <SearchSelect options={profiles.filter((p) => p.active).map((p) => ({ value: p.id, label: p.full_name }))} value={resp} onChange={setResp} placeholder="Sem responsável" disabled={!editable} />
        </div>
        <div className="col-span-2 space-y-1.5">
          <Label htmlFor="notes">Observações internas</Label>
          <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} disabled={!editable} maxLength={2000} />
        </div>
      </div>
      {editable && <Button className="mt-3" size="sm" onClick={save} disabled={saving}>Salvar produção</Button>}
    </section>
  );
}

function TransferDialog({ open, onOpenChange, fichaId, currentSector }: { open: boolean; onOpenChange: (o: boolean) => void; fichaId: string; currentSector: string }) {
  const qc = useQueryClient();
  const { userId } = useAuth();
  const { data: sectors = [], isLoading: sectorsLoading, error: sectorsError, refetch: refetchSectors } = useQuery(sectorsQuery);
  const { data: profiles = [] } = useQuery(profilesQuery);
  const { data: stages = [] } = useQuery(allStagesQuery);
  const [sector, setSector] = useState<string | null>(null);
  const [user, setUser] = useState<string | null>(userId);
  const [obs, setObs] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    setSector(null);
    setUser(userId);
    setObs("");
    void refetchSectors();
  }, [open, userId, refetchSectors]);

  const destinationSectors = sectors.filter(
    (s) => s.active && s.id !== currentSector && stages.some((stage) => stage.sector_id === s.id && stage.active),
  );
  const noDestination = !sectorsLoading && !stagesLoading && destinationSectors.length === 0;

  async function go() {
    if (!sector) return toast.error("Selecione o setor de destino.");
    if (!user) return toast.error("Selecione o usuário responsável pela mudança.");

    setBusy(true);
    try {
      await transferFichaSector(fichaId, sector, user, obs);

      const { data: assignment, error: verifyError } = await supabase
        .from("kanban_assignments")
        .select("sector_id, stage_id")
        .eq("ficha_id", fichaId)
        .maybeSingle();

      if (verifyError) throw new Error(verifyError.message);
      if (!assignment || assignment.sector_id !== sector) {
        throw new Error("A transferência foi solicitada, mas a ficha não confirmou o novo setor.");
      }

      await Promise.all([
        qc.invalidateQueries({ queryKey: ["ficha", fichaId] }),
        qc.invalidateQueries({ queryKey: ["board"] }),
      ]);
      toast.success("Ficha transferida para a primeira etapa do novo setor.");
      onOpenChange(false);
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Transferir ficha de setor</DialogTitle>
          <DialogDescription>
            A ficha irá para a primeira etapa ativa do novo setor. O histórico anterior é preservado.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="transfer-sector">Setor de destino *</Label>
            {sectorsLoading ? (
              <div className="flex h-10 items-center rounded-md border bg-muted px-3 text-sm text-muted-foreground">
                Carregando setores...
              </div>
            ) : sectorsError ? (
              <div className="space-y-2">
                <div className="rounded-md border border-destructive/40 bg-destructive/5 px-3 py-2 text-sm text-destructive">
                  Não foi possível carregar os setores.
                </div>
                <Button type="button" variant="outline" size="sm" onClick={() => void refetchSectors()}>
                  Tentar novamente
                </Button>
              </div>
            ) : destinationSectors.length > 0 ? (
              <SearchSelect
                id="transfer-sector"
                options={destinationSectors.map((s) => ({
                  value: s.id,
                  label: s.name,
                  hint: (() => {
                    const first = stages.find((stage) => stage.sector_id === s.id && stage.active);
                    return first ? "Primeira etapa: " + first.name : "Sem etapa ativa";
                  })(),
                }))}
                value={sector}
                onChange={setSector}
                placeholder="Pesquise e selecione o setor de destino"
              />
            ) : (
              <div className="rounded-md border border-dashed bg-muted/30 px-3 py-3 text-sm text-muted-foreground">
                Não há outro setor ativo com etapa ativa disponível para transferência.
              </div>
            )}
          </div>

          <div className="space-y-1.5">
            <Label>Usuário da mudança *</Label>
            <SearchSelect
              options={profiles.filter((p) => p.active).map((p) => ({ value: p.id, label: p.full_name }))}
              value={user}
              onChange={setUser}
              placeholder="Selecione o usuário"
              disabled={busy}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Observação</Label>
            <Textarea value={obs} onChange={(e) => setObs(e.target.value)} rows={3} maxLength={1000} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>Cancelar</Button>
          <Button onClick={go} disabled={busy || sectorsLoading || stagesLoading || destinationSectors.length === 0 || !sector}>
            {busy ? "Transferindo..." : "Confirmar transferência"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}