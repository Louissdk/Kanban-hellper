import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { DndContext, PointerSensor, closestCenter, useSensor, useSensors, type DragEndEvent } from "@dnd-kit/core";
import { SortableContext, arrayMove, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { ArrowDown, ArrowUp, Flag, GripVertical, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { sectorsQuery, stagesQuery, errMsg, type Stage } from "@/lib/data";
import { PageHeader } from "@/components/app/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/configuracoes/setores")({
  head: () => ({ meta: [{ title: "Setores e Etapas — Configurações" }, { name: "description", content: "Configure setores e etapas de produção." }] }),
  component: SetoresPage,
});

function SetoresPage() {
  const { isAdmin } = useAuth();
  const qc = useQueryClient();
  const { data: sectors = [] } = useQuery(sectorsQuery);
  const [sel, setSel] = useState<string | null>(null);
  const sectorId = sel ?? sectors[0]?.id;
  const sector = sectors.find((s) => s.id === sectorId);
  const [newSector, setNewSector] = useState("");

  if (!isAdmin) return <div className="p-10 text-center text-muted-foreground">Apenas administradores podem gerenciar setores.</div>;

  async function addSector() {
    const name = newSector.trim();
    if (!name) return;
    const { data, error } = await supabase.from("sectors").insert({ name, position: sectors.length + 1 }).select("id").single();
    if (error) return toast.error(error.message.includes("duplicate") ? "Já existe um setor com esse nome." : errMsg(error));
    setNewSector("");
    await qc.invalidateQueries({ queryKey: ["sectors"] });
    setSel(data.id);
    toast.success("Setor criado. Adicione as etapas.");
  }

  async function updateSector(patch: { name?: string; description?: string | null; active?: boolean; is_default_import?: boolean }) {
    if (!sector) return;
    if (patch.is_default_import) await supabase.from("sectors").update({ is_default_import: false }).neq("id", sector.id);
    const { error } = await supabase.from("sectors").update(patch).eq("id", sector.id);
    if (error) return toast.error(errMsg(error));
    qc.invalidateQueries({ queryKey: ["sectors"] });
  }

  return (
    <div>
      <PageHeader title="Setores e Etapas" description="Cada setor tem seu próprio fluxo. A ordem das colunas do quadro vem daqui." />
      <div className="grid grid-cols-1 gap-5 p-3 sm:p-4 md:p-6 lg:grid-cols-[280px_minmax(0,1fr)]">
        <aside className="space-y-3">
          <ul className="scrollbar-thin flex gap-2 overflow-x-auto pb-1 lg:block lg:space-y-1">
            {sectors.map((s) => (
              <li key={s.id}>
                <button onClick={() => setSel(s.id)} className={cn("flex min-w-max items-center justify-between gap-3 rounded-lg border px-3 py-2.5 text-left text-sm hover:bg-muted lg:w-full", s.id === sectorId && "bg-accent font-semibold text-accent-foreground")}>
                  Setor {s.name}
                  {!s.active && <Badge variant="outline">Inativo</Badge>}
                </button>
              </li>
            ))}
          </ul>
          <div className="flex gap-2 lg:sticky lg:top-20">
            <Input value={newSector} onChange={(e) => setNewSector(e.target.value)} placeholder="Novo setor" onKeyDown={(e) => e.key === "Enter" && addSector()} maxLength={60} />
            <Button size="icon" onClick={addSector} aria-label="Adicionar setor"><Plus className="size-4" /></Button>
          </div>
        </aside>
        {sector && (
          <div className="space-y-4">
            <div className="grid gap-3 rounded-2xl border bg-card p-4 shadow-card sm:p-5 md:grid-cols-2">
              <Input defaultValue={sector.name} key={`n-${sector.id}`} onBlur={(e) => e.target.value.trim() && e.target.value !== sector.name && updateSector({ name: e.target.value.trim() })} aria-label="Nome do setor" />
              <div className="flex flex-wrap items-center gap-4 text-sm">
                <label className="flex items-center gap-2"><Switch checked={sector.active} onCheckedChange={(v) => updateSector({ active: v })} /> Ativo</label>
                <label className="flex items-center gap-2"><Switch checked={sector.is_default_import} onCheckedChange={(v) => v && updateSector({ is_default_import: true })} /> Recebe importações do SMB</label>
              </div>
              <Textarea className="md:col-span-2" key={`d-${sector.id}`} defaultValue={sector.description ?? ""} placeholder="Descrição" rows={2} onBlur={(e) => e.target.value !== (sector.description ?? "") && updateSector({ description: e.target.value || null })} />
            </div>
            <StageEditor sectorId={sector.id} />
          </div>
        )}
      </div>
    </div>
  );
}

function StageEditor({ sectorId }: { sectorId: string }) {
  const qc = useQueryClient();
  const { data: stages = [] } = useQuery(stagesQuery(sectorId));
  const { data: counts = {} } = useQuery({
    queryKey: ["stage-counts", sectorId],
    queryFn: async () => {
      const { data } = await supabase.from("kanban_assignments").select("stage_id").eq("sector_id", sectorId);
      const m: Record<string, number> = {};
      for (const r of data ?? []) m[r.stage_id] = (m[r.stage_id] ?? 0) + 1;
      return m;
    },
  });
  const [name, setName] = useState("");
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }));
  const firstActive = stages.find((s) => s.active)?.id;
  const refresh = () => { qc.invalidateQueries({ queryKey: ["stages"] }); qc.invalidateQueries({ queryKey: ["stage-counts", sectorId] }); };

  async function persistOrder(ids: string[]) {
    qc.setQueryData(stagesQuery(sectorId).queryKey, ids.map((id, i) => ({ ...stages.find((s) => s.id === id)!, position: i + 1 })));
    const { error } = await supabase.rpc("reorder_stages", { _sector_id: sectorId, _stage_ids: ids });
    if (error) toast.error(errMsg(error));
    refresh();
  }
  function onDragEnd(e: DragEndEvent) {
    if (!e.over || e.active.id === e.over.id) return;
    const ids = stages.map((s) => s.id);
    void persistOrder(arrayMove(ids, ids.indexOf(String(e.active.id)), ids.indexOf(String(e.over.id))));
  }
  function move(id: string, dir: -1 | 1) {
    const ids = stages.map((s) => s.id);
    const i = ids.indexOf(id);
    if (i + dir < 0 || i + dir >= ids.length) return;
    void persistOrder(arrayMove(ids, i, i + dir));
  }
  function makeFirst(id: string) { void persistOrder([id, ...stages.map((s) => s.id).filter((x) => x !== id)]); }
  async function patch(id: string, p: Partial<Pick<Stage, "name" | "active" | "is_final" | "color">>) {
    if (p.active === false && (counts[id] ?? 0) > 0) return toast.error("Esta etapa possui fichas. Mova-as antes de desativar.");
    const { error } = await supabase.from("stages").update(p).eq("id", id);
    if (error) return toast.error(errMsg(error));
    refresh();
  }
  async function add() {
    const n = name.trim();
    if (!n) return;
    const { error } = await supabase.from("stages").insert({ sector_id: sectorId, name: n, position: stages.length + 1 });
    if (error) return toast.error(errMsg(error));
    setName("");
    refresh();
  }
  async function remove(id: string) {
    if (!confirm("Excluir esta etapa definitivamente?")) return;
    const { error } = await supabase.rpc("delete_stage_safe", { _stage_id: id });
    if (error) return toast.error(errMsg(error));
    toast.success("Etapa excluída.");
    refresh();
  }

  return (
    <div className="rounded-xl border bg-card">
      <div className="flex items-center justify-between border-b px-4 py-3"><h2 className="font-semibold">Etapas ({stages.length})</h2><span className="text-xs text-muted-foreground">Arraste para reordenar</span></div>
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
        <SortableContext items={stages.map((s) => s.id)} strategy={verticalListSortingStrategy}>
          <ul className="divide-y">
            {stages.map((s, i) => (
              <StageRow key={s.id} stage={s} index={i} total={stages.length} count={counts[s.id] ?? 0} isFirst={s.id === firstActive}
                onMove={move} onPatch={patch} onRemove={remove} onMakeFirst={makeFirst} />
            ))}
          </ul>
        </SortableContext>
      </DndContext>
      <div className="flex gap-2 border-t p-3">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome da nova etapa" onKeyDown={(e) => e.key === "Enter" && add()} maxLength={60} />
        <Button onClick={add}><Plus className="size-4" /> Adicionar etapa</Button>
      </div>
    </div>
  );
}

interface RowProps {
  stage: Stage; index: number; total: number; count: number; isFirst: boolean;
  onMove: (id: string, d: -1 | 1) => void;
  onPatch: (id: string, p: Partial<Pick<Stage, "name" | "active" | "is_final">>) => void;
  onRemove: (id: string) => void;
  onMakeFirst: (id: string) => void;
}
function StageRow({ stage, index, total, count, isFirst, onMove, onPatch, onRemove, onMakeFirst }: RowProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: stage.id });
  return (
    <li ref={setNodeRef} style={{ transform: CSS.Transform.toString(transform), transition }} className={cn("flex flex-wrap items-center gap-3 bg-card px-3 py-2", isDragging && "relative z-10 shadow-lift", !stage.active && "opacity-60")}>
      <button {...attributes} {...listeners} className="cursor-grab text-muted-foreground" aria-label="Arrastar"><GripVertical className="size-4" /></button>
      <span className="w-6 font-mono text-xs text-muted-foreground">{index + 1}</span>
      <Input defaultValue={stage.name} onBlur={(e) => e.target.value.trim() && e.target.value !== stage.name && onPatch(stage.id, { name: e.target.value.trim() })} className="h-8 max-w-64" aria-label="Nome da etapa" />
      <div className="flex flex-wrap items-center gap-1.5">
        {isFirst && <Badge>Primeira</Badge>}
        {stage.is_final && <Badge className="bg-success text-success-foreground">Final</Badge>}
        <Badge variant="secondary">{count} fichas</Badge>
      </div>
      <div className="ml-auto flex items-center gap-1">
        <label className="mr-2 flex items-center gap-1.5 text-xs"><Switch checked={stage.active} onCheckedChange={(v) => onPatch(stage.id, { active: v })} /> Ativa</label>
        <Button variant="ghost" size="icon" title="Definir como etapa final" onClick={() => onPatch(stage.id, { is_final: !stage.is_final })}><Flag className={cn("size-4", stage.is_final && "text-success")} /></Button>
        {!isFirst && <Button variant="ghost" size="sm" className="text-xs" onClick={() => onMakeFirst(stage.id)}>Tornar primeira</Button>}
        <Button variant="ghost" size="icon" disabled={index === 0} onClick={() => onMove(stage.id, -1)} aria-label="Subir"><ArrowUp className="size-4" /></Button>
        <Button variant="ghost" size="icon" disabled={index === total - 1} onClick={() => onMove(stage.id, 1)} aria-label="Descer"><ArrowDown className="size-4" /></Button>
        <Button variant="ghost" size="icon" onClick={() => onRemove(stage.id)} aria-label="Excluir"><Trash2 className="size-4 text-destructive" /></Button>
      </div>
    </li>
  );
}
