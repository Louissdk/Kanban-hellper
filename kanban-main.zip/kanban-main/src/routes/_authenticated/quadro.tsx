import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { DndContext, DragOverlay, MouseSensor, TouchSensor, closestCenter, useDroppable, useSensor, useSensors, type DragEndEvent } from "@dnd-kit/core";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { ArrowLeftRight, ChevronDown, Filter, ListFilter, RefreshCw, Search, ShieldAlert, X } from "lucide-react";
import { toast } from "sonner";
import { isForwardStageMove, reorderIds, resolveDropStageId } from "@/lib/kanban-dnd";
import { z } from "zod";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { allStagesQuery, boardQuery, profilesQuery, sectorsQuery, settingsQuery, stagesQuery, PRIORITY_LABEL, isOverdue, errMsg, type BoardCard } from "@/lib/data";
import { KanbanColumn } from "@/components/app/KanbanColumn";
import { reorderKanbanStage, transferFichaSector, transitionFicha } from "@/lib/transitions";
import { FichaCard } from "@/components/app/FichaCard";
import { TransitionModal } from "@/components/app/TransitionModal";
import { NewFichaDialog } from "@/components/app/NewFichaDialog";
import { SmbSyncButton } from "@/components/app/SmbSyncButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";


const searchSchema = z.object({ setor: z.string().optional() });

export const Route = createFileRoute("/_authenticated/quadro")({
  validateSearch: searchSchema,
  head: () => ({ meta: [{ title: "Quadro de Produção — Kanban" }, { name: "description", content: "Quadro de produção por setor." }] }),
  component: QuadroPage,
});

const ALL = "__all";

function QuadroPage() {
  const { setor } = Route.useSearch();
  const navigate = useNavigate({ from: "/quadro" });
  const { canOperate, canManage, userId, isAdmin } = useAuth();
  const queryClient = useQueryClient();

  const { data: sectors = [], isLoading: loadingSectors } = useQuery(sectorsQuery);
  const activeSectors = sectors.filter((s) => s.active);
  const sectorId = setor ?? activeSectors[0]?.id;
  const { data: stages = [] } = useQuery(stagesQuery(sectorId));
  const { data: allStages = [] } = useQuery(allStagesQuery);
  const { data: cards = [], isLoading, isFetching, refetch } = useQuery(boardQuery(sectorId));
  const { data: profiles = [] } = useQuery(profilesQuery);
  const { data: settings } = useQuery(settingsQuery);
  // Filters
  const [q, setQ] = useState("");
  const [prio, setPrio] = useState(ALL);
  const [resp, setResp] = useState(ALL);
  const [seller, setSeller] = useState(ALL);
  const [stageF, setStageF] = useState(ALL);
  const [until, setUntil] = useState("");
  const [onlyOverdue, setOnlyOverdue] = useState(false);
  const [hideDone, setHideDone] = useState(false);
  const [statusF, setStatusF] = useState(ALL);
  const [sortModes, setSortModes] = useState<Record<string, "recent" | "old" | "manual">>({});
  const [manualOrders, setManualOrders] = useState<Record<string, string[]>>({});
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [finalSearchOpen, setFinalSearchOpen] = useState(false);
  const [finalSearch, setFinalSearch] = useState("");

  const activeStages = stages.filter((s) => s.active);
  const finalStage = activeStages.find((s) => s.name === "Enviado/Finalizado") ?? activeStages.find((s) => s.is_final);
  const { data: finalizedSearchCards = [], isFetching: searchingFinalized } = useQuery({
    queryKey: ["finalized-search", sectorId, finalStage?.id, finalSearch.trim()],
    enabled: !!sectorId && !!finalStage?.id && !!finalSearch.trim(),
    queryFn: async () => {
      const { data, error } = await supabase.rpc("search_finalized_fichas", {
        _sector_id: sectorId!,
        _stage_id: finalStage!.id,
        _query: finalSearch.trim(),
        _limit: 100,
      });
      if (error) throw new Error(error.message);

      return (data ?? []).map((row) => ({
        ficha_id: row.ficha_id,
        sector_id: row.sector_id,
        stage_id: row.stage_id,
        priority: row.priority as BoardCard["priority"],
        responsible_id: row.responsible_id,
        entered_stage_at: row.entered_stage_at,
        completed_at: row.completed_at,
        updated_at: row.updated_at,
        sort_order: 0,
        production_returned: row.production_returned,
        return_count: row.return_count,
        last_return_reason_category: row.last_return_reason_category,
        last_return_reason: row.last_return_reason,
        fichas: {
          order_number: row.pedido_cliente ?? row.order_number,
          external_order_id: row.pdd_id ?? null,
          pdd_id: row.pdd_id ?? null,
          pedido_cliente: row.pedido_cliente ?? null,
          customer: row.customer,
          customer_code: row.customer_code,
          codigo_cliente: row.codigo_cliente,
          source_observations: row.source_observations,
          seller_name: row.seller_name,
          product_summary: row.product_summary,
          quantity: row.quantity,
          unit: row.unit,
          delivery_date: row.data_entrega ?? row.delivery_date,
          source_system: row.source_system,
          sync_state: row.sync_state,
          created_at: row.updated_at,
          duplicate_group_id: null,
          duplicated_from_ficha_id: null,
        },
      })) as BoardCard[];
    },
  });
  const finalIds = new Set(stages.filter((s) => s.is_final).map((s) => s.id));
  const profileName = useMemo(() => new Map(profiles.map((p) => [p.id, p.full_name])), [profiles]);
  const fields = Array.isArray(settings?.card_fields) ? (settings.card_fields as string[]) : ["customer", "product", "quantity", "delivery", "responsible", "priority", "last_move"];
  const staleHours = typeof settings?.stale_hours === "number" ? settings.stale_hours : 48;

  const dq = q.trim().toLowerCase();

  const filtered = useMemo(() => cards.filter((c) => {
    const f = c.fichas;
    if (dq && ![
      f.order_number,
      f.pdd_id,
      f.external_order_id,
      f.pedido_cliente,
      ...(isAdmin ? [f.customer] : []),
      f.customer_code,
      f.codigo_cliente,
      f.seller_name,
      f.product_summary,
      f.source_observations,
    ].filter(Boolean).join(" ").toLowerCase().includes(dq)) return false;
    if (prio !== ALL && c.priority !== prio) return false;
    if (resp !== ALL && c.responsible_id !== resp) return false;
    if (seller !== ALL && f.seller_name !== seller) return false;
    if (stageF !== ALL && c.stage_id !== stageF) return false;
    if (until && (!f.delivery_date || f.delivery_date > until)) return false;
    if (onlyOverdue && !isOverdue(f.delivery_date, c.completed_at)) return false;
    if (statusF === "active" && finalIds.has(c.stage_id)) return false;
    if (statusF === "completed" && !finalIds.has(c.stage_id)) return false;
    if (hideDone && finalIds.has(c.stage_id)) return false;
    return true;
  }), [cards, dq, prio, resp, seller, stageF, until, onlyOverdue, hideDone, statusF, finalIds, isAdmin]);

  const byStage = useMemo(() => {
    const m = new Map<string, BoardCard[]>();
    for (const c of filtered) m.set(c.stage_id, [...(m.get(c.stage_id) ?? []), c]);
    for (const [stageId, list] of m) {
      const mode = sortModes[stageId] ?? "recent";
      list.sort((a, b) => {
        if (mode === "manual") {
          const savedOrder = manualOrders[stageId];
          if (savedOrder?.length) {
            const orderIndex = new Map(savedOrder.map((id, index) => [id, index]));
            return (orderIndex.get(a.ficha_id) ?? Number.MAX_SAFE_INTEGER) -
              (orderIndex.get(b.ficha_id) ?? Number.MAX_SAFE_INTEGER);
          }
          const aOrder = a.sort_order ?? Number.MAX_SAFE_INTEGER;
          const bOrder = b.sort_order ?? Number.MAX_SAFE_INTEGER;
          return aOrder - bOrder || b.updated_at.localeCompare(a.updated_at);
        }
        const aDate = a.fichas.created_at ?? a.updated_at;
        const bDate = b.fichas.created_at ?? b.updated_at;
        return mode === "recent"
          ? bDate.localeCompare(aDate) || (a.sort_order ?? 0) - (b.sort_order ?? 0)
          : aDate.localeCompare(bDate) || (a.sort_order ?? 0) - (b.sort_order ?? 0);
      });
    }
    return m;
  }, [filtered, sortModes, manualOrders]);

  const toggleStageSort = (stageId: string) => {
    setSortModes((current) => ({
      ...current,
      [stageId]:
        current[stageId] === "recent"
          ? "old"
          : current[stageId] === "old"
            ? "manual"
            : "recent",
    }));
  };

  const clearFilters = () => {
    setQ("");
    setPrio(ALL);
    setResp(ALL);
    setSeller(ALL);
    setStageF(ALL);
    setStatusF(ALL);
    setUntil("");
    setOnlyOverdue(false);
    setHideDone(false);
  };

  const filterCount = [q.trim(), prio !== ALL, resp !== ALL, seller !== ALL, stageF !== ALL, statusF !== ALL, until, onlyOverdue, hideDone].filter(Boolean).length;
  const sellers = useMemo(() => [...new Set(cards.map((c) => c.fichas.seller_name?.trim()).filter((x): x is string => !!x))].sort((a, b) => a.localeCompare(b, "pt-BR")), [cards]);

  const sensors = useSensors(
    useSensor(MouseSensor, { activationConstraint: { distance: 6 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 2000, tolerance: 8 } }),
  );
  const [dragId, setDragId] = useState<string | null>(null);
  const [modal, setModal] = useState<{ open: boolean; ficha?: string | null; stage?: string | null }>({ open: false });

  async function onDragEnd(event: DragEndEvent) {
    setDragId(null);

    if (!canOperate) {
      toast.error("Seu perfil não possui permissão para movimentar fichas.");
      return;
    }

    const activeId = String(event.active.id);
    const overId = event.over ? String(event.over.id) : null;
    const card = cards.find((c) => c.ficha_id === activeId);
    if (!card || !overId) return;

    const overType = event.over?.data.current?.type as string | undefined;
    if (overType === "sector") {
      if (!canManage || !userId) {
        toast.error("Seu perfil não possui permissão para transferir fichas entre setores.");
        return;
      }

      const targetSectorId = String(event.over?.data.current?.sectorId ?? "");
      const targetSector = activeSectors.find((sector) => sector.id === targetSectorId);
      const targetHasStage = allStages.some((stage) => stage.sector_id === targetSectorId && stage.active);
      if (!targetSector || !targetHasStage || targetSector.id === card.sector_id) return;

      try {
        await transferFichaSector(card.ficha_id, targetSector.id, userId, "Transferência realizada pelo Kanban.");
        const { data: assignment, error: verifyError } = await supabase
          .from("kanban_assignments")
          .select("sector_id,stage_id")
          .eq("ficha_id", card.ficha_id)
          .maybeSingle();
        if (verifyError) throw new Error(verifyError.message);
        if (!assignment || assignment.sector_id !== targetSector.id) {
          throw new Error("A transferência foi solicitada, mas a ficha não confirmou o novo setor.");
        }
        await Promise.all([
          queryClient.invalidateQueries({ queryKey: ["board"] }),
          queryClient.invalidateQueries({ queryKey: ["ficha", card.ficha_id] }),
          queryClient.invalidateQueries({ queryKey: ["stages", targetSector.id] }),
        ]);
        await navigate({ search: { setor: targetSector.id } });
        toast.success("Ficha transferida para o setor " + targetSector.name + ".");
      } catch (error) {
        toast.error(errMsg(error));
        await queryClient.invalidateQueries({ queryKey: ["board", sectorId] });
      }
      return;
    }

    const activeStageId = String(event.active.data.current?.stageId ?? card.stage_id);
    const overStageId = event.over?.data.current?.stageId as string | undefined;
    const overCard = cards.find((c) => c.ficha_id === overId);
    const targetStageId = resolveDropStageId(
      overId,
      overStageId || (activeStages.some((stage) => stage.id === overId) ? overId : undefined),
      overCard?.stage_id,
    );
    if (!targetStageId) return;

    if (targetStageId === card.stage_id) {
      if (filterCount > 0) {
        toast.info("Remova os filtros para reordenar os cards da etapa.");
        return;
      }

      const currentList = byStage.get(card.stage_id) ?? [];
      const orderedIds = reorderIds(
        currentList.map((item) => item.ficha_id),
        activeId,
        overId,
      );

      if (orderedIds.every((id, index) => id === currentList[index]?.ficha_id)) return;

      // Keep the UI responsive immediately, even when the live database has
      // not yet received the optional sort_order migration.
      setManualOrders((current) => ({ ...current, [card.stage_id]: orderedIds }));
      setSortModes((current) => ({ ...current, [card.stage_id]: "manual" }));

      try {
        await reorderKanbanStage(sectorId!, card.stage_id, orderedIds);

        await queryClient.invalidateQueries({ queryKey: ["board", sectorId] });
        toast.success("Ordem dos cards atualizada.");
      } catch (error) {
        toast.error(errMsg(error));
        await queryClient.invalidateQueries({ queryKey: ["board", sectorId] });
      }
      return;
    }

    const currentStage = activeStages.find((stage) => stage.id === activeStageId);
    const targetStage = activeStages.find((stage) => stage.id === targetStageId);
    if (!currentStage || !targetStage) return;

    // Avanços normais pelo arraste usam automaticamente o usuário logado.
    // Retornos continuam passando pelo diálogo para exigir responsável + motivo.
    if (isForwardStageMove(currentStage, targetStage)) {
      if (!userId) {
        setModal({ open: true, ficha: card.ficha_id, stage: targetStageId });
        return;
      }

      await queryClient.cancelQueries({ queryKey: ["board", sectorId] });
      const previousBoard = queryClient.getQueryData<BoardCard[]>(["board", sectorId]);
      const movedAt = new Date().toISOString();

      // Move the card immediately in the visible Kanban. The database
      // transition remains the single authority; a failure restores the
      // exact previous board snapshot.
      queryClient.setQueryData<BoardCard[]>(["board", sectorId], (current) =>
        (current ?? []).map((item) =>
          item.ficha_id === card.ficha_id
            ? { ...item, stage_id: targetStageId, entered_stage_at: movedAt, updated_at: movedAt }
            : item,
        ),
      );

      try {
        await transitionFicha({
          fichaId: card.ficha_id,
          newStageId: targetStageId,
          changedByUserId: userId,
          source: "kanban",
        });
        await Promise.all([
          queryClient.invalidateQueries({ queryKey: ["board", sectorId] }),
          queryClient.invalidateQueries({ queryKey: ["ficha", card.ficha_id] }),
        ]);
        toast.success("Ficha movida para " + targetStage.name + ".");
      } catch (error) {
        if (previousBoard) {
          queryClient.setQueryData(["board", sectorId], previousBoard);
        }
        toast.error(errMsg(error));
        await queryClient.invalidateQueries({ queryKey: ["board", sectorId] });
      }
      return;
    }

    setModal({ open: true, ficha: card.ficha_id, stage: targetStageId });
  }

  const dragCard = cards.find((c) => c.ficha_id === dragId);

  const renderFilters = (compact = false) => (
    <div className={compact ? "grid gap-4" : "flex flex-wrap items-center gap-2"}>
      <div className={compact ? "space-y-1.5" : "contents"}>
        {compact && <Label>Buscar</Label>}
        <div className={compact ? "relative" : "relative w-64"}>
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={isAdmin ? "Ficha, SMB/PDD, código, cliente, vendedor ou produto" : "Ficha, SMB/PDD, código, vendedor ou produto"} className="h-9 pl-9 sm:h-10" aria-label="Buscar pedidos" />
        </div>
      </div>
      <div className={compact ? "grid grid-cols-1 gap-4 sm:grid-cols-2" : "contents"}>
        <div className="space-y-1.5">
          {compact && <Label>Prioridade</Label>}
          <Select value={prio} onValueChange={setPrio}><SelectTrigger className="h-10 sm:w-40" aria-label="Prioridade"><SelectValue /></SelectTrigger><SelectContent><SelectItem value={ALL}>Toda prioridade</SelectItem>{Object.entries(PRIORITY_LABEL).map(([k,v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent></Select>
        </div>
        <div className="space-y-1.5">
          {compact && <Label>Responsável</Label>}
          <Select value={resp} onValueChange={setResp}><SelectTrigger className="h-10 sm:w-48" aria-label="Responsável"><SelectValue /></SelectTrigger><SelectContent><SelectItem value={ALL}>Todo responsável</SelectItem>{profiles.filter((p)=>p.active).map((p)=><SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>)}</SelectContent></Select>
        </div>
        <div className="space-y-1.5">
          {compact && <Label>Vendedor</Label>}
          <Select value={seller} onValueChange={setSeller}><SelectTrigger className="h-10 sm:w-44" aria-label="Vendedor"><SelectValue /></SelectTrigger><SelectContent><SelectItem value={ALL}>Todo vendedor</SelectItem>{sellers.map((name)=><SelectItem key={name} value={name}>{name}</SelectItem>)}</SelectContent></Select>
        </div>
        <div className="space-y-1.5">
          {compact && <Label>Etapa</Label>}
          <Select value={stageF} onValueChange={setStageF}><SelectTrigger className="h-10 sm:w-44" aria-label="Etapa"><SelectValue /></SelectTrigger><SelectContent><SelectItem value={ALL}>Toda etapa</SelectItem>{activeStages.map((s)=><SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent></Select>
        </div>
        <div className="space-y-1.5">
          {compact && <Label>Situação</Label>}
          <Select value={statusF} onValueChange={setStatusF}><SelectTrigger className="h-10 sm:w-40" aria-label="Situação"><SelectValue /></SelectTrigger><SelectContent><SelectItem value={ALL}>Toda situação</SelectItem><SelectItem value="active">Ativas</SelectItem><SelectItem value="completed">Concluídas</SelectItem></SelectContent></Select>
        </div>
        <div className="space-y-1.5">
          {compact && <Label>Entrega até</Label>}
          <Input type="date" value={until} onChange={(e)=>setUntil(e.target.value)} className="h-10 sm:w-40" aria-label="Entrega até" />
        </div>
      </div>
      <div className={compact ? "grid gap-3 rounded-xl border bg-muted/40 p-3 sm:grid-cols-2" : "flex items-center gap-3"}>
        <label className="flex min-h-10 items-center justify-between gap-3 text-sm"><span>Apenas atrasadas</span><Switch checked={onlyOverdue} onCheckedChange={setOnlyOverdue}/></label>
        <label className="flex min-h-10 items-center justify-between gap-3 text-sm"><span>Ocultar finalizadas</span><Switch checked={hideDone} onCheckedChange={setHideDone}/></label>
      </div>
      {compact && filterCount > 0 && <Button variant="outline" onClick={clearFilters}><X className="size-4"/> Limpar {filterCount} filtro{filterCount===1?"":"s"}</Button>}
    </div>
  );

  if (!loadingSectors && activeSectors.length === 0) {
    return <div className="grid min-h-[60vh] place-items-center px-6 text-center text-muted-foreground">Nenhum setor ativo. Um administrador precisa criar um setor em Configurações → Setores e Etapas.</div>;
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="border-b bg-card">
        <div className="mx-auto w-full max-w-[1800px] px-2 py-2 sm:px-3 sm:py-2.5">
          <div className="flex flex-wrap items-center gap-2">
            <Select value={sectorId ?? ""} onValueChange={(v)=>navigate({search:{setor:v}})}>
              <SelectTrigger className="h-10 w-[calc(100%-104px)] max-w-60 font-semibold sm:w-52" aria-label="Setor"><SelectValue placeholder="Setor"/></SelectTrigger>
              <SelectContent>{activeSectors.map((s)=><SelectItem key={s.id} value={s.id}>Setor {s.name}</SelectItem>)}</SelectContent>
            </Select>
            <div className="min-[1180px]:hidden w-full">
              <Button
                type="button"
                variant="outline"
                className="h-9 w-full justify-between sm:h-10"
                aria-expanded={filtersOpen}
                aria-controls="quadro-filters-mobile"
                onClick={() => setFiltersOpen((open) => !open)}
              >
                <span className="flex min-w-0 items-center gap-2">
                  <Filter className="size-4 shrink-0" />
                  <span className="truncate">Filtros</span>
                  {filterCount > 0 && (
                    <span className="grid min-w-5 place-items-center rounded-full bg-primary px-1 text-[10px] text-primary-foreground">
                      {filterCount}
                    </span>
                  )}
                </span>
                <ChevronDown className={cn("size-4 shrink-0 transition-transform", filtersOpen && "rotate-180")} />
              </Button>
              {filtersOpen && (
                <div id="quadro-filters-mobile" className="mt-2 rounded-xl border bg-muted/20 p-3 shadow-sm sm:p-4">
                  {renderFilters(true)}
                </div>
              )}
            </div>
            <div className="hidden w-full items-center gap-2 overflow-x-auto min-[1180px]:flex">
              {renderFilters()}
              {filterCount>0&&<Button variant="ghost" size="sm" onClick={clearFilters}><X className="size-4"/> Limpar</Button>}
            </div>
            <div className="ml-auto flex items-center gap-1 sm:gap-2">
              <div className="hidden sm:block"><SmbSyncButton /></div>
              <div className="sm:hidden"><SmbSyncButton compact /></div>
              <Button variant="ghost" size="icon" onClick={()=>refetch()} disabled={isFetching} aria-label="Atualizar quadro" title="Atualizar quadro"><RefreshCw className={isFetching?"size-4 animate-spin":"size-4"}/></Button>
              {canManage && sectorId && <NewFichaDialog sectorId={sectorId}/>}
              {canOperate && <Button size="sm" className="hidden sm:inline-flex" onClick={()=>setModal({open:true})}><ArrowLeftRight className="size-4"/> Alterar etapa</Button>}
              {canOperate && <Button size="icon" className="sm:hidden" onClick={()=>setModal({open:true})} aria-label="Alterar etapa"><ArrowLeftRight className="size-4"/></Button>}
            </div>
          </div>
          <div className="mt-1 flex min-h-6 items-center justify-between gap-2 text-[11px] text-muted-foreground" aria-live="polite">
            <span className="flex items-center gap-1.5"><ListFilter className="size-3.5"/> {filtered.length} fichas exibidas de {cards.length}</span>
            <span className="hidden items-center gap-1.5 md:flex">
              {canOperate ? (
                <>Arraste a ficha para outra etapa ou toque e segure por 2 segundos no celular para mover.</>
              ) : (
                <><ShieldAlert className="size-3.5 text-warning" /> Seu perfil está em modo somente leitura e não pode alterar etapas.</>
              )}
            </span>
          </div>
        </div>
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={(e)=>setDragId(String(e.active.id))}
        onDragEnd={onDragEnd}
        onDragCancel={()=>setDragId(null)}
      >
        <div className="min-w-0">
          {canManage && activeSectors.filter((sector) => sector.id !== sectorId && allStages.some((stage) => stage.sector_id === sector.id && stage.active)).length > 0 && (
            <div className="flex gap-1.5 overflow-x-auto border-b bg-muted/20 px-2 py-1.5 sm:px-3">
              {activeSectors
                .filter((sector) => sector.id !== sectorId && allStages.some((stage) => stage.sector_id === sector.id && stage.active))
                .map((sector) => <SectorDropZone key={sector.id} sectorId={sector.id} label={sector.name} />)}
            </div>
          )}
          <div className="scrollbar-thin flex min-w-0 items-start gap-[clamp(8px,1vw,14px)] overflow-x-auto overscroll-x-contain px-2 py-2 pb-3 sm:px-3 sm:py-2.5">
          {isLoading || !sectorId ? Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-[62vh] w-[82vw] max-w-[360px] shrink-0 rounded-2xl sm:w-80"/>) : activeStages.map((stage)=>{
            const isFinalStageColumn = finalStage?.id === stage.id;
            const allowFinalSearch = !hideDone && statusF !== "active";
            const list = isFinalStageColumn && finalSearch.trim() && allowFinalSearch
              ? finalizedSearchCards as BoardCard[]
              : byStage.get(stage.id) ?? [];
            const finalSearchAction = isFinalStageColumn ? (
              finalSearchOpen ? (
                <div className="flex min-w-0 items-center gap-1">
                  <div className="relative w-28 sm:w-36">
                    <Search className="pointer-events-none absolute left-2 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      autoFocus
                      value={finalSearch}
                      onChange={(e) => setFinalSearch(e.target.value)}
                      placeholder="Pesquisar"
                      className="h-8 pl-7 pr-7 text-xs"
                      aria-label="Pesquisar pedidos finalizados"
                    />
                    <button
                      type="button"
                      className="absolute right-1 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:text-foreground"
                      onClick={() => { setFinalSearch(""); setFinalSearchOpen(false); }}
                      aria-label="Fechar pesquisa de finalizados"
                    >
                      <X className="size-3.5" />
                    </button>
                  </div>
                  {searchingFinalized && <RefreshCw className="size-3.5 animate-spin text-muted-foreground" />}
                </div>
              ) : (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="size-8"
                  onClick={() => setFinalSearchOpen(true)}
                  title="Pesquisar pedidos finalizados"
                  aria-label="Pesquisar pedidos finalizados"
                >
                  <Search className="size-4" />
                </Button>
              )
            ) : undefined;
            return <KanbanColumn
              key={stage.id}
              stage={stage}
              count={list.length}
              sortMode={sortModes[stage.id] ?? "recent"}
              onSortToggle={() => toggleStageSort(stage.id)}
              headerAction={finalSearchAction}
            >
              {list.length===0&&<p className="grid min-h-24 place-items-center px-4 text-center text-xs text-muted-foreground">Sem fichas nesta etapa</p>}
              <SortableContext items={list.map((card) => card.ficha_id)} strategy={verticalListSortingStrategy}>
                {list.map((card)=><FichaCard
                  key={card.ficha_id}
                  card={card}
                  responsibleName={card.responsible_id?profileName.get(card.responsible_id):undefined}
                  fields={fields}
                  staleHours={staleHours}
                  isFinalStage={finalIds.has(card.stage_id)}
                  draggable={canOperate && !(isFinalStageColumn && !!finalSearch.trim())}
                />)}
              </SortableContext>
            </KanbanColumn>;
          })}
          </div>
        </div>
        <DragOverlay>{dragCard&&<FichaCard card={dragCard} fields={fields} staleHours={staleHours} isFinalStage={finalIds.has(dragCard.stage_id)} draggable={false} overlay responsibleName={dragCard.responsible_id?profileName.get(dragCard.responsible_id):undefined}/>}</DragOverlay>
      </DndContext>

      {sectorId&&<TransitionModal open={modal.open} onOpenChange={(open)=>setModal((current)=>({...current,open}))} sectorId={sectorId} fichas={cards.map((card)=>({ficha_id:card.ficha_id,order_number:card.fichas.order_number,customer:card.fichas.customer,stage_id:card.stage_id}))} initialFichaId={modal.ficha} initialStageId={modal.stage} source="kanban"/>}
    </div>
  );
}


function SectorDropZone({ sectorId, label }: { sectorId: string; label: string }) {
  const { setNodeRef, isOver } = useDroppable({
    id: "sector:" + sectorId,
    data: { type: "sector", sectorId },
  });
  return (
    <div
      ref={setNodeRef}
      className={cn(
        "flex min-h-10 min-w-40 shrink-0 items-center justify-between gap-3 rounded-xl border border-dashed bg-background px-3 py-2 text-left transition",
        isOver ? "border-primary bg-primary/10 shadow-lift" : "hover:border-primary/50 hover:bg-primary/5",
      )}
      aria-label={"Soltar ficha no setor " + label}
    >
      <span className="truncate text-xs font-bold uppercase tracking-wide">Mover para {label}</span>
      <span className="text-[10px] font-black text-muted-foreground">{isOver ? "SOLTE" : "SETOR"}</span>
    </div>
  );
}