import { describe, expect, it } from "vitest";
import { isForwardStageMove, reorderIds, resolveDropStageId } from "@/lib/kanban-dnd";

describe("PEDIFLOW drag/drop end-to-end contract", () => {
  it("resolves a column drop before falling back to the card stage", () => {
    expect(resolveDropStageId("stage-2", "stage-2", "stage-1")).toBe("stage-2");
    expect(resolveDropStageId("card-9", undefined, "stage-3")).toBe("stage-3");
    expect(resolveDropStageId(null, "stage-2", "stage-1")).toBeNull();
  });

  it("classifies stage 1 -> stage 2 as a forward production move", () => {
    expect(
      isForwardStageMove(
        { id: "stage-1", position: 1 },
        { id: "stage-2", position: 2 },
      ),
    ).toBe(true);
  });

  it("classifies a return as a backward move", () => {
    expect(
      isForwardStageMove(
        { id: "stage-3", position: 3 },
        { id: "stage-2", position: 2 },
      ),
    ).toBe(false);
  });

  it("reorders cards without calling a database RPC", () => {
    expect(reorderIds(["A", "B", "C"], "A", "C")).toEqual(["B", "C", "A"]);
    expect(reorderIds(["A", "B", "C"], "C", "A")).toEqual(["C", "A", "B"]);
    expect(reorderIds(["A", "B", "C"], "B", null)).toEqual(["A", "B", "C"]);
  });
});
