const PRODUCTION_ORIGIN = "https://pediflowlh.vercel.app";

/**
 * Authentication callbacks intentionally always use the production origin.
 * This prevents signup/recovery emails generated during local development
 * from containing a localhost destination.
 */
export function authRedirectUrl(_origin: string): string {
  return new URL("/auth", PRODUCTION_ORIGIN).toString();
}

export function recoveryRedirectUrl(_origin: string): string {
  const url = new URL("/auth", PRODUCTION_ORIGIN);
  url.searchParams.set("mode", "recovery");
  return url.toString();
}
