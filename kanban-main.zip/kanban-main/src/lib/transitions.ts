import { createClient } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

/**
 * THE single entry point for stage changes. Both drag-and-drop and the
 * "Alterar etapa" button go through here; the database function
 * `transition_ficha` validates and writes the audit record atomically.
 */
export interface TransitionInput {
  fichaId: string;
  newStageId: string;
  changedByUserId: string;
  observation?: string;
  returnReasonCategory?: string;
  source: "kanban" | "manual";
}

function getPublicRpcClient() {
  const url = import.meta.env.VITE_SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const key =
    import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
    process.env.VITE_SUPABASE_PUBLISHABLE_KEY;

  if (!url || !key) throw new Error("Configuração pública do Supabase não encontrada.");

  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

async function rpc(fn: string, args: Record<string, unknown>) {
  const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
  if (sessionError) throw new Error(sessionError.message);

  const session = sessionData.session;
  if (!session?.access_token || !session.refresh_token) {
    throw new Error("Sua sessão expirou. Entre novamente no sistema.");
  }

  const client = getPublicRpcClient();
  const { error: authError } = await client.auth.setSession({
    access_token: session.access_token,
    refresh_token: session.refresh_token,
  });
  if (authError) throw new Error(authError.message);

  const { data, error } = await client.rpc(fn, args);
  return { data, error: error ? { message: error.message } : null };
}

export async function transitionFicha(input: TransitionInput): Promise<void> {
  if (!input.fichaId) throw new Error("Selecione a ficha.");
  if (!input.changedByUserId) throw new Error("Selecione o usuário responsável pela mudança.");
  if (!input.newStageId) throw new Error("Selecione a nova etapa.");

  const args = {
    _ficha_id: input.fichaId,
    _new_stage_id: input.newStageId,
    _changed_by: input.changedByUserId,
    _observation: input.observation ?? "",
    _source: input.source,
    _return_reason_category: input.returnReasonCategory ?? null,
  };

  const primary = await rpc("transition_ficha", args);
  if (!primary.error) return;

  // Some existing databases can still expose the previous 5-argument
  // transition_ficha while the PostgREST schema cache catches up. Keep the
  // same database transition/status_history architecture instead of creating
  // a second movement path.
  if (/Could not find the function public\.transition_ficha\(/i.test(primary.error.message)) {
    const legacy = await rpc("transition_ficha", {
      _ficha_id: input.fichaId,
      _new_stage_id: input.newStageId,
      _changed_by: input.changedByUserId,
      _observation: input.observation ?? "",
      _source: input.source,
    });
    if (!legacy.error) return;
    throw new Error(legacy.error.message);
  }

  throw new Error(primary.error.message);
}

export async function reorderKanbanStage(
  sectorId: string,
  stageId: string,
  orderedFichaIds: string[],
): Promise<void> {
  const { error } = await rpc("reorder_kanban_stage", {
    _sector_id: sectorId,
    _stage_id: stageId,
    _ordered_ficha_ids: orderedFichaIds,
  });
  if (error) throw new Error(error.message);
}

export async function transferFichaSector(fichaId: string, newSectorId: string, changedBy: string, observation?: string): Promise<void> {
  if (!fichaId) throw new Error("Selecione a ficha.");
  if (!newSectorId) throw new Error("Selecione o setor de destino.");
  if (!changedBy) throw new Error("Selecione o usuário responsável pela mudança.");

  const { error } = await rpc("transfer_ficha_sector", {
    _ficha_id: fichaId,
    _new_sector_id: newSectorId,
    _changed_by: changedBy,
    _observation: observation ?? "",
  });
  if (error) throw new Error(error.message);
}