import { beforeEach, describe, expect, it, vi } from "vitest";

const { rpcMock, getSessionMock, setSessionMock, createClientMock } = vi.hoisted(() => ({
  rpcMock: vi.fn(),
  getSessionMock: vi.fn(),
  setSessionMock: vi.fn(),
  createClientMock: vi.fn(),
}));

vi.mock("@supabase/supabase-js", () => ({
  createClient: createClientMock,
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    auth: {
      getSession: getSessionMock,
    },
  },
}));

describe("stage and board RPC contracts", () => {
  beforeEach(() => {
    rpcMock.mockReset();
    getSessionMock.mockReset();
    setSessionMock.mockReset();
    createClientMock.mockReset();

    vi.stubEnv("VITE_SUPABASE_URL", "https://example.supabase.co");
    vi.stubEnv("VITE_SUPABASE_PUBLISHABLE_KEY", "test-key");

    getSessionMock.mockResolvedValue({
      data: {
        session: {
          access_token: "access-token",
          refresh_token: "refresh-token",
        },
      },
      error: null,
    });

    setSessionMock.mockResolvedValue({
      data: { session: null },
      error: null,
    });

    createClientMock.mockReturnValue({
      auth: {
        setSession: setSessionMock,
      },
      rpc: rpcMock,
    });
  });

  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it("uses the current 6-argument transition contract through the authenticated RPC client", async () => {
    rpcMock.mockResolvedValueOnce({ data: "history-id", error: null });

    const { transitionFicha } = await import("@/lib/transitions");

    await transitionFicha({
      fichaId: "ficha-1",
      newStageId: "stage-2",
      changedByUserId: "user-1",
      source: "kanban",
    });

    expect(getSessionMock).toHaveBeenCalledTimes(1);
    expect(setSessionMock).toHaveBeenCalledWith({
      access_token: "access-token",
      refresh_token: "refresh-token",
    });
    expect(rpcMock).toHaveBeenCalledTimes(1);
    expect(rpcMock.mock.calls[0]?.[0]).toBe("transition_ficha");
    expect(rpcMock.mock.calls[0]?.[1]).toMatchObject({
      _ficha_id: "ficha-1",
      _new_stage_id: "stage-2",
      _changed_by: "user-1",
      _source: "kanban",
      _return_reason_category: null,
    });
  });

  it("falls back to the legacy 5-argument transition contract when schema cache is stale", async () => {
    rpcMock
      .mockResolvedValueOnce({
        data: null,
        error: {
          message:
            "Could not find the function public.transition_ficha(_ficha_id, _new_stage_id, _changed_by, _observation, _source, _return_reason_category) in the schema cache",
        },
      })
      .mockResolvedValueOnce({ data: "history-id", error: null });

    const { transitionFicha } = await import("@/lib/transitions");

    await transitionFicha({
      fichaId: "ficha-2",
      newStageId: "stage-2",
      changedByUserId: "user-1",
      source: "kanban",
    });

    expect(rpcMock).toHaveBeenCalledTimes(2);
    expect(rpcMock.mock.calls[1]?.[0]).toBe("transition_ficha");
    expect(rpcMock.mock.calls[1]?.[1]).toEqual({
      _ficha_id: "ficha-2",
      _new_stage_id: "stage-2",
      _changed_by: "user-1",
      _observation: "",
      _source: "kanban",
    });
  });

  it("routes same-stage card reordering through the authenticated RPC client", async () => {
    rpcMock.mockResolvedValueOnce({ data: null, error: null });

    const { reorderKanbanStage } = await import("@/lib/transitions");

    await reorderKanbanStage("sector-1", "stage-1", ["ficha-2", "ficha-1"]);

    expect(rpcMock).toHaveBeenCalledTimes(1);
    expect(rpcMock.mock.calls[0]?.[0]).toBe("reorder_kanban_stage");
    expect(rpcMock.mock.calls[0]?.[1]).toEqual({
      _sector_id: "sector-1",
      _stage_id: "stage-1",
      _ordered_ficha_ids: ["ficha-2", "ficha-1"],
    });
  });
});
