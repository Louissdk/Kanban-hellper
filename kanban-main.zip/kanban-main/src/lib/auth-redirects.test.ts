import { describe, expect, it } from "vitest";
import { authRedirectUrl, recoveryRedirectUrl } from "@/lib/auth-redirects";

describe("Auth redirect URLs", () => {
  it("creates a confirmation callback on /auth", () => {
    expect(authRedirectUrl("https://pediflowlh.vercel.app")).toBe(
      "https://pediflowlh.vercel.app/auth",
    );
  });

  it("creates a recovery callback on /auth?mode=recovery", () => {
    expect(recoveryRedirectUrl("https://pediflowlh.vercel.app")).toBe(
      "https://pediflowlh.vercel.app/auth?mode=recovery",
    );
  });

  it("always uses the production origin, including during local development", () => {
    expect(recoveryRedirectUrl("http://localhost:5173")).toBe(
      "https://pediflowlh.vercel.app/auth?mode=recovery",
    );
    expect(authRedirectUrl("http://127.0.0.1:3000")).toBe(
      "https://pediflowlh.vercel.app/auth",
    );
    expect(recoveryRedirectUrl("https://preview-example.vercel.app")).toBe(
      "https://pediflowlh.vercel.app/auth?mode=recovery",
    );
  });
});
