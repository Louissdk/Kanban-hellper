import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type Priority = "baixa" | "normal" | "alta" | "urgente";
export const PRIORITY_LABEL: Record<Priority, string> = {
  baixa: "Baixa",
  normal: "Normal",
  alta: "Alta",
  urgente: "Urgente",
};

export interface Sector {
  id: string;
  name: string;
  description: string | null;
  active: boolean;
  position: number;
  is_default_import: boolean;
}
export interface Stage {
  id: string;
  sector_id: string;
  name: string;
  position: number;
  active: boolean;
  is_final: boolean;
  color: string | null;
}
export interface Profile {
  id: string;
  full_name: string;
  email: string | null;
  active: boolean;
}
export interface BoardCard {
  ficha_id: string;
  sector_id: string;
  stage_id: string;
  priority: Priority;
  responsible_id: string | null;
  entered_stage_at: string;
  completed_at: string | null;
  updated_at: string;
  production_returned: boolean;
  return_count: number;
  sort_order: number | null;
  sector_classification_pending: boolean;
  last_return_reason_category: string | null;
  last_return_reason: string | null;
  fichas: {
    order_number: string;
    external_order_id: string | null;
    pdd_id: string | null;
    pedido_cliente: string | null;
    customer: string;
    customer_code: string | null;
    codigo_cliente: string | null;
    source_observations: string | null;
    seller_name: string | null;
    product_summary: string | null;
    quantity: number | null;
    unit: string | null;
    delivery_date: string | null;
    source_system: string;
    sync_state: string;
    duplicate_group_id: string | null;
    duplicated_from_ficha_id: string | null;
    created_at: string;
  };
  item_count?: number;
}

function check<T>(res: { data: T | null; error: { message: string } | null }): T {
  if (res.error) throw new Error(res.error.message);
  return res.data as T;
}

export const sectorsQuery = queryOptions({
  queryKey: ["sectors"],
  queryFn: async () =>
    check(await supabase.from("sectors").select("*").order("position").order("name")) as Sector[],
});

export const stagesQuery = (sectorId: string | undefined) =>
  queryOptions({
    queryKey: ["stages", sectorId],
    enabled: !!sectorId,
    staleTime: 5_000,
    refetchInterval: 15_000,
    queryFn: async () =>
      check(
        await supabase.from("stages").select("*").eq("sector_id", sectorId!).order("position"),
      ) as Stage[],
  });

export const allStagesQuery = queryOptions({
  queryKey: ["stages", "all"],
  queryFn: async () => check(await supabase.from("stages").select("*").order("position")) as Stage[],
});

export const profilesQuery = queryOptions({
  queryKey: ["profiles"],
  queryFn: async () =>
    check(await supabase.from("profiles").select("id, full_name, email, active").order("full_name")) as Profile[],
});

export const boardQuery = (sectorId: string | undefined) =>
  queryOptions({
    queryKey: ["board", sectorId],
    enabled: !!sectorId,
    staleTime: 15_000,
    queryFn: async () => {
      const selectWithOrder =
        "ficha_id, sector_id, stage_id, priority, responsible_id, entered_stage_at, completed_at, updated_at, production_returned, return_count, sort_order, sector_classification_pending, last_return_reason_category, last_return_reason, fichas!inner(order_number, external_order_id, pdd_id, pedido_cliente, customer, customer_code, codigo_cliente, source_observations, seller_name, product_summary, quantity, unit, delivery_date, source_system, sync_state, duplicate_group_id, duplicated_from_ficha_id, created_at, ficha_items(count))";
      const selectWithoutOrder =
        "ficha_id, sector_id, stage_id, priority, responsible_id, entered_stage_at, completed_at, updated_at, production_returned, return_count, last_return_reason_category, last_return_reason, fichas!inner(order_number, external_order_id, pdd_id, pedido_cliente, customer, customer_code, codigo_cliente, source_observations, seller_name, product_summary, quantity, unit, delivery_date, source_system, sync_state, duplicate_group_id, duplicated_from_ficha_id, created_at, ficha_items(count))";
      const selectLegacy =
        "ficha_id, sector_id, stage_id, priority, responsible_id, entered_stage_at, completed_at, updated_at, production_returned, return_count, last_return_reason_category, last_return_reason, fichas!inner(order_number, external_order_id, pdd_id, pedido_cliente, customer, customer_code, codigo_cliente, source_observations, seller_name, product_summary, quantity, unit, delivery_date, source_system, sync_state, duplicate_group_id, created_at, ficha_items(count))";

      let response = await supabase
        .from("kanban_assignments")
        .select(selectWithOrder)
        .eq("sector_id", sectorId!)
        .neq("fichas.sync_state", "archived")
        .limit(2000);

      if (response.error && /sort_order|duplicated_from_ficha_id|column .* does not exist/i.test(response.error.message)) {
        response = await supabase
          .from("kanban_assignments")
          .select(selectWithoutOrder)
          .eq("sector_id", sectorId!)
          .neq("fichas.sync_state", "archived")
          .limit(2000);
      }

      // Keep the production board readable before the optional duplication
      // migration reaches the live database.
      if (response.error && /duplicated_from_ficha_id|column .* does not exist/i.test(response.error.message)) {
        response = await supabase
          .from("kanban_assignments")
          .select(selectLegacy)
          .eq("sector_id", sectorId!)
          .neq("fichas.sync_state", "archived")
          .limit(2000);
      }

      const rows = check(response) as unknown as Array<
        BoardCard & {
          sort_order?: number | null;
          fichas: BoardCard["fichas"] & { ficha_items?: Array<{ count?: number }> };
        }
      >;

      return rows.map((row) => {
        const item_count = Number(row.fichas.ficha_items?.[0]?.count ?? 0);
        const { ficha_items: _items, ...ficha } = row.fichas;
        return { ...row, sort_order: row.sort_order ?? null, item_count, fichas: ficha };
      });
    },
  });

export const settingsQuery = queryOptions({
  queryKey: ["settings"],
  queryFn: async () => {
    const rows = check(await supabase.from("system_settings").select("key, value")) as {
      key: string;
      value: unknown;
    }[];
    return Object.fromEntries(rows.map((r) => [r.key, r.value])) as Record<string, unknown>;
  },
});

export const CARD_FIELDS = [
  { key: "customer", label: "Cliente" },
  { key: "customer_code", label: "Código do cliente" },
  { key: "product", label: "Produto" },
  { key: "quantity", label: "Quantidade" },
  { key: "delivery", label: "Prazo de entrega" },
  { key: "responsible", label: "Responsável" },
  { key: "priority", label: "Prioridade" },
  { key: "last_move", label: "Última movimentação" },
] as const;

export function maskCustomerName(value: string | null | undefined, canView: boolean): string {
  if (canView) return value?.trim() || "—";
  return value?.trim() ? "Cliente protegido" : "—";
}

export function fmtDate(d: string | null | undefined): string {
  if (!d) return "—";
  const date = d.length === 10 ? new Date(d + "T12:00:00") : new Date(d);
  return date.toLocaleDateString("pt-BR");
}
export function fmtDateTime(d: string | null | undefined): string {
  if (!d) return "—";
  return new Date(d).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
}

export function fmtSyncDateTime(d: string | null | undefined): string {
  if (!d) return "—";
  const date = new Date(d);
  if (Number.isNaN(date.getTime())) return "—";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${String(date.getFullYear()).slice(-2)} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
export function isOverdue(delivery: string | null, completed: string | null): boolean {
  if (!delivery || completed) return false;
  return new Date(delivery + "T23:59:59") < new Date();
}

/** Translate Postgres exceptions raised by our functions into readable text. */
export function errMsg(e: unknown): string {
  if (e instanceof Error) return e.message;
  if (e && typeof e === "object" && "message" in e) return String((e as { message: string }).message);
  return "Erro inesperado.";
}
