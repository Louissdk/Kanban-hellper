import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type AppRole = "admin" | "supervisor" | "operator" | "viewer";

interface AuthState {
  session: Session | null;
  loading: boolean;
  userId: string | null;
  fullName: string;
  roles: AppRole[];
  isAdmin: boolean;
  canManage: boolean;
  canOperate: boolean;
  isTestMode: boolean;
  testModeActive: boolean;
  testModeOwnerId: string | null;
  testModeOwner: boolean;
}

const AuthContext = createContext<AuthState | null>(null);

/**
 * Holds session + role flags for UI gating only.
 * Real authorization is enforced by RLS and SECURITY DEFINER functions.
 */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const userId = session?.user.id ?? null;
  const { data: me } = useQuery({
    queryKey: ["me", userId],
    enabled: !!userId,
    queryFn: async () => {
      const [p, r] = await Promise.all([
        supabase.from("profiles").select("full_name").eq("id", userId!).maybeSingle(),
        supabase.from("user_roles").select("role").eq("user_id", userId!),
      ]);
      return {
        fullName: p.data?.full_name ?? "",
        roles: (r.data ?? []).map((x) => x.role as AppRole),
      };
    },
  });

  const roles = me?.roles ?? [];
  const roleBasedCanOperate = roles.some((r) => r === "admin" || r === "supervisor" || r === "operator");
  const { data: dbCanOperate } = useQuery({
    queryKey: ["me", userId, "can-operate"],
    enabled: !!userId,
    staleTime: 15_000,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("can_operate", { _user_id: userId! });
      if (error) return null;
      return Boolean(data);
    },
  });
  const effectiveCanOperate = dbCanOperate === null || dbCanOperate === undefined ? roleBasedCanOperate : dbCanOperate;

  const { data: testMode } = useQuery({
    queryKey: ["test-mode"],
    enabled: !!userId,
    refetchInterval: 10_000,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_test_mode_state");
      if (error) throw new Error(error.message);
      return (data ?? { active: false, activated_by: null, activated_at: null, activated_by_me: false }) as { active: boolean; activated_by: string | null; activated_at: string | null; activated_by_me: boolean };
    },
  });
  const testModeActive = !!testMode?.active;
  const isTestMode = testModeActive && !!testMode?.activated_by_me;
  const value: AuthState = {
    session,
    loading,
    userId,
    fullName: me?.fullName ?? session?.user.email ?? "",
    roles,
    isAdmin: roles.includes("admin") || isTestMode,
    canManage: isTestMode || roles.some((r) => r === "admin" || r === "supervisor"),
    canOperate: isTestMode || effectiveCanOperate,
    isTestMode,
    testModeActive,
    testModeOwnerId: testMode?.activated_by ?? null,
    testModeOwner: !!testMode?.activated_by_me,
  };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de AuthProvider");
  return ctx;
}

export const ROLE_LABEL: Record<AppRole, string> = {
  admin: "Administrador",
  supervisor: "Supervisor",
  operator: "Operador",
  viewer: "Visualizador",
};
