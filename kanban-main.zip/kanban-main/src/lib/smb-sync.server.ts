import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { createSupabaseRequestClient } from "@/integrations/supabase/request.server";

export type TriggerType = "manual" | "automatic";

export type SmbSyncResult = {
  success?: boolean;
  sync_run_id: string;
  orders_scanned?: number;
  orders_eligible?: number;
  orders_created?: number;
  orders_updated?: number;
  orders_ignored?: number;
  errors_count?: number;
  warnings_count?: number;
  message?: string;
  orders?: unknown[];
  errors?: Array<{
    external_order_id?: string | null;
    error_type?: string;
    error_message?: string;
    message?: string;
  }>;
};

const env = (name: string) => process.env[name]?.trim() || null;

function getBearerToken(request: Request): string {
  const header = request.headers.get("authorization");
  if (!header?.startsWith("Bearer ")) throw new Error("Não autenticado.");
  const token = header.slice(7).trim();
  if (!token) throw new Error("Sessão inválida.");
  return token;
}

export async function authenticateUser(request: Request): Promise<string> {
  const token = getBearerToken(request);
  const db = createSupabaseRequestClient(token);
  const { data, error } = await db.auth.getUser(token);

  if (error || !data.user?.id) throw new Error("Sessão inválida.");
  return data.user.id;
}

export async function isTestModeActive(db = supabaseAdmin) {
  const { data, error } = await db.rpc("is_test_mode");
  if (error) throw new Error(error.message);
  return data === true;
}

export async function createSyncRun(trigger: TriggerType, requestedBy: string | null) {
  const { data: active, error: activeError } = await supabaseAdmin
    .from("sync_runs")
    .select("id,status")
    .in("status", ["requested", "running"])
    .limit(1)
    .maybeSingle();

  if (activeError) throw new Error(activeError.message);

  if (active) {
    throw Object.assign(new Error("Já existe uma sincronização em andamento."), {
      code: "SYNC_BUSY",
      runId: active.id,
    });
  }

  const isManual = trigger === "manual";
  const { data, error } = await supabaseAdmin
    .from("sync_runs")
    .insert({
      status: "requested",
      trigger,
      trigger_type: isManual ? "manual_button" : "automatic",
      requested_by: requestedBy,
      robot_status: isManual ? "queued" : "unknown",
      robot_message: isManual ? "Aguardando o robô SMB." : null,
    })
    .select("id,status")
    .single();

  if (error) {
    if (error.code === "23505") {
      const current = await supabaseAdmin
        .from("sync_runs")
        .select("id")
        .in("status", ["requested", "running"])
        .limit(1)
        .maybeSingle();

      throw Object.assign(new Error("Já existe uma sincronização em andamento."), {
        code: "SYNC_BUSY",
        runId: current.data?.id,
      });
    }
    throw new Error(error.message);
  }

  return data;
}

export async function getRobotConfig(db = supabaseAdmin) {
  const { data, error } = await db
    .from("system_settings")
    .select("value")
    .eq("key", "smb_robot_url")
    .maybeSingle();

  if (error) throw new Error(error.message);

  const dbUrl = typeof data?.value === "string" ? data.value.trim() : "";
  const envUrl = env("SMB_ROBOT_URL");
  const timeout = Number(env("SMB_ROBOT_TIMEOUT_MS") || 120000);

  return {
    url: envUrl || dbUrl,
    apiKey: env("SMB_ROBOT_API_KEY"),
    timeoutMs: Number.isFinite(timeout) && timeout >= 1000 ? timeout : 120000,
  };
}

export async function markRunFailed(runId: string, message: string, robotUnavailable: boolean) {
  await supabaseAdmin.from("sync_errors").insert({
    sync_run_id: runId,
    external_order_id: null,
    level: "error",
    message,
    error_type: robotUnavailable ? "robot_unavailable" : "sync_request_error",
    error_message: message,
    occurred_at: new Date().toISOString(),
  });

  await supabaseAdmin
    .from("sync_runs")
    .update({
      status: "failed",
      finished_at: new Date().toISOString(),
      errors: 1,
      errors_count: 1,
      error_details: message,
      error_message: message,
      robot_status: robotUnavailable ? "unavailable" : "available",
      robot_message: message,
    })
    .eq("id", runId);
}

export async function processRobotResult(runId: string, result: SmbSyncResult) {
  if (result.sync_run_id !== runId) {
    throw new Error("sync_run_id incompatível com a execução solicitada.");
  }

  if (await isTestModeActive()) {
    await markRunFailed(runId, "Modo de teste ativo: processamento SMB bloqueado.", false);
    return { status: "failed", sync_run_id: runId };
  }

  const orders = normalizeSyncOrders(Array.isArray(result.orders) ? result.orders : []);

  if (
    orders.length === 0 &&
    Number(result.orders_scanned ?? 0) === 0 &&
    env("SMB_ALLOW_EMPTY_SYNC") !== "true"
  ) {
    await markRunFailed(
      runId,
      "O robô não retornou pedidos. Sincronização interrompida por segurança.",
      false,
    );
    return { status: "failed", sync_run_id: runId };
  }

  if (result.success === false && orders.length === 0 && !(result.errors?.length)) {
    await markRunFailed(
      runId,
      result.message || "O robô informou falha sem detalhes.",
      false,
    );
    return { status: "failed", sync_run_id: runId };
  }

  const { data, error } = await supabaseAdmin.rpc("process_smb_sync_result", {
    _sync_run_id: runId,
    _result: { ...result, sync_run_id: runId, orders },
  });

  if (error) throw new Error(error.message);

  for (const item of result.errors || []) {
    const message = item.error_message || item.message || "Erro reportado pelo robô.";
    await supabaseAdmin.from("sync_errors").insert({
      sync_run_id: runId,
      external_order_id: item.external_order_id || null,
      level: "error",
      message,
      error_type: item.error_type || "robot_error",
      error_message: message,
      occurred_at: new Date().toISOString(),
    });
  }

  if (result.errors?.length) {
    const current = await supabaseAdmin
      .from("sync_runs")
      .select("errors,errors_count,error_message,error_details")
      .eq("id", runId)
      .maybeSingle();

    const totalErrors = Number(current.data?.errors || 0) + result.errors.length;
    const messages = [
      current.data?.error_message,
      ...result.errors.map((item) => item.error_message || item.message || "Erro reportado pelo robô."),
    ].filter(Boolean).join("\n");

    await supabaseAdmin.from("sync_runs").update({
      status: "partial",
      errors: totalErrors,
      errors_count: totalErrors,
      error_message: messages || null,
      error_details: messages || null,
    }).eq("id", runId);
  }

  return data;
}


export type SmbLookupItem = {
  sequence?: number | null;
  code?: string | null;
  product?: string | null;
  description?: string | null;
  quantity?: number | null;
  unit?: string | null;
};

export type SmbLookupOrder = {
  external_order_id: string;
  customer_order_number: string | null;
  pedido_cliente: string | null;
  customer: string | null;
  smb_cliente_id: string | null;
  customer_code: string | null;
  codigo_cliente: string | null;
  seller: string | null;
  opened_at: string | null;
  delivery_date: string | null;
  data_entrega: string | null;
  envio: string | null;
  smb_status: string | null;
  status_smb: string | null;
  status_smb_descricao: string | null;
  product_summary: string | null;
  quantity: number | null;
  unit: string | null;
  source_observations: string | null;
  ranking: number | null;
  items: SmbLookupItem[];
};

function stringValue(value: unknown): string | null {
  if (typeof value !== "string" && typeof value !== "number") return null;
  const valueText = String(value).trim();
  return valueText ? valueText : null;
}

function numberValue(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const textValue = stringValue(value);
  if (!textValue) return null;
  const parsed = Number(textValue.replace(/\./g, "").replace(",", ".").replace(/[^\d.-]/g, ""));
  return Number.isFinite(parsed) ? parsed : null;
}

function parseDateTime(value: unknown): string | null {
  const textValue = stringValue(value);
  if (!textValue) return null;
  if (/^\d{4}-\d{2}-\d{2}T/.test(textValue)) {
    const parsed = new Date(textValue);
    return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
  }
  const match = textValue.match(/^(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}):(\d{2})(?::(\d{2}))?)?$/);
  if (!match) return null;
  const [, day, month, year, hour = "00", minute = "00", second = "00"] = match;
  const parsed = new Date(`${year}-${month}-${day}T${hour}:${minute}:${second}-03:00`);
  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
}

function parseDate(value: unknown): string | null {
  const textValue = stringValue(value);
  if (!textValue) return null;
  if (/^\d{4}-\d{2}-\d{2}$/.test(textValue)) return textValue;
  const match = textValue.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  return match ? `${match[3]}-${match[2]}-${match[1]}` : null;
}

export function normalizeSmbRobotOrder(rawOrder: unknown): SmbLookupOrder {
  const raw = (rawOrder && typeof rawOrder === "object" ? rawOrder : {}) as Record<string, unknown>;
  const cliente = (raw.cliente && typeof raw.cliente === "object" ? raw.cliente : {}) as Record<string, unknown>;

  const externalOrderId = stringValue(raw.external_order_id ?? raw.pdd_id) ?? "";
  const statusCodeRaw = stringValue(raw.status_smb ?? raw.status_code);
  const statusDescriptionRaw = stringValue(raw.status_smb_descricao ?? raw.status_description ?? (typeof raw.smb_status === "string" ? raw.smb_status : null));
  const statusCode = statusCodeRaw && /^(I|P|A|C)$/i.test(statusCodeRaw) ? statusCodeRaw.toUpperCase() : null;

  const statusDescription =
    stringValue(statusDescriptionRaw) ??
    (statusCode === "I" ? "INICIADO" : statusCode === "P" ? "EM PRODUÇÃO" : statusCode === "A" ? "EM ATRASO" : statusCode === "C" ? "CONCLUÍDO" : null);

  const rawItems = Array.isArray(raw.itens) ? raw.itens : Array.isArray(raw.items) ? raw.items : [];
  const items = rawItems.map((entry, index) => {
    const item = (entry && typeof entry === "object" ? entry : {}) as Record<string, unknown>;
    return {
      sequence: numberValue(item.sequencia ?? item.sequence ?? item.item_sequence) ?? index + 1,
      code: stringValue(item.codigo ?? item.code),
      product: stringValue(item.produto ?? item.product),
      description: stringValue(item.descricao ?? item.description),
      quantity: numberValue(item.quantidade ?? item.quantity),
      unit: stringValue(item.unidade ?? item.unit),
    };
  });

  return {
    external_order_id: externalOrderId,
    customer_order_number: stringValue(raw.pedido_cliente ?? raw.customer_order_number ?? raw.order_number),
    pedido_cliente: stringValue(raw.pedido_cliente ?? raw.customer_order_number ?? raw.order_number),
    customer: stringValue(cliente.nome ?? raw.customer),
    smb_cliente_id: stringValue(cliente.smb_cliente_id ?? raw.smb_cliente_id),
    customer_code: null,
    codigo_cliente: null,
    seller: stringValue(raw.vendedor ?? raw.seller),
    opened_at: parseDateTime(raw.abertura ?? raw.opened_at),
    delivery_date: parseDate(raw.data_entrega ?? raw.delivery_date),
    data_entrega: parseDate(raw.data_entrega ?? raw.delivery_date),
    envio: stringValue(raw.envio),
    smb_status: statusDescription,
    status_smb: statusCode,
    status_smb_descricao: statusDescription,
    product_summary: stringValue(raw.product_summary),
    quantity: numberValue(raw.quantity),
    unit: stringValue(raw.unit),
    source_observations: stringValue(raw.observacoes ?? raw.source_observations),
    ranking: numberValue(raw.ranking ?? raw.rank),
    items,
  };
}

export async function getRobotLookupConfig(db = supabaseAdmin) {
  const { data, error } = await db
    .from("system_settings")
    .select("value")
    .eq("key", "smb_robot_lookup_url")
    .maybeSingle();
  if (error) throw new Error(error.message);

  const dbUrl = typeof data?.value === "string" ? data.value.trim() : "";
  const sync = await getRobotConfig(db);

  return {
    url: env("SMB_ROBOT_LOOKUP_URL") || dbUrl || sync.url,
    apiKey: env("SMB_ROBOT_API_KEY"),
    timeoutMs: sync.timeoutMs,
  };
}

export async function lookupSmbOrder(
  pddId: string,
  requestedBy: string,
  accessToken: string,
) {
  const db = createSupabaseRequestClient(accessToken);

  if (await isTestModeActive(db)) {
    throw new Error("A consulta ao SMB fica bloqueada durante o Modo Teste.");
  }

  const { data: canOperate, error: roleError } = await db.rpc("can_operate", {
    _user_id: requestedBy,
  });
  if (roleError) throw new Error(roleError.message);
  if (!canOperate) throw new Error("Usuário sem permissão para consultar pedidos no SMB.");

  const robot = await getRobotLookupConfig(db);
  if (!robot.url) {
    throw Object.assign(
      new Error("Robô indisponível: nenhum serviço de consulta SMB está configurado."),
      { code: "ROBOT_UNAVAILABLE" },
    );
  }

  let response: Response;
  try {
    const headers = new Headers({
      "Content-Type": "application/json",
      "X-PEDIFLOW-Operation": "lookup",
    });
    if (robot.apiKey) headers.set("Authorization", "Bearer " + robot.apiKey);

    response = await fetch(robot.url, {
      method: "POST",
      headers,
      body: JSON.stringify({ operation: "lookup", pdd_id: pddId }),
      signal: AbortSignal.timeout(robot.timeoutMs),
    });
  } catch (error) {
    throw Object.assign(
      new Error(error instanceof Error ? error.message : "Não foi possível conectar ao robô."),
      { code: "ROBOT_UNAVAILABLE" },
    );
  }

  const raw = await response.text();
  let payload: Record<string, unknown> = {};
  if (raw.trim()) {
    try {
      payload = JSON.parse(raw) as Record<string, unknown>;
    } catch {
      throw new Error("O robô respondeu um conteúdo que não é JSON.");
    }
  }

  if (response.status === 404) {
    throw Object.assign(new Error("Pedido não encontrado no SMB."), { code: "ORDER_NOT_FOUND" });
  }

  if (!response.ok) {
    const message = typeof payload.message === "string"
      ? payload.message
      : "O robô não conseguiu consultar o pedido.";
    throw Object.assign(new Error(message), {
      code: response.status >= 500 ? "ROBOT_UNAVAILABLE" : "ROBOT_ERROR",
    });
  }

  const rawOrder = payload.order && typeof payload.order === "object"
    ? payload.order
    : Array.isArray(payload.orders) ? payload.orders[0] : null;

  const order = normalizeSmbRobotOrder(rawOrder);
  if (!order.external_order_id) {
    throw new Error("O robô não retornou uma ficha SMB válida.");
  }
  if (order.external_order_id !== pddId) {
    throw new Error("O pdd_id retornado pelo robô não corresponde ao solicitado.");
  }

  const { data: duplicate, error: duplicateError } = await db
    .from("fichas")
    .select("id,order_number,customer_code,seller_name,smb_status,status_smb,status_smb_descricao")
    .eq("external_order_id", pddId)
    .maybeSingle();
  if (duplicateError) throw new Error(duplicateError.message);

  let duplicateLocation: { sector_name: string | null; stage_name: string | null } = {
    sector_name: null,
    stage_name: null,
  };

  if (duplicate) {
    const { data: assignment, error: assignmentError } = await db
      .from("kanban_assignments")
      .select("sector_id,stage_id")
      .eq("ficha_id", duplicate.id)
      .maybeSingle();
    if (assignmentError) throw new Error(assignmentError.message);

    if (assignment) {
      const [{ data: sector }, { data: stage }] = await Promise.all([
        db.from("sectors").select("name").eq("id", assignment.sector_id).maybeSingle(),
        db.from("stages").select("name").eq("id", assignment.stage_id).maybeSingle(),
      ]);
      duplicateLocation = {
        sector_name: sector?.name ?? null,
        stage_name: stage?.name ?? null,
      };
    }
  }

  let resolvedCustomerCode: string | null = null;
  let customerCodeResolution: "unique" | "not_found" | "ambiguous" | "no_customer" = "no_customer";
  if (order.customer) {
    const { data: customers, error: customerError } = await db
      .from("clientes")
      .select("codigo_cliente")
      .eq("ativo", true)
      .eq("nome", order.customer);
    if (customerError) throw new Error(customerError.message);

    if ((customers ?? []).length === 1) {
      resolvedCustomerCode = customers[0].codigo_cliente;
      customerCodeResolution = "unique";
    } else if ((customers ?? []).length === 0) {
      customerCodeResolution = "not_found";
    } else {
      customerCodeResolution = "ambiguous";
    }
  }

  return {
    order: { ...order, customer_code: resolvedCustomerCode, codigo_cliente: resolvedCustomerCode },
    customer_code_resolution: customerCodeResolution,
    duplicate: duplicate
      ? {
          ficha_id: duplicate.id,
          order_number: duplicate.order_number,
          customer_code: duplicate.customer_code,
          seller_name: duplicate.seller_name,
          smb_status: duplicate.smb_status,
          status_smb: duplicate.status_smb,
          status_smb_descricao: duplicate.status_smb_descricao,
          sector_name: duplicateLocation.sector_name,
          stage_name: duplicateLocation.stage_name,
        }
      : null,
    completed_in_smb: order.status_smb === "C",
  };
}

function normalizeSyncOrders(orders: unknown[]): SmbLookupOrder[] {
  return orders.map(normalizeSmbRobotOrder).filter((order) => Boolean(order.external_order_id));
}



