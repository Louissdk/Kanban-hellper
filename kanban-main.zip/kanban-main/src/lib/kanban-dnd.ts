export interface DragStage {
  id: string;
  position: number;
}

export function resolveDropStageId(
  overId: string | null,
  overStageId: string | null | undefined,
  overCardStageId: string | null | undefined,
): string | null {
  if (!overId) return null;
  return overStageId || overCardStageId || null;
}

export function isForwardStageMove(current: DragStage, target: DragStage): boolean {
  return target.position >= current.position;
}

export function reorderIds(ids: string[], activeId: string, overId: string | null): string[] {
  if (!overId || activeId === overId) return ids.slice();

  const oldIndex = ids.indexOf(activeId);
  const overIndex = ids.indexOf(overId);

  if (oldIndex < 0 || overIndex < 0) return ids.slice();

  const next = ids.slice();
  const [moved] = next.splice(oldIndex, 1);
  next.splice(overIndex, 0, moved);
  return next;
}
