# Kanban de Produção

Camada operacional da fábrica para acompanhar fichas por setor e etapa, com autenticação, auditoria de transições, tempo real e sincronização do SMB em modo somente leitura.

Implement exactly the screenshot and nothing else

This project was built with [Lovable](https://lovable.dev).

## Arquitetura

Frontend React/TanStack Start → Supabase/PostgreSQL ← Worker Node.js + Playwright → SMB somente leitura.

O frontend não executa Playwright e não recebe credenciais do SMB. O worker consome `sync_runs`, importa pedidos via `ingest_smb_order` e nunca altera o sistema original.

### Worker SMB

Veja `worker/README.md`. Os seletores reais do SMB ficam em variáveis de ambiente e devem ser mapeados antes da primeira execução.

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/4ba87eb8-8f3f-4ef1-b254-808679bb7c6c).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
