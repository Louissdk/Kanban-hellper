export interface SmbOrderRef {
  externalOrderId: string;
  detailUrl?: string;
}

export interface SmbOrderItem {
  code?: string | null;
  product?: string | null;
  description?: string | null;
  quantity?: number | null;
  unit?: string | null;
  sequence?: number | null;
}

export interface SmbRobotCliente {
  smb_cliente_id?: string | null;
  nome?: string | null;
  codigo_cliente?: string | null;
}

export interface SmbRobotOrder {
  external_order_id?: string | null;
  pdd_id?: string | null;
  cliente?: SmbRobotCliente | null;
  vendedor?: string | null;
  abertura?: string | null;
  status_smb?: string | null;
  status_smb_descricao?: string | null;
  pedido_cliente?: string | null;
  data_entrega?: string | null;
  envio?: string | null;
  ranking?: number | string | null;
  itens?: Array<{
    sequencia?: number | string | null;
    quantidade?: number | string | null;
    unidade?: string | null;
    descricao?: string | null;
    codigo?: string | null;
    produto?: string | null;
  }>;
}

export interface SmbNormalizedOrder {
  external_order_id: string;
  customer_order_number?: string | null;
  pedido_cliente?: string | null;
  customer: string;
  smb_cliente_id?: string | null;
  customer_code?: string | null;
  seller?: string | null;
  opened_at?: string | null;
  delivery_date?: string | null;
  data_entrega?: string | null;
  envio?: string | null;
  smb_status?: string | null;
  status_smb?: string | null;
  status_smb_descricao?: string | null;
  product_summary?: string | null;
  quantity?: number | null;
  unit?: string | null;
  order_date?: string | null;
  source_observations?: string | null;
  source_system: string;
  source_hash?: string | null;
  ranking?: number | null;
  items: SmbOrderItem[];
}

export interface SMBOrderSource {
  authenticate(): Promise<void>;
  listOrders(): Promise<SmbOrderRef[]>;
  getOrder(ref: SmbOrderRef): Promise<unknown>;
  getOrderItems(order: unknown, ref: SmbOrderRef): Promise<SmbOrderItem[]>;
  normalizeOrder(order: unknown, items: SmbOrderItem[], ref: SmbOrderRef): Promise<SmbNormalizedOrder>;
  close(): Promise<void>;
}
