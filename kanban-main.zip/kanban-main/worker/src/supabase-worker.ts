import { createHash } from "node:crypto";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { SmbPlaywrightAdapter } from "./smb-playwright-adapter.js";
import type { SMBOrderSource, SmbNormalizedOrder, SmbOrderRef } from "./types.js";

const required = (name: string) => {
  const value = process.env[name]?.trim();
  if (!value) throw new Error("Variável " + name + " não configurada.");
  return value;
};

type SyncSettings = {
  enabled: boolean;
  interval_minutes: number;
};

type SyncError = {
  external_order_id: string | null;
  error_type: string;
  error_message: string;
};

type SyncRpcResult = {
  success: boolean;
  sync_run_id: string;
  orders_scanned: number;
  orders_eligible: number;
  orders_created: number;
  orders_updated: number;
  orders_ignored: number;
  errors_count: number;
  warnings_count: number;
  status: "success" | "partial";
};

export class SyncWorker {
  private readonly db: SupabaseClient;
  private readonly source: SMBOrderSource;

  constructor(source: SMBOrderSource = new SmbPlaywrightAdapter()) {
    this.db = createClient(
      required("SUPABASE_URL"),
      required("SUPABASE_SERVICE_ROLE_KEY"),
      { auth: { persistSession: false, autoRefreshToken: false } },
    );
    this.source = source;
  }

  async runForever(): Promise<never> {
    for (;;) {
      try {
        if (!(await this.isTestMode())) {
          await this.scheduleAutomaticRun();
          const run = await this.claimRequestedRun();
          if (run) await this.processRun(run);
        }
      } catch (error) {
        console.error("[worker]", error);
      }

      await new Promise((resolve) =>
        setTimeout(resolve, Number(process.env.WORKER_POLL_MS ?? 5000)),
      );
    }
  }

  private async isTestMode(): Promise<boolean> {
    const { data, error } = await this.db.rpc("is_test_mode");
    if (error) throw error;
    return data === true;
  }

  private async getSyncSettings(): Promise<SyncSettings> {
    const { data, error } = await this.db
      .from("system_settings")
      .select("value")
      .eq("key", "sync")
      .maybeSingle();

    if (error) throw error;

    const value = data?.value;
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      return { enabled: true, interval_minutes: 30 };
    }

    const raw = value as Record<string, unknown>;
    const interval = Number(
      raw.interval_minutes ?? process.env.SYNC_INTERVAL_MINUTES ?? 30,
    );

    return {
      enabled: raw.enabled !== false,
      interval_minutes:
        Number.isFinite(interval) && interval >= 5 ? interval : 30,
    };
  }

  private async scheduleAutomaticRun() {
    const active = await this.db
      .from("sync_runs")
      .select("id")
      .in("status", ["requested", "running"])
      .limit(1);

    if (active.error) throw active.error;
    if ((active.data ?? []).length > 0) return;

    const settings = await this.getSyncSettings();
    if (!settings.enabled) return;

    const latest = await this.db
      .from("sync_runs")
      .select("finished_at,created_at")
      .in("status", ["success", "partial"])
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (latest.error) throw latest.error;

    const lastRunAt = latest.data?.finished_at ?? latest.data?.created_at;
    const due =
      !lastRunAt ||
      Date.now() - new Date(lastRunAt).getTime() >=
        settings.interval_minutes * 60_000;

    if (!due) return;

    const created = await this.db
      .from("sync_runs")
      .insert({
        status: "requested",
        trigger: "automatic",
        trigger_type: "automatic",
        robot_status: "unknown",
      })
      .select("id")
      .single();

    if (created.error && created.error.code !== "23505") {
      throw created.error;
    }
  }

  private async claimRequestedRun(): Promise<{
    id: string;
    trigger_type: string | null;
  } | null> {
    const found = await this.db
      .from("sync_runs")
      .select("id,trigger_type")
      .eq("status", "requested")
      .order("created_at")
      .limit(1)
      .maybeSingle();

    if (found.error) throw found.error;
    if (!found.data) return null;

    const claimed = await this.db
      .from("sync_runs")
      .update({
        status: "running",
        started_at: new Date().toISOString(),
        finished_at: null,
        error_details: null,
        error_message: null,
        robot_status: "running",
        robot_message: "Serviço Playwright processando a solicitação.",
      })
      .eq("id", found.data.id)
      .eq("status", "requested")
      .select("id,trigger_type")
      .maybeSingle();

    if (claimed.error) throw claimed.error;
    return claimed.data ?? null;
  }

  private async processRun(run: {
    id: string;
    trigger_type: string | null;
  }) {
    const startedAt = new Date().toISOString();
    const orders: SmbNormalizedOrder[] = [];
    const errors: SyncError[] = [];

    try {
      await this.source.authenticate();
      const refs = await this.source.listOrders();

      if (!refs.length && process.env.SMB_ALLOW_EMPTY_SYNC !== "true") {
        throw new Error(
          "Leitura do SMB retornou zero pedidos; sincronização interrompida por segurança.",
        );
      }

      for (const ref of refs) {
        try {
          orders.push(await this.readOrder(ref));
        } catch (error) {
          errors.push({
            external_order_id: ref.externalOrderId || null,
            error_type: "order_read_error",
            error_message:
              error instanceof Error ? error.message : String(error),
          });
        }
      }

      const { data, error } = await this.db.rpc("process_smb_sync_result", {
        _sync_run_id: run.id,
        _result: {
          success: errors.length === 0,
          sync_run_id: run.id,
          trigger: run.trigger_type ?? "automatic",
          orders_scanned: refs.length,
          orders,
          errors,
        },
      });

      if (error) throw error;

      const result = (data ?? {
        success: false,
        sync_run_id: run.id,
        orders_scanned: refs.length,
        orders_eligible: 0,
        orders_created: 0,
        orders_updated: 0,
        orders_ignored: 0,
        errors_count: 0,
        warnings_count: 0,
        status: "partial",
      }) as SyncRpcResult;

      for (const item of errors) {
        await this.logError(run.id, item);
      }

      if (errors.length) {
        await this.markExtractionErrors(run.id, errors, result);
      } else {
        const { error: updateError } = await this.db
          .from("sync_runs")
          .update({
            started_at: startedAt,
            robot_status: "available",
            robot_message: "Resultado do robô processado.",
          })
          .eq("id", run.id);

        if (updateError) throw updateError;
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);

      await this.logError(run.id, {
        external_order_id: null,
        error_type: "robot_error",
        error_message: message,
      });

      await this.db
        .from("sync_runs")
        .update({
          status: "failed",
          started_at: startedAt,
          finished_at: new Date().toISOString(),
          error_message: message,
          error_details: message,
          errors: 1,
          errors_count: 1,
          robot_status: "unavailable",
          robot_message: message,
        })
        .eq("id", run.id);
    } finally {
      await this.source.close();
    }
  }

  private async readOrder(ref: SmbOrderRef): Promise<SmbNormalizedOrder> {
    const raw = await this.source.getOrder(ref);
    const items = await this.source.getOrderItems(raw, ref);
    const order = await this.source.normalizeOrder(raw, items, ref);

    return {
      ...order,
      external_order_id: ref.externalOrderId,
      source_hash: createHash("sha256")
        .update(JSON.stringify(order))
        .digest("hex"),
    };
  }

  private async logError(runId: string, error: SyncError) {
    const { error: dbError } = await this.db.from("sync_errors").insert({
      sync_run_id: runId,
      external_order_id: error.external_order_id,
      level: "error",
      message: error.error_message,
      error_type: error.error_type,
      error_message: error.error_message,
      occurred_at: new Date().toISOString(),
    });

    if (dbError) throw dbError;
  }

  private async markExtractionErrors(
    runId: string,
    errors: SyncError[],
    result: SyncRpcResult,
  ) {
    const { data: current, error: readError } = await this.db
      .from("sync_runs")
      .select("errors,errors_count,error_message,error_details")
      .eq("id", runId)
      .maybeSingle();

    if (readError) throw readError;

    const totalErrors =
      Number(current?.errors ?? 0) + errors.length;
    const details = errors
      .map(
        (item) =>
          "[" + (item.external_order_id ?? "SMB") + "] " + item.error_message,
      )
      .join("\n");
    const message = [current?.error_message, details]
      .filter(Boolean)
      .join("\n");

    const { error } = await this.db
      .from("sync_runs")
      .update({
        status: "partial",
        finished_at: new Date().toISOString(),
        errors: totalErrors,
        errors_count: totalErrors,
        error_message: message,
        error_details: message,
        orders_scanned: result.orders_scanned,
        orders_eligible: result.orders_eligible,
        orders_created: result.orders_created,
        orders_updated: result.orders_updated,
        orders_ignored: result.orders_ignored,
        robot_status: "available",
        robot_message: "Sincronização concluída com erros de leitura.",
      })
      .eq("id", runId);

    if (error) throw error;
  }
}

