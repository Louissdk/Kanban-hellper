import { createServer } from "node:http";
import { SyncWorker } from "./supabase-worker.js";
import { SmbPlaywrightAdapter } from "./smb-playwright-adapter.js";

const apiKey = process.env.SMB_ROBOT_API_KEY?.trim() || null;
const port = Number(process.env.ROBOT_HTTP_PORT ?? 8787);

function authorized(req: import("node:http").IncomingMessage) {
  return !!apiKey && req.headers.authorization === "Bearer " + apiKey;
}

async function readBody(req: import("node:http").IncomingMessage) {
  let raw = "";
  for await (const chunk of req) raw += chunk;
  return raw.trim() ? JSON.parse(raw) as Record<string, unknown> : {};
}

function sendJson(res: import("node:http").ServerResponse, status: number, data: unknown) {
  const payload = JSON.stringify(data);
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json");
  res.setHeader("Content-Length", Buffer.byteLength(payload));
  res.end(payload);
}

async function lookupOrder(pddId: string) {
  const source = new SmbPlaywrightAdapter();
  try {
    await source.authenticate();
    const ref = { externalOrderId: pddId };
    const raw = await source.getOrder(ref);
    const items = await source.getOrderItems(raw, ref);
    const order = await source.normalizeOrder(raw, items, ref);
    return { success: true, order: { ...order, external_order_id: pddId } };
  } finally {
    await source.close();
  }
}

const server = createServer(async (req, res) => {
  if (req.method === "GET" && req.url === "/health") {
    return sendJson(res, 200, { ok: true, service: "pediflow-smb-robot" });
  }
  if (req.method !== "POST" || !["/sync", "/"].includes(req.url ?? "")) {
    return sendJson(res, 404, { message: "Endpoint não encontrado." });
  }
  if (!authorized(req)) return sendJson(res, 401, { message: "Não autorizado." });

  try {
    const payload = await readBody(req);

    if (payload.operation === "lookup") {
      const pddId = String(payload.pdd_id ?? "").trim();
      if (!/^\d{1,30}$/.test(pddId)) {
        return sendJson(res, 400, { message: "pdd_id inválido." });
      }
      try {
        return sendJson(res, 200, await lookupOrder(pddId));
      } catch (error) {
        return sendJson(res, 404, {
          success: false,
          message: error instanceof Error ? error.message : "Pedido não encontrado no SMB.",
        });
      }
    }

    const syncRunId = String(payload.sync_run_id ?? "").trim();
    if (!syncRunId) {
      return sendJson(res, 400, { message: "sync_run_id é obrigatório." });
    }

    return sendJson(res, 202, {
      accepted: true,
      sync_run_id: syncRunId,
      message: "Solicitação aceita. O worker processará a execução.",
    });
  } catch (error) {
    return sendJson(res, 500, {
      message: error instanceof Error ? error.message : "Erro inesperado no serviço do robô.",
    });
  }
});

server.listen(port, "0.0.0.0", () => {
  console.log("[robot] HTTP listening on port " + port);
});

void new SyncWorker().runForever();
