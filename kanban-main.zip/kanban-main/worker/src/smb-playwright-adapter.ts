import { chromium, type Browser, type BrowserContext, type Page } from "playwright";
import type { SMBOrderSource, SmbNormalizedOrder, SmbOrderItem, SmbOrderRef } from "./types.js";

const required = (name: string) => {
  const value = process.env[name]?.trim();
  if (!value) throw new Error("Variável " + name + " não configurada.");
  return value;
};

const optional = (name: string) => process.env[name]?.trim() ?? "";

function numberValue(value: string) {
  const normalized = value.replace(/\./g, "").replace(",", ".").replace(/[^\d.-]/g, "");
  const result = Number(normalized);
  return Number.isFinite(result) ? result : null;
}

function dateValue(value: string) {
  const br = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (br) return br[3] + "-" + br[2] + "-" + br[1];
  return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : null;
}

function dateTimeValue(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return null;

  if (/^\d{4}-\d{2}-\d{2}T/.test(trimmed)) {
    const date = new Date(trimmed);
    return Number.isNaN(date.getTime()) ? null : date.toISOString();
  }

  const br = trimmed.match(/^(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}):(\d{2})(?::(\d{2}))?)?$/);
  if (!br) return null;

  const day = br[1];
  const month = br[2];
  const year = br[3];
  const hour = br[4] ?? "00";
  const minute = br[5] ?? "00";
  const second = br[6] ?? "00";
  const date = new Date(year + "-" + month + "-" + day + "T" + hour + ":" + minute + ":" + second + "-03:00");

  return Number.isNaN(date.getTime()) ? null : date.toISOString();
}

export class SmbPlaywrightAdapter implements SMBOrderSource {
  private browser?: Browser;
  private context?: BrowserContext;
  private page?: Page;

  private async getPage() {
    if (this.page) return this.page;

    this.browser = await chromium.launch({
      headless: process.env.SMB_HEADLESS !== "false",
    });
    this.context = await this.browser.newContext();
    this.page = await this.context.newPage();

    return this.page;
  }

  async authenticate() {
    const page = await this.getPage();

    await page.goto(required("SMB_BASE_URL"), { waitUntil: "domcontentloaded" });
    await page
      .locator(required("SMB_LOGIN_USER_SELECTOR"))
      .fill(required("SMB_USERNAME"));
    await page
      .locator(required("SMB_LOGIN_PASSWORD_SELECTOR"))
      .fill(required("SMB_PASSWORD"));
    await page.locator(required("SMB_LOGIN_SUBMIT_SELECTOR")).click();
    await page.waitForLoadState("domcontentloaded");
  }

  async listOrders(): Promise<SmbOrderRef[]> {
    // A paginação final do SMB ainda não foi definida. Não inventamos uma estratégia nova.
    const page = await this.getPage();
    await page.goto(required("SMB_ORDERS_URL"), { waitUntil: "domcontentloaded" });

    const rows = page.locator(required("SMB_ORDER_ROW_SELECTOR"));
    const output: SmbOrderRef[] = [];

    for (let index = 0; index < await rows.count(); index += 1) {
      const row = rows.nth(index);
      const externalOrderId = (
        await row.locator(required("SMB_ORDER_ID_SELECTOR")).first().innerText()
      ).trim();

      if (!externalOrderId) continue;

      const href = await row
        .locator(required("SMB_ORDER_LINK_SELECTOR"))
        .first()
        .getAttribute("href")
        .catch(() => null);

      output.push({
        externalOrderId,
        detailUrl: href
          ? new URL(href, required("SMB_BASE_URL")).toString()
          : undefined,
      });
    }

    return output;
  }

  async getOrder(ref: SmbOrderRef) {
    const page = await this.getPage();
    const url =
      ref.detailUrl ??
      required("SMB_ORDER_DETAIL_URL_TEMPLATE").replace(
        "{id}",
        encodeURIComponent(ref.externalOrderId),
      );

    await page.goto(url, { waitUntil: "domcontentloaded" });

    const text = async (name: string) => {
      const selector = optional(name);
      if (!selector) return "";
      return (await page.locator(selector).first().innerText()).trim();
    };

    const customerOrderSelector = optional("SMB_CUSTOMER_ORDER_NUMBER_SELECTOR");

    return {
      externalOrderId: ref.externalOrderId,
      orderNumber: customerOrderSelector
        ? await page.locator(customerOrderSelector).first().innerText()
        : ref.externalOrderId,
      customer: await page
        .locator(required("SMB_CUSTOMER_SELECTOR"))
        .first()
        .innerText(),
      seller: await text("SMB_SELLER_SELECTOR"),
      openedAt: await text("SMB_OPENED_AT_SELECTOR"),
      deliveryDate: await text("SMB_DELIVERY_DATE_SELECTOR"),
      status: await text("SMB_STATUS_SELECTOR"),
      statusDescription: await text("SMB_STATUS_DESCRIPTION_SELECTOR"),
      smbClienteId: await text("SMB_SMB_CLIENTE_ID_SELECTOR"),
      envio: await text("SMB_ENVIO_SELECTOR"),
      ranking: await text("SMB_RANKING_SELECTOR"),
      product: await page
        .locator(required("SMB_PRODUCT_SELECTOR"))
        .first()
        .innerText(),
      quantity: await text("SMB_QUANTITY_SELECTOR"),
      unit: await text("SMB_UNIT_SELECTOR"),
      orderDate: await text("SMB_ORDER_DATE_SELECTOR"),
      observations: await text("SMB_OBSERVATIONS_SELECTOR"),
      customerCode: await text("SMB_CUSTOMER_CODE_SELECTOR"),
    };
  }

  async getOrderItems(
    _order: unknown,
    _ref: SmbOrderRef,
  ): Promise<SmbOrderItem[]> {
    const selector = optional("SMB_ITEM_ROW_SELECTOR");
    if (!selector) return [];

    const page = await this.getPage();
    const rows = page.locator(selector);
    const output: SmbOrderItem[] = [];

    for (let index = 0; index < await rows.count(); index += 1) {
      const row = rows.nth(index);
      const text = async (name: string) => {
        const childSelector = optional(name);
        if (!childSelector) return null;
        return (await row.locator(childSelector).first().innerText()).trim();
      };

      const sequence = await text("SMB_ITEM_SEQUENCE_SELECTOR");
      const quantity = await text("SMB_ITEM_QUANTITY_SELECTOR");

      output.push({
        sequence: sequence ? numberValue(sequence) : index + 1,
        code: await text("SMB_ITEM_CODE_SELECTOR"),
        product: await text("SMB_ITEM_PRODUCT_SELECTOR"),
        description: await text("SMB_ITEM_DESCRIPTION_SELECTOR"),
        quantity: quantity ? numberValue(quantity) : null,
        unit: await text("SMB_ITEM_UNIT_SELECTOR"),
      });
    }

    return output;
  }

  async normalizeOrder(
    order: unknown,
    items: SmbOrderItem[],
    ref: SmbOrderRef,
  ): Promise<SmbNormalizedOrder> {
    const source = order as Record<string, string>;

    return {
      external_order_id: ref.externalOrderId,
      customer_order_number: source.orderNumber?.trim() || null,
      pedido_cliente: source.orderNumber?.trim() || null,
      customer: source.customer?.trim() || "",
      smb_cliente_id: source.smbClienteId?.trim() || null,
      customer_code: null,
      seller: source.seller?.trim() || null,
      opened_at: source.openedAt ? dateTimeValue(source.openedAt) : null,
      delivery_date: source.deliveryDate ? dateValue(source.deliveryDate.trim()) : null,
      data_entrega: source.deliveryDate ? dateValue(source.deliveryDate.trim()) : null,
      envio: source.envio?.trim() || null,
      smb_status: source.status?.trim() || null,
      status_smb: /^(I|P|A|C)$/.test(source.status?.trim() || "") ? source.status.trim() : null,
      status_smb_descricao: source.statusDescription?.trim() || null,
      product_summary: source.product?.trim() || null,
      quantity: source.quantity ? numberValue(source.quantity) : null,
      unit: source.unit?.trim() || null,
      order_date: source.orderDate ? dateValue(source.orderDate.trim()) : null,
      source_observations: source.observations?.trim() || null,
      source_system: "SMB",
      ranking: source.ranking ? numberValue(source.ranking) : null,
      items,
    };
  }

  async close() {
    await this.context?.close();
    await this.browser?.close();
    this.page = undefined;
    this.context = undefined;
    this.browser = undefined;
  }
}
