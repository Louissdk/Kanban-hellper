# Pediflow — Worker SMB

Serviço Node.js + Playwright separado do frontend. O processo autentica no SMB somente para leitura, normaliza dados e envia o lote ao Supabase.

## Segurança
- Não existem writes de negócio para o SMB.
- Credenciais ficam somente nas variáveis de ambiente do container.
- O frontend não recebe SMB_USERNAME, SMB_PASSWORD ou SMB_ROBOT_API_KEY.

## Fluxo
1. O worker cria sync_runs automáticos conforme o intervalo.
2. Ele também consome sync_runs criados pelo botão manual.
3. O adapter Playwright descobre referências e abre os pedidos.
4. Os pedidos são normalizados em lote.
5. O Supabase aplica ranking, filtro de status, resolução de cliente e upsert.
6. O Kanban stage, responsável e histórico operacional permanecem independentes do SMB.
7. sync_runs e sync_errors recebem o resultado.

## Descoberta
A paginação do SMB ainda está em investigação. Os testes anteriores encontraram duplicações entre páginas. Por isso o adapter não inventa uma estratégia nova; o worker apenas elimina referências repetidas pelo pdd_id.

## Execução
cd worker && npm install && npx playwright install chromium && npm run typecheck && npm start

Docker: docker build -t pediflow-smb-worker ./worker

Em modo fila, deixe SMB_ROBOT_URL vazio e o worker consome a fila Supabase.
Em modo HTTP, configure SMB_ROBOT_URL no backend e o serviço HTTP do robô assume o disparo.